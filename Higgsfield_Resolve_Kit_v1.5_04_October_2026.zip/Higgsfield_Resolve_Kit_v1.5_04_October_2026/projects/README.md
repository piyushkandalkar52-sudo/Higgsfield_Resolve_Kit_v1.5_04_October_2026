# Projects

Create isolated projects with `tools/new_project.sh <slug> [parent]`.
The initializer does not generate media, create a Resolve project, or approve a budget.
After confirming run ID and budget, initialize the ledger per docs/COORDINATOR.md.

For A/B tests use distinct folders and Resolve project names for baseline and
multi-agent work. Do not reuse a live baseline project's writable folder.
