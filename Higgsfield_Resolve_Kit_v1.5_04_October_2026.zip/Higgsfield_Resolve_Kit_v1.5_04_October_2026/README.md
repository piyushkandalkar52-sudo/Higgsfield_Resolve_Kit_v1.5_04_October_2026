# Higgsfield × Resolve — Multi-agent Production Kit

A self-contained production kit for Higgsfield + DaVinci Resolve: production
helpers, the Pocket FM Seedance prompt skill (with its learning material bundled in
`learning/`), coordinated agents, verified continuity handoffs, early timing checks,
and rolling QA/assembly. Everything the kit reads lives inside this folder.

## Start

> **Company use only.** This kit works only with the Pocket company Higgsfield account.
> Use of a personal account is blocked and logged (computer username, computer name,
> Git name/email, and the account attempted).

Works in **Claude Code** and **OpenAI Codex**. The same company-account guard
(`guard/hf_guard.py`) is enforced in both through each host's hooks.

1. Connect Higgsfield in your host, signed in with your **company (Pocket) account**.
2. Open **this folder**:
   - **Claude Code:** accept "Trust this folder" when asked.
   - **Codex:** trust the project when asked, then run `/hooks` and **trust the
     company-account guard hooks** (Codex requires this once before project hooks run).
3. Say: **"Start a new multi-agent project for [script]"** (Claude Code also has `/start`).
4. The kit checks setup and the company workspace automatically, then asks for missing
   decisions, prepares a timed plan, and asks for approval before generating anything.

Instructions: Claude Code reads `CLAUDE.md`; Codex reads `AGENTS.md`. Native Claude
worker definitions are in `.claude/agents/`. Hosts without subagents follow the same
workflow sequentially; no speedup is claimed for that fallback.

To compare against a single-agent workflow, say:
> Prepare an isolated A/B comparison using the same two-scene excerpt, input assets,
> output settings and quality criteria. Show the separate budgets before generating.

Follow [the comparison protocol](docs/BENCHMARK.md). Use separate project folders
and Resolve project/timeline names; do not let both kits write into your existing
TRA project. Running the comparison requires actual generation and its own approval.

## What changed
- Four core roles plus visual reviewer, workflow supervisor and agent watcher; rotate within actual host capacity.
- Independent work overlaps; dependent clips still wait for inspected real frames.
- A timed rough cut and risk-covered tests catch expensive mistakes early.
- Same-run decisions persist; material changes and new runs still need approval.
- One writer for project state, one editor for Resolve, centralized paid submission.
- A local job/budget ledger protects against duplicate reservations and overspending.
- Full playback and verified repairs before delivery.

## Read next
| File | Purpose |
|---|---|
| [WORKFLOW.md](WORKFLOW.md) | Guided milestones, gates, overlap and outputs |
| [MULTI_AGENT.md](MULTI_AGENT.md) | Roles, task dispatch, ownership, dependencies and recovery |
| [RULES.md](RULES.md) | Retained production rules and explicit amendments |
| [docs/COORDINATOR.md](docs/COORDINATOR.md) | Local ledger CLI and its enforcement limits |
| [docs/BENCHMARK.md](docs/BENCHMARK.md) | Fair baseline vs multi-agent comparison |
| [CHANGELOG.md](CHANGELOG.md) | What changed and what was preserved |
| [VALIDATION.md](VALIDATION.md) | Checks performed; live production not yet measured |
| [REFERENCE.md](REFERENCE.md) | Inherited generation recipes and local tools |

## Project layout
Every new project is created automatically with this layout (`tools/init_project.py`
is the single source of truth; a test checks every folder the kit refers to exists):

```
<project>/
  HANDOFF.md        live state: read first when resuming
  1_source/         script/ · voices/ · reference/
  2_library/        characters/ · locations/ · costumes/ · props/ · library.csv · README.md
  3_prompts/        approved scene packets
  4_renders/        frames/ · clips/ · scenes/ · audio/ · edit/
  5_review/         QA sheets · handoffs/ (continuity)
  6_final/          delivered cuts
  logs/             attempts · QA index · approvals · credits
  work/             worker scratch
```

## Requirements and limits
The production helpers target macOS + DaVinci Resolve. Run `tools/check_setup.sh`
when starting production. Model names, API capabilities and
prices in REFERENCE are historical observations: inspect available tools and obtain
current cost preflights before spending. The inherited renderer has format and
frame-rate assumptions; validate an alternative specification before accepting it.

`tools/coordinator.py` uses Python's standard library and POSIX file locking.
It is a local ledger, not an autonomous scheduler or Higgsfield connector. The AI
coordinator dispatches agents and calls the existing connector. Its records support,
but cannot independently prove, media quality or genuine human approval.

The original illustrated PDF and HTML are retained under `docs/legacy/` as historical
guidance. They describe the old sequential workflow; the files above govern this edition.

## Local verification
```sh
python3 -m unittest discover -s tests -v
```
Runs entirely inside this folder (includes the company-account guard tests). No
generation, network calls or Resolve changes are made.

Maintainers only: `tools/verify_baseline.py` compares this kit against the original
source kit it was built from. It refuses to run without `--source <path>` (no stored default) and is
not part of normal setup — new users can ignore it.

## New review and oversight agents
The [dispatch guide](docs/AGENT_DISPATCH.md) explains the three added roles, when they run, and
how visual reviewers divide work. The [visual-review protocol](docs/VISUAL_REVIEW.md) implements
your supplied document. [Review aggregation](docs/REVIEW_GATE.md) detects missing or mismatched
review reports. Start with one reviewer per independent asset; oversight is event-driven.
Example: “Use visual review for this scene, parallelize ready assets within available slots,
and run supervisor/watcher checks only at relevant milestones.” Production approval gates apply.
