# Multi-agent edition — 2026-10-04

## Release — 04 October 2026
v1.5 is the final release, published as `Higgsfield_Resolve_Kit_v1.5_04_October_2026`.

## v1.5 — 2026-10-04 (kit's own project layout)
- New, trimmed project layout: `1_source` · `2_library` · `3_prompts` · `4_renders` ·
  `5_review` · `6_final` · `logs` · `work`. Only folders the kit uses are created.
- Asset library = `2_library/` (characters, locations, costumes, props) with a simpler
  `library.csv` and README. Unused categories, stitch list and extra logs removed.
- Every tool, agent brief, template and doc updated to the new paths; fixed a tool that
  derived the split-audio folder by depth. `tests/test_layout_links.py` fails on any
  broken or old-layout path.
- Existing projects are untouched; the kit never migrates them.

## v1.4 — 2026-10-04 (project layout + asset library)
- New projects get the same layout as the studio project template: all seven asset
  categories, `00_input/data`, asset sheets, continuity grids, dry runs, `04_stitch` with
  `stitch_list.csv`, and the asset/continuity/deliverable/ledger/voice logs.
- Each project's `00_input/image/Asset/README.md` explains how to set up the asset library;
  Step 1 offers to scan the folder and build `logs/assets.csv` for approval.

## v1.3 — 2026-10-04 (Codex support)
- Company-account guard now enforced in **Codex** as well as Claude Code: shared
  `guard/hf_guard.py`, wired by `.codex/hooks.json` and `.claude/settings.json`.
- Guard recognizes Higgsfield tools under any server naming (Higgsfield/higgsfield/plugin-scoped).
- Fails closed: a missing guard file blocks Higgsfield calls in both hosts.
- Attempt logging to the private Google Sheet enabled; README notice added.
- `/start` runs setup + company-workspace check automatically.
- New `tests/test_hosts.py`.

## v1.2 — 2026-10-04 (retest fixes)
- `tools/verify_baseline.py` now requires `--source`; it has no stored default and never
  reads outside this kit unless a maintainer passes a path explicitly.
- Absolute source paths removed from `BASELINE_SHA256.json` and `PROMPT_SYNC_SHA256.json`.
- `VALIDATION.md` commands updated (in-kit tests for everyone; `--source` for maintainers).
- New `tests/test_isolation.py`: fails if the baseline tool runs without `--source` or any
  active file contains an absolute user path. Guard tests no longer leave unclosed files.

## v1.1 — 2026-10-04 (beta-test fixes)
- Self-contained: prompt learning pack and production handbook bundled under `learning/`;
  the prompt skill now points there instead of folders outside the kit.
- README: baseline verification moved to a maintainers-only note; new-user verification
  runs only the in-kit test suite. Setup check points to `tools/check_setup.sh`.
- Company-account guard: reads JSON, MCP content blocks and tabular workspace results
  (previously only tabular); Pocket name + enterprise plan both required.
  Covered by `tests/test_guard.py`.
- Claude Code is the supported production host; `AGENTS.md` bars Higgsfield generation
  from other hosts (e.g. Codex), where the guard isn't enforced.


Derived from `higgsfield_resolve_kit_guided`. `BASELINE_SHA256.json` records every
source file's SHA-256 at copy time. The source folder was not edited.

## Preserved
- Original production executables and render/edit/QA scripts, except the project
  initializer enhanced for isolated multi-agent bookkeeping.
- Prompt skill and PROMPT_TEMPLATE, including realism and fire/prop guidance.
- Verbatim dialogue, character/voice locks, inspected continuity, review evidence,
  explicit paid-generation approvals and new versioned timelines.
- Existing pacing/edit heuristics and renderer constraints. This experiment does
  not silently trade away quality or loosen the edit lint to appear faster.
- Original guide PDF/HTML/images, moved into docs/legacy as historical reference.

## Changed
- Milestone gates replace a global one-step-at-a-time barrier; ready independent
  work overlaps while approvals and true dependencies remain binding.
- Four rotating roles with shared context, bounded worker output, and one editor.
- Same-run approved decisions persist; new scope/version changes are reconciled.
- Separate specification fields, early scratch timing, risk-covered approved tests.
- Single-owner canonical project state; local budget reservations and job ledger.
- Actual outgoing continuity packets, versioned evidence, descendant invalidation.
- Rolling assembly, full playback QA, and explicit repair verification at delivery.
- New templates, role briefs, Claude worker definitions, Codex entry point, and
  an isolated A/B comparison protocol.

See RULES and MULTI_AGENT for exact amended rules. Ledger automation is intentionally
limited: it does not call external services, spawn workers or verify human consent.
Do not confuse local unit tests with proof of a production speed or quality gain.

## Prompt guidance sync — 2026-10-04 (after initial kit creation)
Imported the updated upstream prompt skill byte-for-byte, including its conditional 48-lesson
PRODUCTION LEARNING LAYER and provisional evidence status. Merged only the upstream RULES
H introduction and H7 exclusion/repair refinement; retained all multi-agent amendments.
Updated prompt skeletons, scene/QA packets, production brief and pre-submit workflow to use
reference roles, causality, world/body/screen geography, hand/prop states, two-pass timing,
audio contracts, image/edit structures and evidence-based repair. Coordination code unchanged.
The original creation snapshot remains in BASELINE_SHA256.json. The newer read-only upstream
snapshot and import hashes are in PROMPT_SYNC_SHA256.json. The original has evolved since
creation; an old-snapshot difference is expected and is not evidence this sync modified it.

## Visual reviewer, workflow supervisor and agent watcher — 2026-10-04
Added three role briefs and Claude worker definitions. Preserved the user's reviewer DOCX and
extracted source; mapped all nine rules, efficient review, three decisions and bounded repairs
into a reusable scene record and evidence protocol. Added optional read-only review aggregation
with asset/packet checksum binding and fail-closed coverage checks; this does not inspect pixels.
Defined capacity-aware per-asset review parallelism and optional three-lane complex-asset review,
with one lead. Supervisor/watcher run only on defined events; existing director/editor ownership
and paid-generation approval remain. Source original kit and prompt skill are unchanged by this
update. No new production run, paid generation, or scheduled monitoring was started.
