# Workflow supervisor — <run / event / audit ID>

Audit time with timezone:
Reviewer:
Trigger: setup / test release / dependency release / failure / version change / resume / cut milestone
Assigned scope and proposed action:
Run / approved plan / packet versions:
Manifest snapshot time or digest:
Task-board / ownership snapshot:
Cut/export version (if relevant):
Previous report and changed inputs:
Recommendation: **OK / ATTENTION / BLOCK_RELEASE**

This is an advisory gate audit, not human approval, media QA acceptance or a release command.
All observations apply only to the listed input versions; the director rechecks changes before use.

## Gate evidence

| Check | verified / failed / not applicable / unverified | Exact source, version and reason |
|---|---|---|
| Human plan/scope/spec/cap/method approval | | |
| References/masters and applicable tests/release | | |
| Dependency QA plus actual observed parent handoff | | |
| Version changes and affected descendant review | | |
| Budget commitments and full-cost preflight | | |
| Unknown submissions and financial reconciliation | | |
| Required review coverage and unresolved disagreements | | |
| Tracked repairs and exact-export verification | | |
| Canonical writer and exclusive editor ownership | | |
| Full-cut playback/captions/mix/spec and approval status | | |

Not applicable requires a reason. Missing evidence remains unverified. Readiness, a job's
completion, a reviewer PASS, and build success do not substitute for the required manual gates.

## Budget snapshot

- Approved cap and evidence:
- Settled actual charges:
- Outstanding reservations (including uncertain requests):
- Proposed additional unreserved costs and preflight evidence:
- Total exposure = settled + outstanding + proposed additional:
- Remaining capacity after proposal = cap − total exposure:
- Reservations already covering proposed tasks (excluded from proposed additional):
- Unresolved provider charges or limits and required reconciliation:

## Actionable findings

| ID | Severity: blocker / warning / information | Observed fact and evidence | Affected task/branch/version | Owner | Exact next action / evidence needed to clear |
|---|---|---|---|---|---|

Release hold recommendation and scope:
Independent work that can continue:
Global stop condition, if any, and evidence:
Unverified questions and owner:
Next audit trigger (event, not polling interval):

## Coordinator disposition (director records separately)

Recommended canonical updates / approvals still needed:
Report path for director reconciliation:

The supervisor does not fill in approval on anyone's behalf or alter canonical records. Store
this local report outside the paid-job ledger. For unchanged inputs/findings, reference the prior
report; produce a new copy only when an explicitly required milestone/archive record needs it.
