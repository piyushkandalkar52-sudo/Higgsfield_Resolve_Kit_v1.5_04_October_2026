# Asset library

Approved reference images for this project. Prompts, references and continuity checks
all use these, so fill the library before planning.

## Folders
| Folder | Put here |
|---|---|
| `characters/` | Faces, full body and turnaround views — one set per character |
| `locations/` | Places where scenes are staged (throne room, alley, palace exterior) |
| `costumes/` | Outfit changes during the story (ballgown, cloak, disguise) |
| `props/` | Objects that matter to the story (letter, ring, sword) |

**File names:** `<Name>_<variant>_<view>.png` — e.g. `Amelia_wedding_front.png`,
`ThroneRoom_night_wide.jpg`. Use the same names as the script.

## `library.csv` — one row per image
| Column | Example |
|---|---|
| `asset_id` | `CHR-AMELIA-01` (CHR / LOC / COS / PRP + name + number) |
| `name` | `Amelia` |
| `category` | `characters` |
| `variant` | `wedding` |
| `view` | `front` / `side` / `back` / `wide` / `close` |
| `file` | `2_library/characters/Amelia_wedding_front.png` |
| `scenes` | `S01;S04` |
| `approved` | `yes` once you have signed it off |
| `notes` | continuity notes (scar on left cheek, ring on right hand) |

## Let the kit do it
Say **"Scan my library and build library.csv."** The coordinator lists what it found,
proposes the rows and asks you to approve them. Uploading references to Higgsfield happens
later, after the plan and spend are approved; their media ids are recorded in `HANDOFF.md`.
