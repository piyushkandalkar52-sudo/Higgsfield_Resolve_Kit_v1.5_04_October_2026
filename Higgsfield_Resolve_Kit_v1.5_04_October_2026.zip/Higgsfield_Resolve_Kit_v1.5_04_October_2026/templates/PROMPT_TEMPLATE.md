# Prompt skeletons (fill in from the frame and the plan; then run the prompt skill's checklist)

## Preparation and mechanical preflight
Use the updated prompt skill's PRODUCTION LEARNING LAYER before filling these skeletons.
Keep this preparation in the scene packet; deliver one complete prompt in the required format.
- One-sentence dramatic change; causal chain; source facts versus approved adaptation.
- Last accepted state; protected elements; permitted changes; reveal boundaries.
- For each exact attached tag: controls / must not control / applicable shots.
- World position, anatomical side and screen position distinguished; background valid per camera.
- Action states, prop owner/count/contact through occlusion, and each hand's availability.
- Two timing passes: contiguous shot windows sum to duration; measured speech plus action fits.
- Audio mode, one speaker per voice tag, exact lines, separate accent/delivery, no contradictory bans.
- Output format/count, JSON validity if required, exact attached tags, current tool length limits.
- Ending state is usable; required crop is safe at start, action peak and end.
Settings belong in tool controls; STYLE quality cues remain wording. Reference role/exclusion
clauses refine the generic identity locks below. Retain approved F3/J2 constraints and gates.

Fixed realism lines (adapt content to the actual approved scene; keep required phrases):
- **OPTICS:** "Real lens behaviour: real lens bokeh, natural depth of field, focus held on the eyes and the bridge of the nose in every close-up, background falling into soft round bokeh from the practical lights, gentle natural vignetting, no drift mid-segment."
- **CAMERA (operator):** "Handheld stabiliser or light handheld, at chest-to-eye height, about 1 m from the actors, like an operator on a light shoulder rig: a small constant breathing float, micro-corrections, short physical push-ins of about 20 cm."
- **Eyes:** "Living eyes: wet surface, small soft warm pinpoint catch-lights, iris colour clearly visible."
- **LIGHTING ends with:** "Realistic lighting ratio between key and fill; face never overexposed, skin detail still visible in the brightest areas."
- **STYLE:** "Ultra-HD 4K, 30fps, cinematic realistic portrait texture. Live-action period drama shot on a real set, <place and era>: photoreal people with natural, imperfect skin, real fabric weight (<fabrics>), fine organic film grain, true lens softness at the frame edges, gentle highlight roll-off, rich but natural colour."
- **Face lock:** "Faces stay stable and true to the references in every shot: same eye shape, nose, jawline. Eyes hold steady on their target."
- **Fire lock (when there are flames):** "All paper, fabric and hair stay intact; flames stay inside the hearth, lanterns and candle holders."
- **Audio lock:** "Only the spoken line and quiet room tone; no music, no breathing, gasping, sighing or sobbing sounds."

---

## A. Base clip with on-camera dialogue (omni_reference)
```
SCENE CONTEXT
<When, where, era. What happens. Exactly N people.>

ACTIVE REFERENCES
@image1: <Name>, <age>, <hair>, <costume>, <signature detail>. Controls <identity/costume>; excludes <pose/expression/light if not approved>; applies to <shots>. Match those assigned features.
@audio1: <Name> voice identity only; <approved accent and delivery separately>.
@image2: <Name>, … Controls <features>; excludes <unwanted influence>; applies to <shots>. Silent in this clip.
@image3: the <location>. Controls <architecture/geography>; excludes <camera or lighting if separately directed>; applies to <shots>.

LOCATION MAP
<Stable architecture and world positions; body left/right separately from frame left/right. Background per camera. Flammable props: distance + "intact".>
<Worn-material line: scuffs, soot, worn fabric, dust.>

FIRST FRAME / BLOCKING
<Match the approved start frame exactly for start-frame chaining [E5]. State positions, each hand, prop ownership/count/state and gaze. Do not repeat an already completed action.>

FORMAT MODE
Timed multishot. Cuts only at the specified points; the camera does not cut on its own. Fast pace, no pause longer than half a second between words.

OPTICS
<fixed line>

CAMERA
<fixed operator line>
<Opening continuity composition for E5; no dialogue on a wide. First word begins only when the approved close shot starts [F4].>
<t0>s to <t1>s — <FOV, framing, camera position/move, visible causal action, emotional change, fragile continuity fact>
<t1>s HARD CUT
… (contiguous windows summing to duration; retain approved F3 constraints) …
<Final window: readable ending state with a usable hold; no extra plot action crammed in.>

ACTION
<Causal trigger; preparation → contact → movement → release → result. Track props through hiding/reappearance. Speaker lips match exact words; non-speakers stay silent.>

PERFORMANCE
<Emotional change tied to trigger; one or two dominant visible cues per beat, not a gesture on every word. Apply approved acting/intensity notes and subtle-shock rules where relevant.>
<Name>: wants …, holds back …, eyes …, intensity N/10.
<Skin line per character, flaws "faint" / "subtle".>
<Eyes line>

LIGHTING
<Key source + side, warm/cool word; fill almost none; rim. No Kelvin.> <fixed-look guard if the show has one, e.g. "every hallway light switched off; no lamps, no warm bulbs, no warm bokeh anywhere in frame" [R-H10]> <fixed ending>

AUDIO
Mode: <exact dialogue / voice identity reference>. @audio1 maps only to <Name>; accent <approved accent>, delivery <note>.
From <t>s, <Name> (@audio1), <tone>, lips synced: "<exact line>"
Only this line is spoken. <audio lock> <rain scenes: "No thunder." [R-I5]>

STYLE
<fixed STYLE>

POSITIVE LOCKS
Exactly N people, no reflections or duplicates. <face lock> <costume / prop / safety locks>
<fire lock if flames>
```

## B. Extension clip (video_extension; parent = previous job id; no audio_references)
```
SCENE CONTEXT
Continue the video straight on from its last frame. <What happens next.>

ACTIVE REFERENCES
@image1: … (character sheets only; a voice described in words if anyone speaks)

LOCATION MAP (the video's closing camera)
<Exactly what the parent's last frame shows.>

FIRST FRAME / BLOCKING
Exactly the video's last frame: <positions as visible>.

FORMAT MODE
Timed multishot … <movement = ONE continuous uncut shot>

OPTICS / CAMERA
0.0s to 0.6s — the same shot as the video's last frame, continuing seamlessly.
0.6s HARD CUT
…

(PERFORMANCE / PHYSICS / LIGHTING / AUDIO / STYLE / POSITIVE LOCKS as in A)
```

## C. Image edit and new image (separate structures; no video timeline)
```
BASE IMAGE AND PURPOSE
<Exact base image/tag and why this edit is needed.>
SINGLE CHANGE
<One precise change and replacement description.>
REFERENCE ROLES
<Each attached tag: controls / exclusions / scope.>
PROTECTED ELEMENTS
<Identity, pose, architecture, light, composition, materials and props to preserve.>
SUCCESS CRITERIA
<Observable correct result and comparison evidence. Unseen geometry is designed, not recovered exactly.>
<Physical light, natural skin/materials and approved image tone; aspect in tool settings.>
```
New image: specify purpose, reference roles, identity/age, pose/expression, composition,
environment, physical light/exposure, materials, props and targeted exclusions. A character
sheet can request approved front/side/back views and head close-ups; no timed video shots.
For a drifting accessory, propose designing it separately before fitting it to the locked base.

## D. Narration line (seed_audio)
`prompt` = the exact line only (spell numbers out); `medias` = `audio_references` with the narrator's sample; `format: wav`, `sample_rate: 48000`; `speech_rate: +10` to fit a tight window.

## E. Silent visual under external narration
Use A's applicable visual blocks with a silent audio contract: no generated dialogue,
narration or voice-over; no characters mouth the external narration. Set generation audio
according to the approved silent-mode settings. External narration remains its own exact-line job.

## Review and repair handoff
Review story → causal action/geography → identity/costume/props → performance → timing →
audio → text/crop → polish. Record observed defect separately from its suspected cause,
exact frame/interval, protected elements, smallest proposed repair and rollback version.
Two failed wording changes trigger a method-change proposal, not more negatives or automatic
regeneration. Only the director can submit approved paid work.
