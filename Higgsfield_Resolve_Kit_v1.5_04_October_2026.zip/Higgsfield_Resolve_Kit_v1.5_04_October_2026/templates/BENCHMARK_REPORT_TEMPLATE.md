# Workflow comparison — <run>
Arm: A guided / B multi-agent
Mode: orchestration-only / full-workflow
Script/input hashes: · Scope: · Planned duration:
Plan version: · Spec/model versions: · Budget cap:
Actual workers: · Resolve project: · Output folder:

| Milestone | UTC timestamp |
|---|---|
| Start | |
| First approved test | |
| First assembled scene | |
| First reviewable cut | |
| Final accepted cut | |

| Measure | Value / unavailable | Evidence |
|---|---|---|
| Wall elapsed minutes | | |
| Excluded wait interval union | | |
| Adjusted elapsed minutes | | |
| Accepted finished minutes | | |
| Total actual credits (all types/attempts) | | |
| Rerun credits (subset of total) | | |
| Agent effort / tokens | | |
| User interruptions | | |
| Review rounds | | |
| Late continuity defects | | |
| Same quality bar passed | | |

Quality reviewer/rubric and accepted issues:
Order/learning/service conditions that affect comparison:
Comparison conclusion (incomplete until both arms finish):
