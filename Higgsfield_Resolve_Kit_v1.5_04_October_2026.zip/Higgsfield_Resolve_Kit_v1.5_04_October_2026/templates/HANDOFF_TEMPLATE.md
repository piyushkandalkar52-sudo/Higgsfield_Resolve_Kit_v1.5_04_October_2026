# HANDOFF — <SLUG> · multi-agent edition

## CURRENT RUN
| | |
|---|---|
| **Current scene / part** | |
| **Latest approved clip** | (from `logs/qa_index.csv`) |
| **Jobs still running** | none |
| **Next action** | |
| **Blocker** | none |

_Update after every submit, take review and build [R-A7]. Finished run reports go to `logs/handoff_history.md` [R-A8]._

> **For the coordinator:** this is the human-readable summary of this project.
> `logs/production_manifest.json` owns task/dependency/budget state; reconcile it first.
> Workers return reports; only the coordinator updates this file and shared CSV logs. Read it first on every resume; update it
> after every decision, batch, QA pass and build. How to work is in the kit's `CLAUDE.md`,
> `WORKFLOW.md` and `RULES.md`; this file only says **where this project stands**: current state
> only. Older run reports: `logs/handoff_history.md`.

**Project folder:** `projects/<SLUG>/` · **Resolve project:** `<name>` · **Started:** <DATE> · **Last updated:** <DATE>

## Progress
`Step 1/11 · Project ▸ ✔0 ●1 ○2 ○3 ○4 ○5 ○6 ○7 ○8 ○9 ○10 ○11`

| Step | Status | Note |
|---|---|---|
| 0 Setup | ☐ | |
| 1 Project | ☐ | |
| 2 Read & story | ☐ | |
| 3 Decisions | ☐ | |
| 4 Plan & cost (approved?) | ☐ | |
| 5 References | ☐ | |
| 6 Test clips (approved?) | ☐ | |
| 7 Production | ☐ | |
| 8 Assembly | ☐ | |
| 9 Whole-cut QA | ☐ | |
| 10 Delivery | ☐ | |
| 11 Review rounds | ☐ | |

## ⚠ In flight right now
| Job id | Clip | Submitted | Status |
|---|---|---|---|
| | | | |
Poll these with `jobs_wait` before submitting anything new. Never resubmit a pending job.

---

## Project rules (on top of the kit's RULES.md)
Persistent preferences the person states for this project ("always…", "from now on…"), with date:
1.

## 1. Story
- **Script source:** `1_source/script/<file>`
- **Previous sequence ends with:**
- **This sequence starts with:**
- **How the story ends:**
- **Scope of this run:**

### 1.1 Lines (verbatim, the QA reference)
| ID | Speaker | Line (exact) | On camera / V.O. | Clip | Verified (transcript + lips) |
|---|---|---|---|---|---|
| D01 | | | on camera | | ☐ |
| V01 | | | V.O. | | ☐ |

## 2. Decisions (asked and answered)
| Date | Question | Answer | Consequence |
|---|---|---|---|
| | Scope | | |
| | Output spec + budget cap | | |
| | **Continuity method: extension / keyframe / mix** (confirmed for new runs/changes) | | |
| | Reuse of earlier outputs | | |
| | Voices (on-camera / narration) | | |
| | Edit pace · flashback look | | |
| | Wording changes | | |

## 3. Locks
### 3.1 Look table (from the sheets)
| Character | Sheet file | Hair · costume · signature detail | Voice line for prompts | Acting sheet (temperament, tension, eyes) |
|---|---|---|---|---|
| | | | | |

### 3.2 Geography per location (master camera)
| Location | Plate | Who is where, facing whom | Notes |
|---|---|---|---|
| | | | |

## 4. Higgsfield media ids (reuse, never re-upload)
| What | Local file | media_id / job id |
|---|---|---|
| | | |

## 5. Keyframes / new sheets
| Item | Made from | Job id | File | Approved |
|---|---|---|---|---|
| | | | | ☐ |

## 6. Generation
### 6.1 Clip plan (from PLAN.md)
| Clip | Scene | Type (STILL/MOVE) | Dur | Source (base / ext of X / keyframe) | Lines | Prompt file |
|---|---|---|---|---|---|---|
| | | | | | | |

### 6.2 Attempts (every submit, failures included; never delete rows)
| Clip / attempt | Job id | Mode | Parent | Status | File | Words | Lips | Look/blocking | Verdict | Reason | Evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | approved / needs_repair / rejected | | `5_review/<SUB>/<clip>_sheet.jpg` + transcript |

The coordinator writes the same verdict as one row in `logs/qa_index.csv` the moment the take is reviewed [R-K4].
Review cuts may use approved / needs_repair takes [R-J10]. Final delivery requires
verified repairs or explicit acceptance of permitted remaining issues; the build script alone does not prove this.

## 7. Cut
- **EDL:** `4_renders/edit/<SLUG>_edl_vN.json` · **Captions:** `…_captions_vN.srt`
- **Resolve timelines:** `<SLUG> vN` / `<SLUG> vN CAPTIONED` · **Preview:** `6_final/…`
- **Length:** · **Caption count vs script:**

## 8. Known issues (timestamped)
| Time | Issue | Severity | Fix plan / cost |
|---|---|---|---|
| | | | |

## 9. Credits
| When | Balance | Spent | On what |
|---|---|---|---|
| start | | — | |
**Cap:** · **Spent so far:** · **Rejected takes:**

## 10. Review rounds
| Round | # | TC | Clip | Note | Decision | Cost |
|---|---|---|---|---|---|---|
| | | | | | | |

## 11. Next steps
- [ ]

## 12. Session log (newest first, one line each)
| Date time | What happened |
|---|---|
| <DATE> | Project created |

When a run or part is finished, move its full report (deliverables, issues, QA notes) to
`logs/handoff_history.md` and keep one line here [R-A8].

## 13. Multi-agent run control
- **Run ID / approved plan version:**
- **Scope/spec/budget/continuity approval evidence:**
- **Decision/reference versions:**
- **Coordinator / current editor:**
- **Actual worker count and host:**
- **Manifest:** `logs/production_manifest.json` (initialize after confirmed budget/run ID)
- **Settled credits / outstanding reservations / cap:**
- **Unknown submissions requiring reconciliation:**
- **Next user gate / next ready tasks:**

| Task ID | Owner | Packet/version | Dependencies | Returned report | Next action |
|---|---|---|---|---|---|

Use `work/<task-id>/` for worker drafts; `3_prompts/` for approved packets;
`5_review/handoffs/` for observed continuity. The coordinator merges reports into the
manifest and existing QA/approval logs; the CLI does not automatically render this
handoff or CSVs. Reconcile these views at every submit/review/build and before pause.

## 14. Repair obligations and final acceptance
| Issue | Take/cut version | Required repair / accepted exception | Verification evidence | Closed by |
|---|---|---|---|---|

## 15. Comparison
- Benchmark arm/mode: · Separate baseline folder / Resolve project:
- Report: `BENCHMARK_REPORT.md`; event intervals: `logs/benchmark_events.csv`
- Full-cut playback with sound: verified / unverified, evidence:
- Same acceptance bar as comparison arm: yes/no, explanation:

## 16. Review and oversight state
| Local task / asset version | Assigned role / worker | Status / waiting reason | Checkpoint + basis | Report path |
|---|---|---|---|---|

- Named visual lead / coverage gaps / source reference versions:
- Defect episode IDs and repair counts (persist across agents/takes):
- Latest supervisor recommendation / affected release hold / director action:
- Latest watcher snapshot / changed actionable finding / unresolved evidence:
- Actual active slots / exclusive editor owner:

Local tasks live in work/ and this coordinator-owned summary, not fake generation-ledger jobs.
