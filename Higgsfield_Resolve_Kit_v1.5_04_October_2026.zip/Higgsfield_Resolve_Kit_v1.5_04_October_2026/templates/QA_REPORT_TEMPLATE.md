# QA — <clip/take/version>
Reviewer: · Plan/reference version: · Media path:
Verdict: approved / needs_repair / rejected

| Check | pass / fail / not applicable / unverified | Evidence and timestamp |
|---|---|---|
| Words vs exact line IDs | | |
| Lip sync through playback (motion score is supporting evidence only) | | |
| Identity, costume and intra-clip geography | | |
| Props and physical action | | |
| Incoming join / outgoing continuity | | |
| Light and image artifacts | | |
| Motion through playback | | |
| Audio intelligibility, levels, unwanted sounds | | |
| Applicable fire/prop and safety rules | | |

## Repairs
| Issue ID | Severity | Exact issue/time | Edit / regenerate proposal | Verification evidence |
|---|---|---|---|---|

Review-cut use permitted: · Final-cut use permitted:
Observed continuity handoff path:
Missing verification and next action:

No passed checkbox without evidence. Silence makes spoken-word checks not applicable,
not automatically passed. Full-cut QA additionally checks story/performance, caption
text/timing/placement, mix and delivery specification through complete playback.

## Production learning review order
Story meaning → causal action/geography → identity/costume/props → performance → timing →
audio → text/crop → visual polish. Record pass / needs repair / unclear per category.
Keep the observed defect distinct from a suspected prompt/reference cause. Record the exact
result/interval approved, protected elements and rollback target. Job completion is not approval.
After two unsuccessful wording revisions of one defect, recommend a method change for director
review rather than a third negative clause. Recheck all protected elements after repair.
