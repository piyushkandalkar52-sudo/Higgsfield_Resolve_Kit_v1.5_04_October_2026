# Agent watcher report — <task/check ID>

Run / assignment version:
Reporter / report version / unique output path:
Trigger: handoff / completion / missed expected checkpoint
Check started / completed (UTC):
Snapshot observed-at / received-at (UTC):
Actual host capacity / active agents / watcher role rotation:
Expected checkpoint / basis / advisory time:
Prior report and changed evidence, if any:

## Observed task health

| Task / worker | Promised output / version / owner | State | Evidence path or host/job reference / observed-at | Blocker / next checkpoint | Unknowns |
|---|---|---|---|---|---|
| | | | | | |

States: `working`, `tool-running`, `render-wait`, `user-wait`, `dependency-wait`, `no-signal`.
Identify a dominant blocker and secondary wait if needed. Stale or contradictory evidence is
unknown; a missed checkpoint alone does not establish abandonment. Output existence is not QA.

## Actionable findings

| Finding ID / category | Evidence / affected task and artifact | Impact on current work | Proposed director action | Prior finding / change |
|---|---|---|---|---|
| | | | | |

Categories: duplicate ownership / confirmed abandoned local task / repeated same-error loop /
stale snapshot requiring one fresh observation. Write `None` when no actionable finding exists.
For abandoned tasks, cite confirmed stopped/failed host status, missing required output and absence
of a documented wait/handoff. Otherwise use `no-signal`. For repeated loops, cite the actual attempts.

Outstanding remote jobs or uncertain submissions requiring director reconciliation before reassignment:
In-flight tools / exclusive editor ownership requiring reconciliation:
Evidence routed to director for workflow-supervisor review, if relevant:
Single next eligible action / responsible owner (proposal only):

## Measurement, when available

| Measure | Value or unavailable | Evidence / interval / limits |
|---|---|---|
| Watcher check elapsed and agent effort overhead | | |
| Review-queue wait | | |
| Confirmed avoidable idle interval union | | |
| Rework time / rerun cost | | |
| Time to final accepted cut, including coordination and review | | |
| Same accepted-quality standard / unresolved QA | | |

Do not add overlapping waits as elapsed production delay. No latency-based quality judgments,
worker rankings or arbitrary speed scores. This snapshot is advisory, not proof of speed gains.
Check complete: no standing watcher, follow-up polling, automatic intervention or scheduled task.
