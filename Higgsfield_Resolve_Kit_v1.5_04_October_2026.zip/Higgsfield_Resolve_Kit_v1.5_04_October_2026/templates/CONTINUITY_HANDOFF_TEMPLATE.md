# Observed continuity handoff — <task/take/version>
Parent remote job ID: · Source media: · Plan/reference versions:
Reviewer: · Reviewed at (UTC): · Evidence/timecodes:
Actual outgoing frame file: · Extraction time:

| State | Observed fact |
|---|---|
| People in frame / out of frame | |
| Position, facing, eye line, screen direction | |
| Costume, hair, injuries, dirt | |
| Props/counts/possession and each hand | |
| Geography and camera framing | |
| Light, weather and time | |
| Unfinished action and emotional state | |
| Audio tail / unfinished line | |

Outgoing frame sharp and usable: yes/no, evidence:
Parent take accepted: yes/no, QA evidence:
Unresolved defect / planned repair that could change this state:
Successor may be released: yes/no, reason:

This records the generated output, not the intended prompt. A parent replacement
invalidates this handoff until reviewed again. Never invent obscured state.
