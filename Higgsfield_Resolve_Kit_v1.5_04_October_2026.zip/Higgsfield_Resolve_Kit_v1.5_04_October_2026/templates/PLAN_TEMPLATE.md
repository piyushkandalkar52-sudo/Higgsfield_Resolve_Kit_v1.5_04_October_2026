# PLAN — <SLUG> · <scope>

**Status:** DRAFT — no paid submissions before explicit approval. **Date:** <date>
**Run ID:** <id> · **Plan version:** <version> · **Approved version/evidence:** <pending>
**Model:** <confirmed model> · **Resolution:** <value> · **Aspect ratio:** <value>
**Frame rate:** <value> · **Timeline dimensions:** <value> · **Budget cap:** <N credits>
**Renderer feasibility:** <verified / blocked; existing pipeline assumes 1440×1080, 24 fps>
**Dialogue audio:** on · **Silent-clip audio:** off
**Continuity method:** <extensions / keyframes / mix> · **Reuse:** <approved policy>

Approvals persist for this same run and unchanged approved scope/version. A new run or material
change to scope, spec, budget or continuity requires renewed explicit approval. Workers cannot
spend, alter locks or approve their own outputs. See `MULTI_AGENT.md` for task protocol/tooling.

## Story position
- **Previous sequence ends with:**
- **This sequence starts with:**
- **How the story ends:**
- **Where this run ends:**
- **Full-script read completed by coordinator:** <source/version>

## Scenes and reference gates
| Scene | Place / time / state | Story function | Target length | Master version | Look approval | Other prerequisites |
|---|---|---|---|---|---|---|
| S01 | | | | pending | pending | |

Every scene requires a checked, approved master matching its state. A shared location or different
scene ID does not establish independent production. Extension-chain bases also need checked masters.

## Clip list
| Clip | Scene | Type | Duration | Shots (~2 s; F3 applies) | Continuity source and version | Lines | Dependency chain | Ready condition |
|---|---|---|---|---|---|---|---|---|
| A1 | S01 | STILL | 10 s | <4–5 shots> | approved master <version> | D01 | A | master + applicable test gates |
| A2 | S01 | STILL | 8 s | <coverage> | parent A1 <accepted take/version> | D02 | A | parent QA + observed state |

Use STILL 8–10 s and MOVEMENT 5–6 s, respecting C2 clip limits and F2 coverage. Preserve the
existing F3 pacing and J2 real-shot-boundary restrictions. Do not mix arbitrary durations or waive
renderer/lint limits because a style preference was selected.

## Look and performance locks
| Character | Scenes | Sheet/version | Costume / look / day | Voice/version | Acting habits |
|---|---|---|---|---|---|

## Acting notes (per line)
| Line ID | Exact approved wording | Wants | Holds back | Eyes | Intensity |
|---|---|---|---|---|---|

## Narration (voice-over)
| ID | Exact approved line | Over clip(s) | Target window | Reference/version | Timing check |
|---|---|---|---|---|---|

## Scratch timing before paid generation
**Artifact:** <local placeholder cut/timing table> · **Speech source:** <existing/local scratch>
**Timing measured or estimated:** <state explicitly> · **Reviewer:** <role>
| Beat / line | Natural spoken duration | Picture window | Reaction / transition allowance | Finding / fix |
|---|---|---|---|---|

Check opening clarity, natural line fit, emotional turns, reactions, transitions and ending. No paid
image/audio/video generation for this pass. If speech cannot be measured, mark provisional timing
and identify the test that blocks affected production until it is verified.

## Risk-based test matrix
Default: one test per scene. Any shared coverage or additional tests requires explicit approval
of this matrix; each scene still needs its own reference/look gate.
| Test | Scene(s) covered | Risk / hypothesis | Required references | Acceptance evidence | Production tasks blocked | Reusable final clip? |
|---|---|---|---|---|---|---|
| T01 | S01 | <identity, lip sync, interaction, geography, prop, extension/seam> | | | | |

**Test coverage approval:** <pending/evidence>
**Release policy:** <default: all planned tests approved before production / explicitly approved rolling scene release>
**Rolling release scope/evidence:** <if approved; references + applicable tests + timing must pass>

## Roles and dependency-driven run order
Maximum four active agents including the coordinator. Rotate duties; do not allocate seven
permanent agents. Use fewer workers when the remaining work is inherently sequential.

| Role | Owner | Duties now | Later duties | Owned artifacts |
|---|---|---|---|---|
| Coordinator/director | | Plan, approvals, reservations, ALL paid submissions | Reconcile jobs/cost/versions | Manifest, shared logs, HANDOFF |
| Story/continuity | | Full story, asset audit and timing/coverage | Shared locks and observed handoffs | Assigned task/evidence files |
| Production | | References and prompt proposals | Ready chains / voice preparation | Assigned task files |
| QA/editor | | Independent QA and scratch timing | Rolling edit and final playback | Evidence, EDL/SRT/Resolve; sole editor |

- **Ready independent tasks:** <prerequisites and exact versions, not just different scene labels>
- **Strict sequential chains:** <including dependencies that cross scene IDs>
- **Priority path:** <longest dependency chain / high-risk prerequisite>
- **Overlap:** <QA ready outputs + prepare prompts + VO + rolling assembly>
- **Single editor:** <owner; no concurrent Resolve/shared-data writes>
- **Agent/service concurrency limits:** <verified limits>

## Observed end-state handoff contract
For each accepted parent record source clip/take/job/version, approved extracted endpoint or
keyframe, people/positions, screen direction, costumes, props/hand state, action, light, out-of-frame
people/entry direction and unresolved issues. Child prompts are finalized from this observed state.
Replaced parents or masters invalidate affected descendants until revalidated. Flawed-master
regeneration follows E13. Never submit against a stale or unreviewed parent version.

## Cost (current get_cost preflight)
Historical approximate prices are not approval evidence. Include references, tests, production,
voice, and repairs without counting a test reused in production twice.
| Item | Quantity / duration | Current unit basis | Credits | Preflight evidence |
|---|---|---|---|---|
| Test video | | | | |
| Remaining video | | | | |
| Narration | | | | |
| Sheets / masters / keyframes | | | | |
| Rerun reserve 30% | | | | |
| **Total including reserve** | | | | |

**Cap:** <N> · **Actual charges:** <N> · **Outstanding commitments:** <N>
Coordinator reserves before submission: actual + outstanding + proposed cost ≤ cap. Reconcile
charges without double counting. Stop submissions on cap/429; never duplicate pending jobs.

## Rolling assembly and acceptance
- Assemble approved scenes as they arrive, with provisional cuts clearly labelled.
- Existing build checks remain unchanged. A tool accepting `needs_repair` does not prove repair.
- Single editor verifies specified repairs and supported format before final build.
- Review a frozen preview version in parallel for picture/continuity and speech/audio/captions.
- Final gate: complete playback with sound, correct dialogue/captions, valid joins, no unresolved
  required repairs or continuity/dialogue failures. Record cosmetic and explicitly accepted issues.
- If playback is unavailable, record it as unverified and obtain review before claiming a pass.

## Explicit exceptions and open questions
| Beat / rule | Requested exception | Tool feasibility | User approval evidence | Acceptance check |
|---|---|---|---|---|

## Proposed wording changes
| ID | Source wording | Proposed wording | Reason | Approval evidence |
|---|---|---|---|---|

## Benchmark choice
See `docs/BENCHMARK.md`. Select **orchestration-only** to isolate scheduling/agent effects while
holding production gates constant, or **full enhanced workflow** to compare the whole revised
process. Record elapsed time, agent effort, generation wait, credits, rework and quality findings.
Do not present estimated speedup as measured improvement.

## Review and oversight allocation
- Actual host capacity / simultaneous worker assignments:
- Visual reviewer per asset or explicit specialist lanes / named consolidation lead:
- Scene record / frozen asset/reference versions / coverage matrix:
- Editor-owned audio/caption/final-cut checks (no duplicated full visual pass):
- Supervisor milestone triggers and assigned report paths:
- Watcher checkpoints, evidence sources and task-specific expectation basis:
- Defect IDs / targeted repair count / changed-approach count / escalation owner:
- Benchmark review queue, review/consolidation/oversight effort and escaped defects:
