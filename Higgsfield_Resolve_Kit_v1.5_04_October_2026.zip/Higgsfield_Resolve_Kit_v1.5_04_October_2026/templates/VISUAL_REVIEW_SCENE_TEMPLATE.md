# Visual review scene record — <scene ID / version>

Director owns the canonical record. Workers propose changes in assigned task paths.
Keep only scene-relevant details; update changed fields instead of rebuilding every shot.

- Run / approved plan / script / direction versions:
- Named visual review lead / assigned workers and lanes / actual active agent count:
- Scene record path/version:
- Story span: opening situation → key change → exit state; protected reveals:
- Whole scene/sequence read (path, span, version); whole-script planning context reference:
- Participants: each person's visible / offscreen / arriving later / concealed status and location;
  unresolved identity/count remains unresolved:
- Geography: stable landmarks, positions, listener hearing range, entrances, routes, later action space:
- Look anchor and reference roles: identity / wardrobe / architecture / blocking / lighting / previous state:
- Reference files/media IDs, immutable versions and actual digest or version-set identifier:
- Inherited state: relevant presence, wardrobe, hands, props, injuries/wetness, emotion:
- Authorized changes / last accepted baseline / parent take/version and actual endpoint path/time:
- Constraints: generation mode, audio mode, duration, delivery size, crop, timing:
- Opening wide required? yes/no; packet/approval reference for no:
- Closing wide required? yes/no; packet/approval reference for no:
- Open issue: consequential uncertainty, repair or explicit exception only:

## Asset review — <asset ID / immutable version>

- Media path/digest or immutable version ID:
- Structured-merger binding if used: asset_id / asset_version / actual asset SHA256 / scene-packet SHA256:
- Scene record / script / reference version-set reviewed (must match across lanes):
- Actual coverage: whole image / playback speed and ranges / sample timestamps / intended viewing size:
- Actual opening and closing boundary evidence:
- Required opening wide evidence / required closing wide evidence:
- Cuts, contact moments and crop-safety opening/peak/ending evidence:
- Missing evidence and limitations (do not claim temporal/audio checks from stills):
- QA/editor-owned audio/dialogue/lip-sync checks: report link or pending; not part of visual PASS:

| Source rule | Assigned owner | PASS / defect ID / N/A with reason / unverified | Actual evidence location/time |
|---|---|---|---|
| 1 Whole-scene setup | | | |
| 2 Natural film staging | | | |
| 3 Blocking/readability | | | |
| 4 Scene look | | | |
| 5 Photographic realism | | | |
| 6 Both required wides and actual boundaries | | | |
| 7 Physical/emotional continuity | | | |
| 8 Action/performance | | | |
| 9 Reference roles/narrow repair | | | |
| Applicable H5/L checks | | | |

## Consolidated result — named lead <name>

- Decision: PASS / REPAIR / NEEDS REVIEW:
- Lane report paths and cross-lane conflict resolution:
- All applicable nine-rule coverage complete? Evidence gaps:
- Affected dependencies / downstream use blocked? Why:
- Next eligible action / exact evidence or decision needed:
- Director acceptance and editor evidence links (visual PASS alone cannot release a successor):

| Defect ID | Location/time and observed defect | Suspected cause (optional; separate) | Required replacement state | Protected elements | Recheck scope | Targeted repairs used (0/1) | Changed approaches used (0/1) |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

One consolidated brief per asset. Never reset a surviving defect's counters by changing its name
or asset version. After one targeted repair and one changed approach, escalate if unresolved;
both require existing director authorization and budget, not automatic spending permission.
Preserve baseline and failed revisions. Review the complete new output after full regeneration.

- Post-repair asset/version and evidence:
- Defect / protected elements / affected boundaries rechecked:
- Unchanged evidence reused (proof of unchanged portion):
- Unresolved defects / escalation:
- Review queue time / review duration / consolidation effort (measured, otherwise unavailable):

Optional machine report: follow `docs/REVIEW_GATE.md`; map source rules 1–9 to R1–R9.
Use full NOT APPLICABLE status with a reason, explicit evidence gaps and actual checks.
