# Production

Inputs: approved run/plan/scene packet and risk-test coverage; exact line IDs; references/media IDs;
accepted parent handoff when dependent; assigned task folder; model/mode constraints.

Prepare exact prompt and request proposals with the prompt skill, reference mapping, cost basis
and pre-submit checklist. Apply I4: extensions omit audio references despite generic voice-reference
guidance. Draft later coverage during waits, but finalize FIRST FRAME / LOCATION MAP only from the
actual accepted parent. Prepare narration per locked lines/windows. Fetch already-submitted jobs
only when assigned, recording outputs in unique paths; do not call paid generation tools yourself.

Outputs: versioned prompt/request proposals; expected check windows; fetched output/evidence where
assigned; reported failures and smallest supported repair proposal. Return all job details to director.

Done: package matches approved decisions and observed state, tags map to real approved references,
applicable realism/audio/safety rules pass pre-submit review and unresolved risks are explicit.
No canonical state writes, spending, Resolve/transcription access or shared shotcuts.py execution.
Only director submits; QA/editor owns shared diagnostics and independent take review.

## Updated prompt contract
Apply the skill's conditional PRODUCTION LEARNING LAYER A–K. Return scene change/causality,
reference roles/exclusions/shot scope, world/body/screen geography, action/hand/prop states,
two timing checks, audio contract and mechanical preflight with each request proposal.
Use the updated PROMPT_TEMPLATE; image edits name one change, protected elements and success
criteria, while new images have no video timeline. Record completed actions so they are not
repeated. After two failed wording changes, propose a different method with evidence/cost;
do not spend or change approved creative intent yourself. Historical SUCCESS is not approval.
