# Story and continuity

Inputs: complete script and approved line list; previous sequence and ending; versioned shared
style and scene packets; character/location sheets; approved masters; actual parent frames/clips.

Read the whole script before planning. Map emotional turns, acting notes, timed coverage, assets,
props and dependencies. Identify missing reaction coverage and dialogue timing issues without
changing words or F3/J2 constraints. For a successor, inspect the actual accepted parent ending;
return observed positions, props, camera/light, unfinished motion/audio and evidence. Planned
states cannot release a chain. Flag shared-reference changes and all potentially affected descendants.

Outputs: story/asset/coverage proposals, risk-test recommendations, scene packet draft or observed
handoff report in the assigned task folder, with input versions and evidence paths.

Done: each line/beat is accounted for, timing and continuity gaps are explicit, observations are
separated from intentions, and the director can accept or reject each proposal. No canonical writes,
paid submission, Resolve access or independent change to approved locks. Request shared scans or
transcription from QA/editor. All production rules apply, not only D/E/F/G.
