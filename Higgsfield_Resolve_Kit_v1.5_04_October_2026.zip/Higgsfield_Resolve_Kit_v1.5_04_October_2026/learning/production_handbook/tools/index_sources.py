from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import json, re, hashlib, collections

BASE = Path(__file__).resolve().parents[1]
src = BASE / 'sources'
text = (src / 'Higgsfield_Seedance_Prompts.md').read_text()
matches = list(re.finditer(r'^\*\*PROMPT (\d+)\*\*', text, re.M))
records = []
decoder = json.JSONDecoder()

def flatten(obj, prefix=''):
    if isinstance(obj, dict):
        for k, v in obj.items(): yield from flatten(v, f'{prefix}.{k}' if prefix else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj): yield from flatten(v, f'{prefix}[{i}]')
    else: yield prefix, obj

for i, m in enumerate(matches):
    end = matches[i+1].start() if i+1 < len(matches) else len(text)
    block = text[m.start():end]
    lines = block.splitlines()
    meta = {}
    for line in lines:
        match = re.match(r'^(DATE(?:\(S\))?|MODEL\(S\)|STATUS\(ES\)|GENERATIONS FOUND):\s*(.*)',line)
        if match: meta[match[1]] = match[2].strip()
    marker = next((j for j,l in enumerate(lines) if l.startswith('GENERATIONS FOUND:')), 0)
    body = '\n'.join(lines[marker+1:]).strip()
    body = re.sub(r'\n\\?-{10,}\s*$', '', body).strip()
    # Reverse Markdown punctuation escaping only; do not rewrite content or valid JSON escapes.
    normalized = re.sub(r'\\([_.*#\[\]()!<>=+-])', r'\1', body)
    parsed = None; error = None
    candidate = normalized.strip()
    if candidate.startswith('```'): candidate = re.sub(r'^```(?:json)?\s*|\s*```$', '',candidate)
    try: parsed = json.loads(candidate)
    except json.JSONDecodeError as e: error = {'message':e.msg,'line':e.lineno,'column':e.colno}
    values = list(flatten(parsed)) if parsed is not None else []
    def first(keys):
        return next((v for k,v in values if k.lower() in keys), None)
    title = first({'title','sequence_title','scene_title','prompt_title'})
    if not title:
        mt=re.search(r'"(?:sequence_title|title)"\s*:\s*"([^"]+)"',normalized)
        title=mt.group(1) if mt else next((l.strip() for l in normalized.splitlines() if l.strip()), '')[:145]
    rec = dict(id=f'A{int(m.group(1)):03d}', archive_number=int(m.group(1)),
        source_start_line=text[:m.start()].count('\n')+1,
        source_end_line=text[:end].count('\n'), metadata=meta, title=title,
        raw_prompt=body, normalized_prompt=normalized, parsed=parsed,
        format='json_after_markdown_unescape' if parsed is not None else ('json_like_unparsed' if candidate.startswith(('{','[')) else 'plain_text'),
        parse_error=error if candidate.startswith(('{','[')) else None,
        characters=len(normalized), duration=first({'duration','total_duration','total_duration_seconds','duration_seconds'}),
        tags=sorted(set(re.findall(r'@[\w]+(?:[ _][0-9]+)?',normalized))),
        content_sha256=hashlib.sha256(normalized.encode()).hexdigest(),
        creative_approval='not_established_by_archive_status',
        render_review='not_performed_no_media_supplied')
    if rec['duration'] is None:
        dm=re.search(r'^Duration:\s*([\d.]+)\s*(?:seconds|sec)',normalized,re.I|re.M)
        if dm: rec['duration']=dm.group(1)+' seconds'
    num=rec['archive_number']
    if num<=10: group='HSF'; basis='named Harrison cast and home'
    elif 24<=num<=29: group='TRA contemporary scenes'; basis='named Amelia, Tomas, Max or Javier'
    elif 30<=num<=66: group='IMTS'; basis='named Kira or adjacent Kira scene block; A035 assignment is contextual'
    elif 68<=num<=98: group='TDMB'; basis='named Alessandra, Edgar or Desmond'
    elif 12<=num<=18: group='Cafe prop edits'; basis='show not named; related to TRA cafe by subject, not verified'
    else: group='Unassigned'; basis='insufficient named story context'
    rec['story_group']=group;rec['story_group_basis']=basis
    durations=[]; shot_ids=[]; method=None
    if parsed and isinstance(parsed,dict):
        shots=parsed.get('shots',parsed.get('SHOTS'))
        if isinstance(shots,list):
            for shot in shots:
                d=re.fullmatch(r'([\d.]+)\s*(?:sec|seconds|s)',str(shot.get('duration','')).strip(),re.I)
                if d: durations.append(float(d.group(1)));shot_ids.append(shot.get('shot'))
            if len(durations)==len(shots): method='JSON shot duration fields'
        elif isinstance(parsed.get('action_timeline'),list):
            slots=parsed['action_timeline']; prev=0; contiguous=True
            for j,slot in enumerate(slots):
                d=re.fullmatch(r'([\d.]+)\s*[-–]\s*([\d.]+)\s*(?:sec|seconds|s)',slot.get('time','').strip(),re.I)
                if d:
                    a,b=map(float,d.groups());contiguous=contiguous and abs(a-prev)<.001 and b>a;prev=b
                    durations.append(b-a);shot_ids.append(j+1)
            if len(durations)==len(slots) and contiguous: method='JSON contiguous action intervals'
    else:
        for sm in re.finditer(r'^SHOT\s+(\d+)\s*[—–-]\s*(?:FINAL\s+)?([\d.]+)\s*(?:SEC|SECONDS)\b',normalized,re.M|re.I):
            shot_ids.append(int(sm.group(1)));durations.append(float(sm.group(2)))
        if durations and shot_ids==list(range(1,len(shot_ids)+1)):method='Sequential explicit shot duration headings'
    declared=re.match(r'([\d.]+)',str(rec['duration'] or ''))
    if method and declared:
        total=round(sum(durations),3);target=float(declared.group(1))
        rec['timing_audit']={'method':method,'declared_seconds':target,'enumerated_seconds':total,'difference_seconds':round(total-target,3),'shot_count':len(durations),'verdict':'matches' if abs(total-target)<.01 else 'mismatch','note':'Checks written duration arithmetic only, not speech or action feasibility or rendered duration.'}
    else:rec['timing_audit']={'verdict':'not_mechanically_verified','note':'Incomplete or unsupported timing format; do not assume correct.'}
    records.append(rec)

ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with ZipFile(src/'_Learning Manual.docx') as z:
    document=ET.fromstring(z.read('word/document.xml'))
    relroot=ET.fromstring(z.read('word/_rels/document.xml.rels'))
    rels={r.attrib['Id']:r.attrib.get('Target','') for r in relroot}
    paras=[]
    for p in document.findall('.//w:p',ns):
        t=''.join(e.text or '' for e in p.findall('.//w:t',ns))
        if not t.strip(): continue
        links=[]
        for h in p.findall('.//w:hyperlink',ns):
            rid=h.attrib.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            if rid in rels: links.append({'label':''.join(e.text or '' for e in h.findall('.//w:t',ns)),'url':rels[rid]})
        paras.append({'id':f'D{len(paras)+1:05d}','text':t,'links':links})

hashes=collections.defaultdict(list)
for r in records: hashes[r['content_sha256']].append(r['id'])
stats={'archive_entries':len(records),'manual_paragraphs':len(paras),'manual_words':sum(len(p['text'].split()) for p in paras),
       'formats':dict(collections.Counter(r['format'] for r in records)),
       'archive_status_labels':dict(collections.Counter(r['metadata'].get('STATUS(ES)','missing') for r in records)),
       'generation_records_reported':sum(int(r['metadata'].get('GENERATIONS FOUND',0)) for r in records),
       'exact_duplicate_prompt_groups':[ids for ids in hashes.values() if len(ids)>1],
       'unique_normalized_prompts':len(hashes),
       'timing_audit':dict(collections.Counter(r['timing_audit']['verdict'] for r in records)),
       'story_groups':dict(collections.Counter(r['story_group'] for r in records)),
       'evidence_limit':'Archive status labels are copied as reported and are not proof of creative approval. Conversation links in the manual were not opened; raw transcripts, scripts and renders are not supplied.'}
for name,data in [('archive_index.json',records),('manual_index.json',paras),('coverage.json',stats)]:
    (BASE/'data'/name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
summary=[]
for r in records:
    vals=list(flatten(r['parsed'])) if r['parsed'] else []
    significant=[(k,str(v)) for k,v in vals if re.search(r'(purpose|story|intent|dialogue|timecode|time_range|^duration|^audio|shot_number)',k,re.I) and len(str(v))<500]
    summary.append(f"{r['id']} | {r['title']} | {r['metadata']} | {r['format']} | chars={r['characters']} | duration={r['duration']}\n"+'\n'.join(f'  {k}: {v}' for k,v in significant[:18]))
(BASE/'data'/'archive_summary.txt').write_text('\n\n'.join(summary))
print(json.dumps(stats,indent=2))
print('Unparsed JSON-like entries:',[(r['id'],r['parse_error']) for r in records if r['format']=='json_like_unparsed'])
