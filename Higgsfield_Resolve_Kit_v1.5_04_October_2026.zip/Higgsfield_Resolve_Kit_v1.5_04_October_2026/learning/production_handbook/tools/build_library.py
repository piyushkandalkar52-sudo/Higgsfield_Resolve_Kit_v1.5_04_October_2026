from pathlib import Path
import json, html, sys, re, zipfile
from content import LESSONS, CASES, PROJECTS, CONFLICTS, GAPS, EVALS

B=Path(__file__).resolve().parents[1]
def dump(name,data): (B/'data'/name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
def h(s):return html.escape(str(s),quote=True)
archive=json.loads((B/'data/archive_index.json').read_text())
manual=json.loads((B/'data/manual_index.json').read_text())
coverage=json.loads((B/'data/coverage.json').read_text())
layers={
 'creative':('01_CREATIVE_JUDGMENT.md','Creative judgment','What should the audience see, understand, and feel?','#117c73'),
 'collaboration':('02_WORKING_WITH_USERS.md','User collaboration','How should the assistant interpret and deliver your request?','#8062aa'),
 'screenplay':('03_SCREENPLAY_GUIDE.md','Screenplay','What happens, why it happens, and what changes?','#b36b23'),
 'prompting':('04_PROMPTING_GUIDE.md','Prompting and references','How do we communicate the scene to the generator?','#326ca4'),
 'review':('05_REVIEW_AND_MEMORY.md','Review and memory','Did it work, what needs repair, and where do we resume?','#a75154')}

dump('lesson_register.json',LESSONS);dump('case_library.json',CASES)
dump('project_registry.json',[dict(name=x[0],focus=x[1],characters=x[2],manual_refs=x[3].split(),archive_coverage=x[4],boundary=x[5]) for x in PROJECTS])
dump('contradictions.json',[dict(choice=x[0],resolution=x[1],lesson_ids=x[2].split(),example=x[3]) for x in CONFLICTS])
dump('open_questions.json',[dict(id=x[0],priority=x[1],needed=x[2],reason=x[3],smallest_request=x[4]) for x in GAPS])
dump('evaluation_cases.json',[dict(id=x[0],test=x[1],lesson_ids=x[2].split(),expected=x[3],failure=x[4],status='not_run_on_a_new_scene') for x in EVALS])

packet={
 'schema_version':'1.0','status':'draft','project_id':None,'world_version':None,'scene_id':None,'source_excerpt':None,
 'dramatic_change':None,'audience_knowledge':{'before':None,'after':None,'keep_hidden':[]},
 'start_state':None,'end_state':None,'protected_elements':[],'allowed_change':None,
 'output_spec':{'model':None,'mode':None,'aspect_ratio':None,'resolution':None,'frame_rate':None},
 'duration_seconds':None,'character_limit':None,'character_count_unit':'Unicode code points; confirm adapter unit',
 'generation_boundary':None,'references':[],'reference_example':{'tag':'<exact registered tag>','asset':'<approved path or asset ID>','roles':['identity'],'excluded_roles':['costume'],'applies_to_shots':[],'status':'unverified'},
 'audio_mode':None,'audio_mode_choices':['silent','speech_only','speech_and_room_tone','explicit_custom'],
 'shots':[],'shot_example':{'id':'S01_SH01','start_seconds':0,'end_seconds':None,'action':None,'camera':None,'eyelines':None,'continuity_in':None,'continuity_out':None,'utterances':[]},
 'utterance_example':{'speaker':None,'voice_tag':None,'text':None,'start_seconds':None,'end_seconds':None},
 'prompt_format':None,'compiled_prompt':None,'acceptance_checks':[],'lesson_ids':[],'open_questions':[]}
templates={
 'scene_packet.json':packet,
 'decision_record.json':{'decision_id':None,'project_id':None,'scene_id':None,'request':None,'prior_state':None,'user_feedback_source':None,'observed_problem':None,'suspected_cause':None,'changed_element':None,'protected_elements':[],'candidate_version':None,'selected_baseline':None,'result_status':'proposed','result_evidence':[],'acceptance_scope':None,'lesson_ids':[],'next_action':None},
 'review_record.json':{'project_id':None,'scene_id':None,'prompt_id':None,'attempt_id':None,'job_status':'unknown','creative_status':'unreviewed','render_path':None,'reviewer':None,'reviewed_at':None,'checks':{k:'unclear' for k in ['story','action','geography','identity','props','performance','timing','audio','text','crop']},'accepted_intervals':[],'findings':[],'approval_evidence':None,'acceptance_scope':None,'next_action':None},
 'run_state.json':{'project_id':None,'world_version':None,'active_scene':None,'script_version':None,'selected_prompt_version':None,'last_accepted_render':None,'current_physical_state':None,'current_emotional_state':None,'in_flight_jobs':[],'pending_corrections':[],'current_reference_roles':[],'deprecated_assets':[],'rejected_versions':[],'paused_work':[],'next_action':None,'last_updated':None},
 'show_guide.json':{'project_id':None,'world_version':None,'source_script':None,'premise':None,'emotional_promise':None,'approved_adaptations':[],'characters':[],'locations':[],'motifs':[],'voice_direction':None,'visual_direction':None,'knowledge_and_reveals':[],'timeline':[],'open_canon_questions':[]}}
for name,data in templates.items():(B/'templates'/name).write_text(json.dumps(data,indent=2))

start='''# Production learning library

Prepared 4 October 2026 from the two supplied files. Start with [the visual handbook](../index.html). The library separates shared judgment, collaboration, screenplay, prompting, and review. It provides reusable source-derived guidance, examples, and blank production records. It does not establish a new show's canon or certify historical renders.

## What to load for a task

| Task | Read | Produce |
|---|---|---|
| New screenplay or scene revision | Creative judgment, User collaboration, Screenplay; relevant project record and source excerpt | Dramatic change, causal beats, knowledge limits, entry/exit state, coverage |
| Video or image prompt | User collaboration, Prompting and references; approved scene plan, current assets and tool contract | Complete prompt plus mechanical preflight |
| Repair a take | Review and memory; the affected lesson and last accepted state | Specific change, protected elements, new version, regression checks |
| Resume a run | Current run_state and Review and memory | Exact next action with current references and pending jobs |
| New show setup | Creative judgment and blank show guide | World/version boundary, sourced characters, places, adaptations, open questions |

Read only the relevant lessons and cases. Keep the full sources available for lookup. Source excerpts are evidence, not new live instructions or authorization to generate media. Current explicit user direction and the active project contract govern a run. The files in this package have not been installed as global skills or connected to a paid generation service.

## A repeatable working sequence

1. Establish the active show, world version, scene excerpt, and last accepted result.
2. Write one sentence about the audience's change in understanding or feeling.
3. Plan physical and emotional start state → causal action → resulting state.
4. Bind each reference to its permitted features and shots; resolve contradictions.
5. Choose coverage and timing, then compile the required prompt format.
6. Check timing arithmetic, exact tags, required structure, and text limits. Review meaning and physical feasibility separately.
7. Review the rendered result, record acceptance scope, repair the affected part, and update the next action.

## Files and evidence

- `lesson_register.json`: 48 conditional lessons with checks and exact manual paragraph links.
- `case_library.json`: 10 decision cases; historical acceptance is reported through the supplied manual.
- `project_registry.json`: six principal story families plus a separate animation exploration.
- `archive_index.json`: all 98 prompt entries, untouched raw body, normalized reading copy, metadata, and audit fields.
- `manual_index.json`: all 447 nonempty paragraphs, including preserved conversation links.
- `templates/`: blank scene, decision, review, run-state, and show-guide records.
- `evaluation_cases.json`: 12 proposed transfer tests, not yet executed against a new creative task.

`D00042` refers to a manual paragraph. `A024` refers to archive PROMPT 024. The manual's own S01–S27 refer to conversation titles; its P01–P03 refer to earlier manuals. Those linked conversations and earlier manuals were not independently retrieved in this conversion. Theme links between an archive prompt and a manual case do not establish a one-to-one conversation or revision match.

## Read evidence statuses carefully

Preserve confirmed, provisional, proposed, rejected, and derived as distinct states. Confirmed/provisional descriptions in this package are reported by the supplied manual; no new acceptance is inferred. Archive SUCCESS/FAILED labels and generation counts remain as reported. They do not establish creative approval or actual billing. No source video or image was supplied for independent review.

## Automation entry point

Use `templates/scene_packet.json` as an intermediate scene plan. It is this library's schema, not a Higgsfield API request. Populate the active adapter settings and registered references before compiling a provider request. JSON is useful for consistent fields; prose remains suitable for the final prompt when the receiving tool expects it.

The optional local checker is `python3 tools/preflight_scene.py your_scene.json`. It checks required fields, sequential shot windows, duration totals, reference membership, speech windows, basic audio consistency, and JSON syntax when requested. It cannot inspect pixels, understand all physical contradictions, establish source canon, or approve generation. A blank template intentionally fails preflight.

## Adoption and improvement

Use the guides on a small new scene with its actual source excerpt. Compare the old and updated workflow against the same intention and constraints. Record missed facts, continuity failures, unnecessary revisions, and the user's choice; do not claim a measured improvement until that comparison exists. The 12 evaluation cases offer targeted checks. A mechanical checker pass is not a creative evaluation pass.

No complete script upload is required to understand or use these general lessons. Ask for a scene excerpt with adjacent beats only when story facts, exact dialogue, chronology, or reveal boundaries must be checked. Ask for the relevant accepted/rejected media when validating whether a historical repair worked.
'''
start += '''
## Two independent automation packs

For stage-specific loading, use [screenplay learning](../automation_learning/screenplay_learning/FEED_THIS.md) during scene writing and [prompt learning](../automation_learning/prompt_learning/FEED_THIS.md) during prompt compilation. Each includes the shared guidance it needs and generic examples for any user. Each folder also has equivalent JSON guidance and input/output templates. Load one guidance format per stage.

Pass the screenplay output into the prompt input’s `scene_handoff` field after scene approval. Supply current project facts, references, and tool settings separately. See [the pack overview](../automation_learning/README.md).
'''
(B/'guides/00_START_HERE.md').write_text(start)
for key,(filename,name,question,color) in layers.items():
    lines=[f'# {name}',question,'Source-derived working guidance. Apply the active brief and project context. See 00_START_HERE.md for scope and evidence limits.']
    for l in [l for l in LESSONS if l['layer']==key]:
        refs=' '.join(l['manual_refs']+l['archive_refs'])
        lines += [f"## {l['id']} {l['title']}",f"When: {l['when']}",l['rule'],f"Example: {l['example']}",f"Check: {l['check']}",f"Scope: {l['scope']}",f"Evidence: {refs}. {l['evidence_status']}"]
    (B/'guides'/filename).write_text('\n\n'.join(lines)+'\n')
for filename,title,rows in [
 ('06_PROJECT_BOUNDARIES.md','Project boundaries',PROJECTS),
 ('07_CONFLICTS_AND_EXCEPTIONS.md','Conflicts and exceptions',CONFLICTS),
 ('08_OPEN_QUESTIONS.md','Smallest additional inputs when needed',GAPS),
 ('09_EVALUATION_PLAN.md','Test the lessons on new scenes',EVALS)]:
    out=[f'# {title}']
    for row in rows:out += [f'## {row[0]}']+[str(v) for v in row[1:]]
    (B/'guides'/filename).write_text('\n\n'.join(out)+'\n')
(B/'README.md').write_text('# Production learning library\n\nOpen [the visual handbook](index.html). For machine use, begin with [the loading guide](guides/00_START_HERE.md). Original files are preserved under `sources/`; evidence can be explored in [the source browser](sources.html).\n\nPrepared 4 October 2026. General guides are usable now; selected scene facts and media outcomes still need the specific source excerpt or render when a production task requires them.\n')

def refs(manual_ids,archive_ids=()):
    if isinstance(manual_ids,str):manual_ids=manual_ids.split()
    return ' '.join(f'<a class="ref" href="sources.html#{h(x)}">{h(x)}</a>' for x in list(manual_ids)+list(archive_ids))

style='''
:root{--ink:#233142;--muted:#5d6c7e;--paper:#f5f4ef;--card:#fff;--teal:#117c73;--gold:#b36b23;--red:#a75154;--line:#d6dedf}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:var(--teal);text-underline-offset:3px}button,input,select{font:inherit}button,select,input{border:1px solid #bdc9ce;border-radius:8px;padding:9px 12px;background:#fff;color:var(--ink)}button{cursor:pointer}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #63aea8;outline-offset:3px}.wrap{max-width:1420px;margin:auto;display:grid;grid-template-columns:235px minmax(0,1fr);gap:36px;padding:28px}.sidebar{position:sticky;top:24px;height:fit-content}.brand{font-size:12px;text-transform:uppercase;letter-spacing:.15em;font-weight:800;color:var(--teal)}.sidebar h2{font-size:20px;line-height:1.25;margin:8px 0 20px}.sidebar nav a{display:block;padding:7px 0;text-decoration:none;color:var(--muted);font-size:14px}.sidebar nav a:hover{color:var(--teal)}main{min-width:0}header{padding:14px 0 24px}h1{font-size:clamp(30px,4vw,48px);line-height:1.07;letter-spacing:-.04em;margin:9px 0 17px}h2{font-size:27px;line-height:1.2;letter-spacing:-.025em;margin:0 0 15px}h3{font-size:19px;margin:0 0 8px}p{margin:8px 0 15px}.lead{font-size:19px;color:var(--muted);max-width:800px}.small{font-size:13px;color:var(--muted)}section{scroll-margin-top:24px;margin:0 0 48px}.pill{display:inline-block;font-size:12px;padding:3px 9px;background:#e4eeeb;color:#176458;border-radius:6px;margin:0 5px 5px 0}.pale{background:#f8eee0;color:#855419}.warn{background:#f8e9e5;color:#914a43}.note{padding:15px 19px;background:#edf5f2;border-left:4px solid var(--teal);border-radius:0 10px 10px 0}.note.warnbox{background:#fff4eb;border-left-color:var(--gold)}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.card{padding:20px;border:1px solid var(--line);border-radius:12px;background:var(--card)}.tree{padding:22px;background:#eaf2ef;border-radius:15px}.tree-root{max-width:460px;margin:auto;text-align:center;background:#194a49;color:white;border-radius:10px;padding:17px}.tree-root small{color:#c5e4df}.tree-stem{height:24px;width:2px;background:#8fafab;margin:auto}.tree-branches{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;position:relative}.tree-branch{font-size:14px;background:#fff;border:1px solid #cbdcd6;border-top:5px solid var(--tone);border-radius:8px;padding:14px;position:relative;text-decoration:none;color:var(--ink)}.tree-branch:before{content:"";height:18px;width:2px;background:#8fafab;position:absolute;left:50%;top:-23px}.automation-branches{grid-template-columns:repeat(2,minmax(0,1fr))}.tree-branches.automation-branches:before{left:25%;right:25%}.tree-branch small{color:var(--muted);display:block;margin-top:5px}.tree-branches:before{content:"";position:absolute;left:8.33%;right:8.33%;top:-18px;border-top:2px solid #8fafab}.flow{display:flex;gap:8px;align-items:stretch;flex-wrap:wrap;margin:18px 0}.flow>div{flex:1;min-width:120px;padding:14px;background:#fff;border:1px solid var(--line);border-radius:10px}.flow b{display:block;color:var(--teal);margin-bottom:3px}.flow>span{align-self:center;color:var(--teal)}.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:17px 0}.toolbar input{flex:1;min-width:180px}.lesson{margin:10px 0;border:1px solid var(--line);border-left:4px solid var(--tone);border-radius:9px;background:#fff}.lesson summary,.case summary{padding:15px 18px;cursor:pointer}.lesson summary strong{font-size:16px}.lesson summary .small{display:block;margin:4px 0 0 22px}.detail{padding:0 20px 16px}.detail dl{display:grid;grid-template-columns:90px minmax(0,1fr);gap:9px 16px;margin:4px 0 16px}.detail dt{font-size:13px;font-weight:750;color:var(--muted)}.detail dd{margin:0}.ref{display:inline-block;font-size:12px;border-bottom:1px solid #a8ccc3;text-decoration:none;margin:2px 8px 2px 0}.case{background:white;border:1px solid var(--line);border-radius:10px;margin-bottom:12px}.case summary{font-weight:750}.case .detail{font-weight:400}.tablebox{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:14px;background:white}th,td{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid var(--line)}th{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.04em}code{font-size:.86em;background:#edf1f3;padding:2px 4px;border-radius:4px;overflow-wrap:anywhere}.filelinks a{display:block;padding:5px 0}.muted{color:var(--muted)}footer{border-top:1px solid var(--line);padding-top:18px;font-size:12px;color:var(--muted)}[hidden]{display:none!important}@media(max-width:950px){.wrap{grid-template-columns:1fr;gap:5px;padding:20px}.sidebar{position:static}.sidebar h2{display:none}.sidebar nav{display:flex;gap:6px 20px;flex-wrap:wrap;margin:12px 0}.sidebar nav a{font-size:13px}.tree-branches{grid-template-columns:1fr;border-left:2px solid #8fafab;padding-left:18px}.tree-branches:before{display:none}.tree-branch:before{display:block;height:2px;width:18px;left:-20px;top:24px}.tree-stem{margin-left:0}}@media(max-width:580px){.wrap{padding:16px}.grid{grid-template-columns:1fr}.tree-branches{grid-template-columns:1fr}.tree{padding:16px}.detail dl{grid-template-columns:1fr;gap:3px}.detail dd{margin-bottom:10px}.toolbar>*{width:100%}.flow>span{display:none}th,td{padding:9px}h1{font-size:34px}}@media print{.sidebar,.toolbar,.print-hide{display:none}.wrap{display:block}.lesson,.case,.card{break-inside:avoid}body{background:white}section{margin-bottom:25px}}
'''

parts=['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Production learning library</title><style>'+style+'</style></head><body><div class="wrap"><aside class="sidebar"><div class="brand">Creative production</div><h2>Production<br>learning library</h2><nav>']
for id,title in [('overview','Start here'),('use','Use it on a scene'),('automation','Two automation packs'),('lessons','48 practical lessons'),('cases','10 decision examples'),('audit','Prompt checks'),('projects','Keep shows separate'),('conflicts','Handle exceptions'),('inputs','What else is needed'),('files','Reusable files'),('test','Test improvement')]:parts.append(f'<a href="#{id}">{title}</a>')
parts.append('<a href="sources.html">Explore original evidence ↗</a></nav></aside><main><header id="overview"><div class="brand">Version 1.1 · 4 October 2026</div><h1>Production learning,<br>ready for every user.</h1><p class="lead">A practical way to apply creative judgment into screenplay writing, AI prompts, and review—while keeping the reason behind each choice.</p><span class="pill">98 prompt entries indexed</span><span class="pill">447 manual paragraphs preserved</span><span class="pill">48 conditional lessons</span><span class="pill pale">Creative transfer tests still to run</span></header>')
parts.append('<section><div class="tree"><div class="tree-root"><b>Production experience → reusable guidance</b><br><small>Prompt archive + the manual summarizing 27 conversations</small></div><div class="tree-stem"></div><div class="tree-branches">')
for key,(_,name,question,color) in layers.items():parts.append(f'<a href="#lessons" data-layer-link="{key}" class="tree-branch" style="--tone:{color}"><b>{name}</b><small>{question}</small></a>')
parts.append('<a href="#projects" class="tree-branch" style="--tone:#647c63"><b>Each show’s own facts</b><small>Keep names, world, ages, costumes, and approved adaptations within that show.</small></a></div></div><p class="small">The shared principles guide both writing and prompting. References, settings, and story facts are filled in for the active scene.</p></section>')
parts.append('<section id="use"><h2>Use it on the next scene</h2><div class="flow"><div><b>1 · Intention</b>What changes for the viewer?</div><span>→</span><div><b>2 · Scene</b>What causes each action and reaction?</div><span>→</span><div><b>3 · Prompt</b>Which references, shots, words, and timing express it?</div><span>→</span><div><b>4 · Check</b>Does the result show what you meant?</div></div><div class="grid"><div class="card"><h3>For screenplay work</h3><p>Read creative judgment + screenplay lessons. Bring the active scene excerpt and its adjacent beats. Produce a clear event with a beginning state, consequence, and ending state.</p></div><div class="card"><h3>For prompting work</h3><p>Use the approved scene plan + prompting lessons. Bind exact references, check timing and format, then review the real output before accepting it.</p></div></div><p class="note"><b>One example:</b> “She feels relieved” becomes recognition → a loosened grip → lowered shoulders. The screenplay gives that change a cause. The prompt specifies the visible behavior. Review checks that it did not turn into an unintended broad smile.</p></section>')
parts.append('<section id="automation"><h2>Two folders. Two automation stages.</h2><p>Generic guidance for every user. Each pack works on its own and includes the shared rules that stage needs.</p><div class="tree"><div class="tree-root"><b>Automation learning</b><br><small>Choose the stage you are working on</small></div><div class="tree-stem"></div><div class="tree-branches automation-branches"><a class="tree-branch" style="--tone:#b36b23" href="automation_learning/screenplay_learning/FEED_THIS.md"><b>01 · Screenplay learning</b><small>What happens? Why? What changes?</small></a><a class="tree-branch" style="--tone:#326ca4" href="automation_learning/prompt_learning/FEED_THIS.md"><b>02 · Prompt learning</b><small>How should the generator show it?</small></a></div></div><div class="flow"><div><b>Scene input</b>Brief + relevant script + current facts</div><span>→</span><div><b>Screenplay pack</b>Scene + structured handoff</div><span>→</span><div><b>Scene approval</b>Record the selected version</div><span>→</span><div><b>Prompt pack</b>Approved handoff + references + tool settings</div></div><div class="grid"><div class="card filelinks"><h3>Screenplay learning</h3><p>Build clear actions, emotions, reveals, continuity, and coverage.</p><a href="automation_learning/screenplay_learning/FEED_THIS.md">Feed this file · complete stage guide</a><a href="automation_learning/screenplay_learning/lessons.json">JSON version · same guidance</a><a href="automation_learning/screenplay_learning/README.md">How to use it + templates</a></div><div class="card filelinks"><h3>Prompt learning</h3><p>Bind references, describe motion, check timing, compile prompts, and review results.</p><a href="automation_learning/prompt_learning/FEED_THIS.md">Feed this file · complete stage guide</a><a href="automation_learning/prompt_learning/lessons.json">JSON version · same guidance</a><a href="automation_learning/prompt_learning/README.md">How to use it + templates</a></div></div><p class="note">Feed <b>FEED_THIS.md</b> or its JSON equivalent at the relevant stage. Add the current scene information. Shared rules appear in both packs so neither needs the other folder. Historical names and show facts stay in the evidence library.</p><p><a href="automation_learning/README.md">Open the folder guide</a></p></section>')
parts.append('<section id="lessons"><h2>Open the branch you need</h2><p>Each lesson includes a condition, an action, an example, a check, and a route back to the supplied evidence.</p><div class="toolbar"><input id="search" aria-label="Search lessons" placeholder="Search: emotion, book, camera, timing…"><select id="layer" aria-label="Choose learning branch"><option value="all">All branches</option>')
for k,(_,name,_,_) in layers.items():parts.append(f'<option value="{k}">{name}</option>')
parts.append('</select></div><p class="small" id="lesson-count" aria-live="polite">48 lessons</p>')
for l in LESSONS:
    color=layers[l['layer']][3]
    search=' '.join([l['id'],l['title'],l['when'],l['rule'],l['example'],l['check']])
    parts.append(f'<details class="lesson" id="{l["id"]}" data-layer="{l["layer"]}" data-search="{h(search.lower())}" style="--tone:{color}"><summary><strong>{l["id"]} · {h(l["title"])}</strong><span class="small">{h(l["when"])}</span></summary><div class="detail"><dl>')
    for label,field in [('Do this','rule'),('Example','example'),('Check','check'),('Scope','scope')]:parts.append(f'<dt>{label}</dt><dd>{h(l[field])}</dd>')
    parts.append('</dl>'+refs(l['manual_refs'],l['archive_refs'])+f'<p class="small">{h(l["evidence_status"])}</p></div></details>')
parts.append('</section><section id="cases"><h2>See how production decisions become lessons</h2><p>These are paraphrased decision histories from the supplied manual. They preserve what was proposed, accepted with qualifications, or left unresolved.</p>')
for c in CASES:
    parts.append(f'<details class="case" id="{c["id"]}"><summary>{c["id"]} · {h(c["title"])} <span class="small">— {h(c["family"])}</span></summary><div class="detail"><dl>')
    for label,field in [('Intention','intent'),('Problem','problem'),('Decision','decision'),('Protect','protected'),('Evidence','status')]:parts.append(f'<dt>{label}</dt><dd>{h(c[field])}</dd>')
    parts.append('</dl>'+refs(c['manual'],c['archive'])+'<p>Use '+', '.join(f'<a href="#{x}">{x}</a>' for x in c['lessons'])+'</p></div></details>')
parts.append('</section><section id="audit"><h2>Catch these problems before generation</h2><div class="grid"><div class="card"><h3>25 timing discrepancies</h3><p>Of 71 prompts with supported explicit timing, 46 match their written totals and 25 differ. Another 27 could not be checked mechanically.</p><p class="small">This checks listed seconds, not measured video length or whether speech fits.</p></div><div class="card"><h3>A mix of formats</h3><p>91 entries are prose. Seven are JSON-like: six parse after Markdown unescaping, and A006 still fails strict JSON parsing.</p><p class="small">Both formats are preserved. The final format should match the receiving tool.</p></div></div>')
parts.append('<p class="note warnbox"><b>SUCCESS is not an approval:</b> 96 archive entries say SUCCESS and two say FAILED. These are copied labels. The manual reports several unresolved creative fixes. No supplied renders have been independently checked in this work.</p><details class="case"><summary>View all 25 written timing discrepancies</summary><div class="detail tablebox"><table><thead><tr><th>Source</th><th>Stated total</th><th>Listed shots</th><th>Difference</th></tr></thead><tbody>')
for r in archive:
    a=r['timing_audit']
    if a['verdict']=='mismatch':parts.append(f'<tr><td>{refs([], [r["id"]])}</td><td>{a["declared_seconds"]:g}s</td><td>{a["enumerated_seconds"]:g}s</td><td>{a["difference_seconds"]:+g}s</td></tr>')
parts.append('</tbody></table><p class="small">A smaller sum means unallocated time; a larger sum means the listed allocation exceeds the stated duration. Resolve the intended timing before reusing the prompt. No historical prompt has been silently repaired.</p></div></details><div class="card"><h3>Three concrete formatting risks</h3><p>'+refs([],['A006'])+' contains <code>"duration": 4.5 seconds</code>, which is invalid JSON. A quoted string or a numeric seconds field is needed in a new compiled version.</p><p>'+refs([],['A033'])+' has a blank reference assignment. '+refs([],['A071'])+' includes <code>@duke_bdfor</code>, a tag joined to the following word. Compare with the active tag registry.</p><p class="small">A017 and A018 have identical normalized prompt bodies. Their archive metadata remains separate; the repeated text is not two independent creative lessons.</p></div></section>')
parts.append('<section id="projects"><h2>Keep each show’s facts in its own branch</h2><p>The manual describes six principal story families and one distinct animation exploration. The prompt archive covers only part of that range.</p><div class="grid">')
for name,focus,characters,mrefs,acover,boundary in PROJECTS:parts.append(f'<div class="card"><h3>{h(name)}</h3><p>{h(focus)}</p><p class="small">{h(characters)}<br>Archive: {h(acover)}</p><p>{h(boundary)}</p>{refs(mrefs)}</div>')
parts.append('</div><p class="small">A011, A019–A023, and A067 remain unassigned because their text does not securely identify the show. A012–A018 remain a café-prop group with a thematic TRA connection. No cross-show canon has been merged.</p></section>')
parts.append('<section id="conflicts"><h2>Turn apparent conflicts into choices</h2><div class="tablebox"><table><thead><tr><th>Choice</th><th>How to decide</th><th>Evidence</th></tr></thead><tbody>')
for choice,resolution,lids,example in CONFLICTS:parts.append(f'<tr><td><b>{h(choice)}</b></td><td>{h(resolution)}<br>'+', '.join(f'<a href="#{x}">{x}</a>' for x in lids.split())+f'</td><td>{h(example)}</td></tr>')
parts.append('</tbody></table></div></section>')
parts.append('<section id="inputs"><h2>You do not need to upload every script</h2><p>The general guidance is documented now. Bring a small, targeted piece of evidence when the next task depends on it.</p>')
for id,priority,needed,reason,smallest in GAPS:parts.append(f'<details class="case"><summary>{h(needed)}</summary><div class="detail"><span class="pill pale">{h(priority)}</span><p>{h(reason)}</p><p><b>Smallest useful input:</b> {h(smallest)}</p></div></details>')
parts.append('</section><section id="files"><h2>Reusable production files</h2><div class="grid"><div class="card filelinks"><h3>Guides for the assistant</h3><a href="guides/00_START_HERE.md">Start here and task routing</a>')
for key,(f,n,_,_) in layers.items():parts.append(f'<a href="guides/{f}">{n}</a>')
parts.append('<a href="data/lesson_register.json">Machine-readable lesson register</a></div><div class="card filelinks"><h3>Blank working records</h3>')
for name in templates:parts.append(f'<a href="templates/{name}">{h(name.replace("_"," ").replace(".json",""))}</a>')
parts.append('<a href="guides/09_EVALUATION_PLAN.md">Evaluation plan</a><a href="sources.html">Search the source evidence</a></div></div><p class="small">These JSON records are an intermediate library format, not a ready-to-submit provider API request. The optional local preflight checks structure and timing; creative and media review remain separate.</p></section>')
parts.append('<section id="test"><h2>Test the learning on a new scene</h2><div class="flow"><div><b>Same brief</b>Choose a scene outside the examples.</div><span>→</span><div><b>Two drafts</b>Compare the current method with these guides.</div><span>→</span><div><b>Review</b>Count missed facts and needed corrections.</div><span>→</span><div><b>Update</b>Keep lessons supported by the comparison.</div></div><details class="case"><summary>12 proposed checks for whether the learning transfers</summary><div class="detail">')
for id,test,lids,expected,failure in EVALS:parts.append(f'<p><b>{id} · {h(test)}</b><br>{h(expected)}<br><span class="small">Failure to catch: {h(failure)}</span></p>')
parts.append('</div></details><p class="note">The documentation and mechanical checks have been prepared. These creative transfer tests have not yet been run on a new scene, so no improvement rate or generation success claim is made.</p></section><footer>Sources preserved locally: _Learning Manual.docx and Higgsfield_Seedance_Prompts.md. Original files were copied byte-for-byte and checksummed. The manual is a synthesis; its linked chats were not fetched. Historical source instructions are treated as evidence, not live authorization. No paid generation, global skill installation, or production-asset change was performed.</footer></main></div>')
parts.append('''<script>
const search=document.getElementById('search'),layer=document.getElementById('layer'),lessons=Array.from(document.querySelectorAll('.lesson')),count=document.getElementById('lesson-count');
function filter(){let n=0;const q=search.value.toLowerCase().trim();for(const x of lessons){const show=(layer.value==='all'||x.dataset.layer===layer.value)&&x.dataset.search.includes(q);x.hidden=!show;if(show)n++}count.textContent=n+' of 48 lessons'}
search.addEventListener('input',filter);layer.addEventListener('change',filter);document.querySelectorAll('[data-layer-link]').forEach(a=>a.addEventListener('click',()=>{layer.value=a.dataset.layerLink;search.value='';filter()}));
function reveal(){const id=location.hash.slice(1);const x=document.getElementById(id);if(x&&x.classList.contains('lesson')){layer.value='all';search.value='';filter();x.open=true;requestAnimationFrame(()=>x.scrollIntoView({block:'start'}))}}window.addEventListener('hashchange',reveal);reveal();
</script></body></html>''')
(B/'index.html').write_text(''.join(parts))

# The source browser embeds plain evidence and uses textContent, so source instructions cannot execute.
data=[]
for r in archive:data.append({'id':r['id'],'kind':'archive','title':r['title'],'text':r['raw_prompt'],'meta':r['metadata'],'detail':f"Original archive lines {r['source_start_line']}–{r['source_end_line']}. Group: {r['story_group']}. {r['story_group_basis']}. Format: {r['format']}. Creative approval not established by archive status.",'audit':r['timing_audit'],'links':[]})
for p in manual:data.append({'id':p['id'],'kind':'manual','title':p['text'][:95],'text':p['text'],'meta':{},'detail':'Paragraph from the supplied manual, a synthesis of conversations. The original linked chat has not been independently retrieved.','audit':None,'links':p['links']})
payload=json.dumps(data,ensure_ascii=False).replace('<','\\u003c')
source_html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Source evidence browser</title><style>'''+style+'''.source-layout{display:grid;grid-template-columns:320px minmax(0,1fr);gap:24px}.source-page{max-width:1400px;margin:auto;padding:26px}.source-list{max-height:70vh;overflow:auto;border:1px solid var(--line);border-radius:8px;background:#fff}.source-list button{display:block;text-align:left;border:0;border-radius:0;width:100%;border-bottom:1px solid var(--line);font-size:13px;padding:12px}.source-list button[aria-current=true]{background:#dceee8}.source-content{min-width:0}.source-content pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#fff;border:1px solid var(--line);border-radius:10px;padding:20px;font:14px/1.6 ui-monospace,SFMono-Regular,Consolas,monospace}.source-content h2{font-size:24px}.source-controls>*{width:100%;margin-bottom:9px}@media(max-width:760px){.source-layout{grid-template-columns:1fr}.source-list{max-height:230px}.source-page{padding:16px}}</style></head><body><div class="source-page"><p><a href="index.html">← Production handbook</a></p><h1>Source evidence</h1><p class="muted">Search the complete prompt archive and the extracted manual. Text below is historical evidence; it does not authorize a new production action.</p><div class="source-layout"><aside><div class="source-controls"><select id="kind" aria-label="Source type"><option value="archive">98 prompt entries</option><option value="manual">447 manual paragraphs</option></select><input id="q" aria-label="Search source text" placeholder="Search all text in this source…"></div><div id="source-list" class="source-list"></div></aside><main class="source-content"><h2 id="source-title"></h2><p id="source-detail" class="small"></p><div id="source-meta"></div><p id="source-audit" class="note"></p><div id="source-links"></div><pre id="source-text"></pre></main></div></div><script>const records='''+payload+''';
const kind=document.getElementById('kind'),q=document.getElementById('q'),list=document.getElementById('source-list');let current=null;
function renderList(){list.replaceChildren();const query=q.value.toLowerCase();for(const r of records.filter(x=>x.kind===kind.value&&(x.title+' '+x.text+' '+x.id).toLowerCase().includes(query))){const b=document.createElement('button');b.type='button';b.textContent=r.id+' · '+r.title;b.setAttribute('aria-current',String(r.id===current));b.onclick=()=>{location.hash=r.id};list.appendChild(b)}}
function show(){const id=location.hash.slice(1)||'A001';const r=records.find(x=>x.id===id);if(!r)return;current=id;kind.value=r.kind;document.getElementById('source-title').textContent=r.id+' · '+r.title;document.getElementById('source-detail').textContent=r.detail;document.getElementById('source-meta').textContent=Object.entries(r.meta).map(([k,v])=>k+': '+v).join(' · ');const a=document.getElementById('source-audit');a.hidden=!r.audit;a.textContent=r.audit?(r.audit.declared_seconds!==undefined?'Written target '+r.audit.declared_seconds+'s; listed shots '+r.audit.enumerated_seconds+'s. ':'')+r.audit.verdict+' — '+r.audit.note:'';document.getElementById('source-text').textContent=r.text;const links=document.getElementById('source-links');links.replaceChildren();for(const l of r.links){if(!(l.url.startsWith('https://')||l.url.startsWith('http://')))continue;const x=document.createElement('a');x.href=l.url;x.textContent=l.label+' (original linked source; not fetched here)';x.rel='noopener';links.appendChild(x)}renderList()}
kind.addEventListener('change',renderList);q.addEventListener('input',renderList);window.addEventListener('hashchange',show);show();</script></body></html>'''
(B/'sources.html').write_text(source_html)
print('Built handbook, source browser, 48 lessons, 10 cases, 10 guides and 5 blank templates.')

from build_automation_packs import build as build_packs
print('Built generic automation packs:', build_packs())
(B/'README.md').write_text((B/'README.md').read_text() + '\n## Separate stage feeds\n\nUse [screenplay learning](automation_learning/screenplay_learning/FEED_THIS.md) for scene writing and [prompt learning](automation_learning/prompt_learning/FEED_THIS.md) for generation prompts. Both are generic, independent packs with JSON alternatives and task templates. [Folder guide](automation_learning/README.md).\n')
