"""Check a new scene packet locally. This never submits generation or certifies creative QA."""
import json, math, re, sys
from pathlib import Path

def check(packet):
    errors=[]; warnings=[]
    def number(v): return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
    for field in ['project_id','scene_id','source_excerpt','dramatic_change','start_state','end_state','output_spec']:
        if not packet.get(field): errors.append(f'Missing {field}.')
    spec=packet.get('output_spec') or {}
    for field in ['model','mode','aspect_ratio','resolution']:
        if not spec.get(field): errors.append(f'Missing output_spec.{field}.')
    duration=packet.get('duration_seconds')
    if not number(duration) or duration<=0: errors.append('duration_seconds must be a positive number.')
    refs=packet.get('references') or []; tags=[]
    for ref in refs:
        tag=ref.get('tag');tags.append(tag)
        if not tag or not ref.get('asset') or not ref.get('roles'): errors.append('Each reference needs exact tag, asset, and roles.')
        if ref.get('status')!='approved':warnings.append(f'Reference {tag!r} is not marked approved; verify its permitted use.')
    if len(tags)!=len(set(tags)):errors.append('Duplicate reference tags.')
    text=packet.get('compiled_prompt')
    if not isinstance(text,str) or not text.strip():errors.append('compiled_prompt is empty.')
    else:
        used=set(re.findall(r'@[\w]+(?:[ _][0-9]+)?',text))
        for tag in sorted(used-set(tags)):errors.append(f'Prompt uses unregistered tag {tag}.')
        limit=packet.get('character_limit')
        if limit is not None:
            if not number(limit) or limit<=0:errors.append('character_limit must be positive or null.')
            elif len(text)>limit:errors.append(f'Prompt has {len(text)} Unicode code points; limit is {limit}. Confirm the adapter uses this counting unit.')
        if packet.get('prompt_format')=='json':
            try:json.loads(text)
            except json.JSONDecodeError as e:errors.append(f'Compiled prompt is invalid JSON: {e.msg} at line {e.lineno}.')
    modes={'silent','speech_only','speech_and_room_tone','explicit_custom'}
    if packet.get('audio_mode') not in modes:errors.append('Choose an explicit supported packet audio_mode.')
    shots=packet.get('shots') or [];prev=0;ids=[]
    if not shots:errors.append('At least one timed shot is required.')
    for shot in shots:
        sid=shot.get('id');ids.append(sid)
        if not sid:errors.append('Missing shot ID.')
        a=shot.get('start_seconds');b=shot.get('end_seconds')
        if not number(a) or not number(b) or a<0 or b<=a:errors.append(f'{sid}: invalid time range.');continue
        if abs(a-prev)>.001:errors.append(f'{sid}: gap/overlap at {a}s; preceding endpoint is {prev}s.')
        prev=b
        for field in ['action','camera','continuity_out']:
            if not shot.get(field):errors.append(f'{sid}: missing {field}.')
        for speech in shot.get('utterances') or []:
            if packet.get('audio_mode')=='silent':errors.append(f'{sid}: silent packet contains speech.')
            for field in ['speaker','text','voice_tag']:
                if not speech.get(field):errors.append(f'{sid}: utterance missing {field}.')
            if speech.get('voice_tag') not in tags:errors.append(f'{sid}: voice tag is not registered.')
            start=speech.get('start_seconds');end=speech.get('end_seconds')
            if not number(start) or not number(end) or start<a or end>b or end<=start:errors.append(f'{sid}: speech window is invalid or outside shot.')
    if len(ids)!=len(set(ids)):errors.append('Duplicate shot IDs.')
    if shots and number(duration) and abs(prev-duration)>.001:errors.append(f'Final shot ends at {prev}s; packet declares {duration}s.')
    warnings.append('Human review still required: canon, reference pixels, physical feasibility, speech delivery, camera geography, and final rendered footage. These checks cannot certify them.')
    return {'mechanical_result':'needs_repair' if errors else 'passed','errors':errors,'warnings':warnings,'ready_for_generation':False,'note':'Readiness also requires active run authorization and creative/reference checks. This tool does not approve or submit work.'}

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python3 tools/preflight_scene.py path/to/scene.json')
    try:packet=json.loads(Path(sys.argv[1]).read_text())
    except (OSError,json.JSONDecodeError) as e:print(json.dumps({'mechanical_result':'invalid_input','error':str(e)}));raise SystemExit(2)
    result=check(packet);print(json.dumps(result,indent=2));raise SystemExit(1 if result['errors'] else 0)
