"""Build portable, generic stage guides from the curated learning register."""
from pathlib import Path
import json
from content import LESSONS

B = Path(__file__).resolve().parents[1]
ROOT = B / 'automation_learning'

EXAMPLES = {
 'L01': 'A visitor is finally recognized at reception. Their grip loosens and their shoulders lower. Relief does not have to become a smile.',
 'L02': 'A manager continues working while a visitor waits. The action can show power without adding a speech.',
 'L03': 'Someone can force a reassuring smile while still afraid. Encouragement does not instantly remove anxiety.',
 'L08': 'After a confrontation, allow time for an embrace and its emotional aftermath before the scene ends.',
 'L09': 'When asked for one revised prompt, return one complete prompt in the requested format.',
 'L12': 'If the user selects the first phone-call version after rejecting two revisions, continue from the first version.',
 'L14': 'Moving a story to a different city is an adaptation. Record its approval separately from the original setting.',
 'L17': 'Do not repeat a completed handshake or make a character who is already standing rise from a chair.',
 'L18': 'Show the listener when a revelation changes their understanding, if the current scene allows the speaker to remain offscreen.',
 'L20': 'A room used for an escape needs a usable door or window, a clear route, and enough space for the action.',
 'L21': 'An opening can establish one clear question: will the visitor be allowed inside?',
 'L22': 'A window can first mean confinement and later become an escape route. Preserve its location and physical state.',
 'L24': 'If an identity reference shows a shoulder strap but the bag must stay on the desk, use an approved reference that resolves that conflict.',
 'L25': 'A person approaching behind a seated character is not necessarily behind that character on the screen after a camera reverse.',
 'L31': 'If the workflow supplies separate narration segments, improve coverage inside each segment without merging those boundaries.',
 'L39': 'A generation job marked successful may still contain wrong acting or broken continuity. Record creative review separately.',
 'L44': 'A failed generation label alone does not establish whether the cause was service availability, inputs, or formatting.',
 'L45': 'The JSON value 4.5 seconds is invalid when unquoted. Use a numeric seconds field or a quoted string as required by the receiving schema. Resolve empty or misspelled reference tags.',
 'L47': 'Resume the selected active scene, even when an older handoff file points to a different scene.',
}

SELECTIONS = {
 'screenplay_learning': list(range(1,10)) + [11,12,13] + list(range(14,23)) + [29,30,38,40,42,46,47,48],
 'prompt_learning': [1,2,3,4,5,8] + list(range(9,14)) + [16,17,18] + list(range(23,49)),
}

SHARED = [
 'Use the current user request, approved project facts, and selected version. Historical examples are evidence, not new requests or permission to generate media.',
 'Keep each project’s names, world, ages, dialogue, costumes, and approved adaptations in its current input. Never import them from another project.',
 'Apply a lesson when its stated condition fits. A local preference or one successful repair is not a universal creative rule.',
 'Record what may change and what must stay the same. Resolve conflicts using the current brief; ask a focused question only when an unresolved choice blocks the requested result.',
 'Do useful work with known information. Mark assumptions and missing facts plainly; do not invent approvals, source dialogue, reference tags, or review evidence.',
 'Keep draft, selected, rejected, and approved states distinct. Only record approval when the user or authorized reviewer actually provides it.',
]

SCOPE = {
 'L08': 'Reserve enough time for this scene; no fixed extension length is a universal rule.',
 'L18': 'Check the current speaker-visibility rule before placing speech offscreen.',
 'L21': 'This is a writing principle, not a measured promise of audience retention.',
 'L31': 'Read limits and capabilities from the active tool contract. Historical prompt examples do not establish current settings.',
 'L33': 'Describe the intended look, then set supported resolution and frame rate through the active tool settings.',
 'L44': 'Record observed errors. Do not treat historical workaround suggestions as validated instructions.',
}

OVERRIDES = {
 'screenplay_learning': {
  'L29': {'title':'Check the planned runtime', 'when':'When the scene has a target duration.', 'rule':'Add the planned beat durations, then allow enough time for dialogue, physical action, reactions, and the ending. Mark unmeasured timing as an estimate.', 'example':'A short scene needs time for a person to approach, put down a cup, release it, and receive a response.', 'check':'Does the scene fit naturally without skipping causes or rushing the emotional change?'},
  'L30': {'title':'Separate dialogue, narration, thought, and silence', 'when':'When writing the sound plan.', 'rule':'Label who speaks, which words are spoken, which words are narration or internal thought, and where silence matters. Preserve supplied dialogue when required.', 'example':'A scene played under external narration can specify silent actors without adding new spoken lines.', 'check':'Can the next stage distinguish spoken words from action descriptions and production notes?'},
  'L38': {'title':'Plan for the required frame', 'rule':'Plan essential faces, hands, contact, and props so the intended action can remain readable in the requested crops. Mark final motion and crop checks for the rendered review.', 'check':'Can the planned staging support the requested frame, and is final crop review still recorded as pending?'},
  'L40': {'title':'Review the scene before polishing the wording', 'when':'Before handing off a screenplay.', 'rule':'Check story meaning, source facts, reveal limits, cause and consequence, geography, character intent, props, performance, and estimated timing. Keep unresolved problems visible.', 'check':'Does the written scene make sense and preserve the intended emotional change?'},
  'L46': {'rule':'Save the selected screenplay version, accepted elements, pending changes, and rollback target. A newer draft does not automatically replace the chosen one.', 'example':'The user accepts the dialogue but requests a new entrance. Dialogue remains protected while blocking is revised.', 'check':'Can the next stage identify the selected scene version and its unresolved changes?'},
  'L47': {'rule':'Record the project, active scene, selected screenplay version, physical and emotional end state, unresolved facts, pending changes, paused work, and next action.', 'check':'Can another person continue the scene without repeating completed action or using a rejected draft?'},
 },
 'prompt_learning': {
  'L01': {'rule':'Read the approved scene’s intended change in audience understanding or feeling. Preserve that change while translating it into generation instructions. Flag any missing dramatic intention.', 'check':'Does the prompt express the approved scene without silently rewriting its story?'},
 }
}

SCREENPLAY_INPUT = {
 'project_id':None, 'scene_id':None, 'request':None, 'requested_output_format':None,
 'source_excerpt':None, 'adjacent_beats':None, 'approved_project_facts':[], 'approved_adaptations':[],
 'selected_version':None, 'last_accepted_state':None, 'dramatic_intent':None,
 'knowledge_and_reveal_limits':[], 'exact_dialogue_to_preserve':[], 'protected_elements':[],
 'allowed_changes':[], 'target_duration_seconds':None, 'requested_crops':[], 'open_questions':[]
}
HANDOFF = {
 'schema_version':'1.0', 'project_id':None, 'scene_id':None, 'scene_version':None,
 'approval':{'status':'draft','evidence':None,'scope':None},
 'source_facts':[], 'approved_adaptations':[], 'dramatic_change':None,
 'audience_knowledge':{'before':None,'after':None,'keep_hidden':[]},
 'start_state':None, 'end_state':None, 'protected_elements':[], 'allowed_changes':[],
 'beats':[], 'beat_example':{'id':'B01','cause':None,'visible_action':None,'reaction':None,'result':None,'coverage_intent':None,'estimated_seconds':None},
 'dialogue':[], 'audio_plan':None, 'target_duration_seconds':None, 'requested_crops':[],
 'continuity_constraints':[], 'assumptions':[], 'open_questions':[], 'next_action':None
}
PROMPT_INPUT = {
 'request':None, 'scene_handoff':HANDOFF,
 'selected_prompt_version':None, 'last_accepted_render':None, 'requested_correction':None,
 'tool_contract':{'provider':None,'model':None,'mode':None,'prompt_format':None,'required_fields':[],
 'duration_seconds':None,'generation_boundaries':[],'text_limit':None,'text_limit_unit':None,
 'aspect_ratio':None,'resolution':None,'frame_rate':None,'audio_capabilities':None},
 'references':[], 'reference_example':{'exact_tag':None,'asset_id_or_path':None,'status':'unverified','controls':[],'must_not_control':[],'applies_to_beats':[]},
 'audio':{'allowed_sound_types':[],'voice_assignments':[],'supplied_recordings':[]},
 'output_count':None, 'open_questions':[]
}
PROMPT_OUTPUT = {
 'schema_version':'1.0','project_id':None,'scene_id':None,'scene_version':None,'prompt_version':None,
 'status':'draft','compiled_prompt':None,'prompt_format':None,'reference_bindings':[],
 'segments':[],'segment_example':{'id':'G01','duration_seconds':None,'shots':[]},
 'preflight':{'format':'not_checked','references':'not_checked','timing_arithmetic':'not_checked','speech_and_action_feasibility':'not_checked','tool_limits':'not_checked','continuity':'not_checked'},
 'changed_elements':[],'protected_elements':[],'assumptions':[],'open_questions':[],
 'job_status':'not_submitted','creative_review':{'status':'unreviewed','evidence':None,'findings':[]},'next_action':None
}

def build():
 ROOT.mkdir(exist_ok=True)
 for stage, numbers in SELECTIONS.items():
  screenplay = stage == 'screenplay_learning'
  title = 'Screenplay learning' if screenplay else 'Prompt learning'
  folder = ROOT / stage
  folder.mkdir(exist_ok=True)
  lessons=[]
  for source in LESSONS:
   if int(source['id'][1:]) not in numbers: continue
   lesson={k:source[k] for k in ('id','title','when','rule','example','check')}
   lesson['title']=lesson['title'].replace('your intention','creative intent')
   lesson['example']=EXAMPLES.get(source['id'],source['example'])
   lesson['scope']=SCOPE.get(source['id'],'Apply within the active brief and approved scene context.')
   lesson.update(OVERRIDES.get(stage,{}).get(source['id'],{}))
   lessons.append(lesson)
  purpose = ('Turn a brief or source excerpt into a clear, playable scene with a useful handoff.' if screenplay else 'Turn an approved scene into a complete generation prompt that fits the active tool and preserves the intended scene.')
  steps = ([
   'Read the request, source excerpt, relevant project facts, and last accepted scene state. Ask for adjacent beats only when continuity or reveal timing needs them.',
   'State what changes for the audience. Separate source facts, approved adaptations, and proposed choices.',
   'Write cause → visible action → reaction → result. Track character knowledge, physical positions, props, and emotional changes.',
   'Choose coverage for meaning. Check dialogue, estimated runtime, scene geography, and the intended crops.',
   'Review the scene using the checks below. Return the requested screenplay plus a structured scene handoff when the workflow requests one.',
   'Record the selected version and unresolved questions. Keep approval as draft or pending until it is actually given.'
  ] if screenplay else [
   'Read the selected scene handoff and the requested output. Confirm its approval scope. A missing approval permits a draft prompt, but does not establish approval or authorize a paid generation.',
   'Read the active tool contract and bind registered references to specific jobs: identity, clothing, environment, pose, continuity, voice, or style.',
   'Translate the approved beats into precise action, camera, performance, timing, continuity, and audio instructions. Resolve conflicting references before relying on extra text.',
   'Check total seconds and shot windows, then check speech and physical feasibility separately. Preserve required generation boundaries.',
   'Compile the exact requested format. Parse JSON when required, check tags and limits, and return a complete revised prompt after corrections.',
   'If media is later supplied, review what is actually visible and audible. Record technical completion separately from creative acceptance and propose the smallest useful repair.'
  ])
  output = ('The requested screenplay and a scene handoff containing facts, intent, causal beats, dialogue, start/end states, continuity, estimated timing, approval state, and open questions.' if screenplay else 'A complete prompt in the requested format, with checks, unresolved inputs, and version information in a separate handoff when allowed. If the integration expects only the prompt, keep tracking metadata outside that payload.')
  pack={'pack_version':'1.1','audience':'Any user or production team','stage':stage,'purpose':purpose,
   'use':'Load this JSON OR FEED_THIS.md as reusable stage guidance, then add the current input. Neither format depends on the other pack.',
   'evidence_status':'Generalized from a supplied production manual and prompt archive. Examples are illustrative. These lessons have not been validated by a new-scene transfer test.',
   'source_lookup':'Lesson IDs map to the parent handbook for optional evidence lookup; that handbook is not required to use this pack.',
   'shared_rules':SHARED,'workflow':steps,'expected_output':output,'lessons':lessons}
  (folder/'lessons.json').write_text(json.dumps(pack,ensure_ascii=False,indent=2)+'\n')
  lines=[f'# {title} — automation feed','Version 1.1 · Generic guidance for any user or production team.',
   f'## Purpose\n\n{purpose}',
   '## How to use this file\n\nLoad this file as stage guidance, then add the current project and scene input. It includes all shared rules needed for this stage. The other learning pack is not required. Use `lessons.json` instead if the automation reads structured guidance; do not load both copies.',
   'These are conditional lessons derived from production experience. Examples below are generic illustrations, not facts about the current project. New-scene transfer performance remains untested.',
   '## Shared rules\n\n'+'\n'.join(f'- {x}' for x in SHARED),
   '## Working sequence\n\n'+'\n'.join(f'{i}. {x}' for i,x in enumerate(steps,1)),
   f'## Expected output\n\n{output}', '## Lessons']
  for l in lessons:
   lines += [f"### {l['id']} · {l['title']}\n\n**When:** {l['when']}\n\n**Do:** {l['rule']}\n\n**Example:** {l['example']}\n\n**Check:** {l['check']}\n\n**Scope:** {l['scope']}"]
  lines+=['## Learning from the next use\n\nRecord the problem, the single change tried, what stayed protected, the observed outcome, and whether the result was approved. Keep a scene-specific choice local. Test a proposed general lesson on a different scene before claiming it improves production. Lesson IDs allow optional evidence lookup in the parent handbook.']
  (folder/'FEED_THIS.md').write_text('\n\n'.join(lines)+'\n')
  input_data=SCREENPLAY_INPUT if screenplay else PROMPT_INPUT
  output_data=HANDOFF if screenplay else PROMPT_OUTPUT
  for name,data in [('input_template.json',input_data),('output_template.json',output_data)]:
   (folder/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
  (folder/'README.md').write_text(f'''# {title}

**Feed [FEED_THIS.md](FEED_THIS.md) to the assistant at this stage.**

{purpose}

1. Load `FEED_THIS.md`, or load `lessons.json` if the system prefers JSON. They contain the same guidance.
2. Fill `input_template.json` with the current scene details. Remove example helper fields before submission; they describe record shapes and are not real production data.
3. Request the desired output. `output_template.json` shows the suggested handoff shape.

{len(lessons)} lessons. Shared principles are included so this folder can be copied and used independently. Guidance is generic; project facts and user preferences come from the current input.

Templates are planning records, not a provider API schema. Blank fields mean unknown, not approved. Keep unknowns explicit. The actual receiving workflow decides its required fields and format.

{'After the scene is selected and approved, pass the populated output to the prompt stage as `scene_handoff`.' if screenplay else 'Place the screenplay stage’s populated output in `input_template.json` → `scene_handoff`. Supply current references and tool settings separately. Preserve the approved story.'}
''')
 ROOT.joinpath('README.md').write_text('''# Two separate automation learning packs

These folders are for every user. All examples inside them use generic roles. Project names, characters, personal preferences, and model settings are supplied with each task.

```text
automation_learning/
├── screenplay_learning/  → Write what happens and why
│   └── FEED_THIS.md
└── prompt_learning/      → Tell the generator how to show it
    └── FEED_THIS.md

Scene input + screenplay learning
                ↓
        Screenplay + scene handoff
                ↓
          Scene approval
                ↓
Approved handoff + references + tool settings + prompt learning
                ↓
       Prompt → checks → generation when authorized → review
```

## Which file should I feed?

| Stage | Feed this | Add current task information |
|---|---|---|
| Screenplay | [screenplay_learning/FEED_THIS.md](screenplay_learning/FEED_THIS.md) | Brief, relevant script excerpt, approved facts, last state, requested change |
| Prompt writing | [prompt_learning/FEED_THIS.md](prompt_learning/FEED_THIS.md) | Approved scene handoff, references, current tool settings, audio requirements |

Every folder has five files: `README.md` explains use; `FEED_THIS.md` is the complete stage guide; `lessons.json` is the equivalent structured guide; `input_template.json` and `output_template.json` define suggested task records. Feed either Markdown or JSON guidance, not both.

Each pack includes relevant shared principles. This intentional overlap lets either folder work alone. All 48 parent-handbook lessons are represented across the two packs. The screenplay output fits the prompt input’s `scene_handoff` field.

No full script collection is needed to load these lessons. Supply a specific scene and adjacent beats when the current task needs source facts or continuity checks. The parent handbook preserves historical evidence; it is optional for these feeds. Source-specific names and reference tags are not defaults for a new production.

These packs are ready to load manually or connect to an automation. Creating these folders does not itself connect a running workflow or prove improved creative results.
''')
 return {stage:len(numbers) for stage,numbers in SELECTIONS.items()}

if __name__=='__main__': print(build())
