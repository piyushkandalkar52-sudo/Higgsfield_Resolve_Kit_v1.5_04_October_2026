# Project boundaries

## HSF

Family cruelty, hidden status, survival, and the sisters’ protective bond.

Layla and Sophie; Harrison family.

D00055 D00056 D00057 D00058

A001–A010

Keep age, family relationship, and casting decisions tied to the selected adaptation; casting exploration is not a cast approval.

## IMTS

Neglect, intellectual ability, betrayal, and concealed identity.

Kira, Jake, Isla, Poppy.

D00059 D00060 D00061 D00062 D00063

A030–A066

Boston adaptation and earlier Korean references coexist in the archive. Verify the active world before reusing costumes, school references, or dialogue.

## TRA

Romantic uncertainty, wealth contrasts, family and control.

Amelia, Tomas, Javier, Max.

D00064 D00065 D00066 D00067

A024–A029; café edits A012–A018 are only thematically linked

Contemporary café/phone/taxi material and royal-period material require separate scene/world versions. Do not import the current royal project’s defaults into every historical scene.

## TDMB

Coercive family power, confinement, art, and emerging trust.

Alessandra, Edgar, Desmond, William, Rowan.

D00068 D00069 D00070 D00071

A068–A098

Preserve injuries, doorway/window mechanics, and the selected winter world. Animated Alessandra is a separate exploration.

## DP / Little Princess

Dispossession, corporate revenge, mentorship, and psychological danger.

Destiny, Ryan, Mrs Jones, David, Samuel.

D00072 D00073 D00074 D00075

No secure match identified

Samuel is not the IMTS Samuel. Verify childhood dates and age progression. Three months versus three years may be deliberate negotiation.

## HIH / DC Wilson material

Humiliation, concealed status, love, duty, and restrained authority.

Charlie, Claire, Doris, Aunt Lena, Wilson family.

D00076 D00077 D00078 D00079

No secure match identified

Use the active DC winter adaptation and current scene; never infer the next task from stale history.

## Animated Alessandra exploration

Original adult character development, mask and style experiments.

Alessandra in an animation development branch.

D00207 D00208 D00209 D00210 D00275 D00276 D00277

No secure match identified

No final character approval established; do not replace the live-action cast or world with this branch.
