# Creative judgment

What should the audience see, understand, and feel?

Source-derived working guidance. Apply the active brief and project context. See 00_START_HERE.md for scope and evidence limits.

## L01 Decide what changes

When: Before planning any scene.

State what the audience understands or feels before the scene, what causes a change, and what they understand afterward.

Example: Destiny is recognized at reception; her defensive grip loosens. The change is relief, which may leave her mouth neutral.

Check: Can every important shot be connected to that change?

Scope: Apply within the current brief and approved scene context.

Evidence: D00040 D00041 D00042 D00045 D00047. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L02 Turn your intention into visible behavior

When: When the brief uses an internal feeling or motive.

Choose observable behavior and a trigger. Keep the emotional meaning intact when translating the brief.

Example: Ryan continuing his work while Destiny waits can express power without an invented speech.

Check: Would a viewer understand the relationship from the action and response?

Scope: Apply within the current brief and approved scene context.

Evidence: D00044 D00045 D00046 D00144. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L03 Use precise emotional distinctions

When: When similar emotion words produce the wrong performance.

Separate relief, joy, reassurance, shame, anxiety, curiosity, and anger. Use one or two cues per beat.

Example: A forced reassuring smile can coexist with fear. Claire receiving encouragement need not instantly lose her anxiety.

Check: Did the revision change the intended feeling into a different one?

Scope: Apply within the current brief and approved scene context.

Evidence: D00145 D00149 D00150 D00151 D00372. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L04 Match intensity to this event

When: When quiet acting feels weak or heightened acting feels exaggerated.

Choose intensity from stakes, genre, character, and framing. Treat action strength and facial emotion as separate decisions.

Example: Forced separation may require active resistance; a business negotiation may show controlled resolve.

Check: Does intensity clarify this beat without flattening the character?

Scope: Apply within the current brief and approved scene context.

Evidence: D00146 D00147 D00148 D00265 D00266 A019 A021 A022. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L05 Make every camera choice earn its place

When: When asking for cinematic coverage.

Choose the view that reveals information, relationship, scale, or emotional change. A push, orbit, cut, or hold needs a purpose.

Example: The café can become stronger through fewer actor shots; a protective hug can need one sustained take.

Check: What does this camera choice let the audience notice?

Scope: Apply within the current brief and approved scene context.

Evidence: D00087 D00088 D00089 D00125 D00126 D00127 A001 A024 A060 A063. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L06 Make worlds believable through use

When: When designing poverty, wealth, school, hospital, or workplace.

Build the social meaning through function, maintenance, scale, privacy, and behavior.

Example: An older modest home can be clean. A primary classroom needs child-sized furniture and learning materials.

Check: Does the place support the story and age group rather than only a surface style?

Scope: Apply within the current brief and approved scene context.

Evidence: D00173 D00175 D00176 D00177 D00179 A038 A066. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L07 Offer genuinely different choices

When: When presenting design alternatives.

Vary meaningful structure: layout, silhouette, construction, circulation, materials, or dramatic function. Explain the difference plainly.

Example: Two costumes should differ in construction and role, not only color.

Check: Would choosing between these options change a meaningful creative decision?

Scope: Apply within the current brief and approved scene context.

Evidence: D00181 D00182 D00204 D00205. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L08 Leave room for the feeling to land

When: When the action is complete but the emotional payoff feels missing.

Reserve time for recognition and aftermath. Add a dedicated continuation if the current clip cannot carry it naturally.

Example: Layla and Sophie needed more time in their embrace after the confrontation.

Check: Is the ending a readable emotional state rather than several rushed actions?

Scope: The manual reports an eight-second extension request; the archive labels both hug entries FAILED. Neither establishes an approved final hug render.

Evidence: D00057 D00170 D00228 D00244 D00245 D00246 A001 A002. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.
