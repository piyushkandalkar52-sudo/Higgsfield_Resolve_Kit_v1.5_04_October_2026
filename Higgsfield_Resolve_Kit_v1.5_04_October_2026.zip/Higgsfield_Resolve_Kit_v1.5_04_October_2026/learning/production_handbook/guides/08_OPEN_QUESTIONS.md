# Smallest additional inputs when needed

## G01

Needed when validating production quality

Accepted and rejected renders with the associated prompt ID and a short reason

To check whether the proposed repair actually worked.

Start with the hug, café book placement, or one doorway sequence. Full scripts are unnecessary for this check.

## G02

Needed before adapting a particular scene

The scene excerpt plus the preceding and following beat

To verify exact dialogue, facts, and consequences before changing the screenplay.

Request one relevant excerpt when a scene is chosen; do not upload all scripts merely to use this library.

## G03

Needed before combining project assets

The active show/world version and approved reference set

To resolve Boston/Korean variants, contemporary/royal TRA, and live-action/animated Alessandra.

Confirm the chosen branch for the next production run.

## G04

Needed only for the DP childhood timeline

Ages, childhood year, present year, and the relevant script lines

The manual flags an unresolved relation between eight-year progression and early-2010s versus 2025–26 dates.

No automatic date or vehicle-era correction is justified yet.

## G05

Helpful for learning communication more deeply

One complete chat around a difficult correction or rollback

The Word manual summarizes 27 conversations; it does not preserve all turn-by-turn wording and rejected assistant reasoning.

Export a representative session only if you want a more exact model of how you communicate.

## G06

Needed before automated submission

Current adapter schema, tag registry, generation boundaries, and measured limits

Historical tool names and limits cannot establish the current integration contract.

Use the existing production adapter and its verified settings; this documentation sends no paid jobs.
