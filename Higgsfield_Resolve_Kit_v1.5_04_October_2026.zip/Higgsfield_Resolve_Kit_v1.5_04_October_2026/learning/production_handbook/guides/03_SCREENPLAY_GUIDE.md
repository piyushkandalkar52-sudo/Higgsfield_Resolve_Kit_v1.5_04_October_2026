# Screenplay

What happens, why it happens, and what changes?

Source-derived working guidance. Apply the active brief and project context. See 00_START_HERE.md for scope and evidence limits.

## L14 Keep facts and adaptation separate

When: When interpreting or relocating a story.

Track source facts, authorized adaptation, assistant interpretation, and approved production assets separately.

Example: Boston is an adaptation in the IMTS material; it is not evidence that the original story was set there.

Check: Can each changed story fact be traced to its source or approved adaptation?

Scope: Apply within the current brief and approved scene context.

Evidence: D00036 D00037 D00063 D00178 D00179 D00313. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L15 Protect who knows what

When: When a mystery, concealed identity, or delayed reveal matters.

Record character knowledge, audience knowledge, and the permitted reveal point. Clarify the event while preserving the intentional secret.

Example: An acquisition can be legible while the new chairman remains unseen.

Check: Does a shot, line, face, or symbol reveal information too early?

Scope: Apply within the current brief and approved scene context.

Evidence: D00048 D00049 D00050 D00213. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L16 Write the physical cause and consequence

When: When an action involves transfer, crossing, restraint, service, or rescue.

Break the action into valid states: preparation, contact, movement, release, and result.

Example: Serving coffee includes approach, placement, release, and withdrawal. Forced entry must visibly differ from voluntary entry.

Check: Are any essential state changes missing or repeated?

Scope: Apply within the current brief and approved scene context.

Evidence: D00084 D00085 D00086 D00133 D00134 D00135 A022 A027 A028 A046. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L17 Begin from the last accepted state

When: When continuing an existing scene.

Use the last physical and emotional state already reached; adapt obsolete literal actions while preserving their dramatic purpose.

Example: Do not replay a completed handshake or make a standing Doris leap from a chair.

Check: Does the next beat require a reset that the audience never saw?

Scope: Apply within the current brief and approved scene context.

Evidence: D00051 D00052 D00053 D00247 D00248 D00249 D00250 A024 A025 A026. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L18 Choose reactions when meaning changes

When: When deciding which face to show during dialogue.

Track the active line, who understands something new, and whose response changes the scene.

Example: The Duke can react while Alessandra continues speaking offscreen when the local coverage calls for it.

Check: Does the reaction answer a dramatic question rather than fill a shot quota?

Scope: Speaker visibility requirements are scene-specific. Resolve any current project rule before using offscreen dialogue.

Evidence: D00152 D00153 D00154 A076 A080 A082. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L19 Choose the grammar of time

When: When writing a montage, memory, or age progression.

Declare whether this is one continuous event, separate moments, compressed years, or a continuous transformation. Vary activities and feelings appropriately.

Example: Four years of romance should include routine care, shared study, teasing, and quieter moments rather than constant laughter.

Check: Are costume, age, prop, and location changes consistent with the chosen passage of time?

Scope: Apply within the current brief and approved scene context.

Evidence: D00061 D00167 D00168 D00169 A048 A058 A059. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L20 Design the set around required action

When: When a scene depends on entrances, escape, or movement.

Establish routes, usable thresholds, scale, and camera access before decorating.

Example: Alessandra’s room needs a workable door and window route, plus places that can support the escape.

Check: Can the scene actually be staged in the proposed set?

Scope: Apply within the current brief and approved scene context.

Evidence: D00172 D00173 D00174 D00179 A087 A095 A096. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L21 Build an opening around a dramatic question

When: When designing a promo opening.

Make the consequential event understandable quickly; carry a question through the next beats and let the response matter.

Example: Will the child be taken? Will the family help the sisters? Will Destiny be admitted?

Check: Do the opening image, action, and words support the same question?

Scope: These are editorial principles. The sources provide no measured retention gains.

Evidence: D00225 D00226 D00227 D00228 A009 A020 A023. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L22 Let motifs develop meaning

When: When repeating a prop, threshold, or visual symbol.

Track its first meaning, later changes, physical state, and reveal limits.

Example: TDMB’s windows can connect confinement and escape; a portfolio can register changing anxiety.

Check: Does the repetition develop the story, and is the symbol established or authorized?

Scope: Apply within the current brief and approved scene context.

Evidence: D00215 D00216 D00217. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.
