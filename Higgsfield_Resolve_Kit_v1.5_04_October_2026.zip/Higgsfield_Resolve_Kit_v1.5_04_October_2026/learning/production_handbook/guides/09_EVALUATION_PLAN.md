# Test the lessons on new scenes

## E01

A heroine is recognized and feels safer, but does not become happy.

L03

Show a small release of tension with a neutral mouth.

Broad smile or instant confidence.

## E02

Remove two paintings from an approved aged artist room.

L11 L42

Preserve room wear, books, furniture, lighting, and function.

Whole-room cleaning or redesign.

## E03

A reference fixes positions but a new OTS angle is requested.

L23 L26

Preserve world positions and describe the new view’s background.

Copying the master angle or swapping characters.

## E04

A bag must be on the desk while the identity image contains its strap.

L24

Identify the conflict and propose a bounded asset repair.

Add stronger full-appearance locks.

## E05

The greeting handshake already happened in the accepted clip.

L17

Continue the conversation from the current state.

Replay the handshake.

## E06

A silent visual uses externally supplied narration.

L30

Generate picture with the appropriate silence contract; preserve narration placement outside it.

Generate an extra narrator or contradictory dialogue.

## E07

A 7-second plan has seven shot headings totaling 8 seconds.

L29

Flag the mismatch; propose a revised feasible plan.

Claim exact 7-second readiness.

## E08

The new character costume reference carries a different pose.

L35

Transfer clothing within scope and preserve the requested pose and identity.

Copy the outfit model’s face or pose.

## E09

The user returns to version 1 after rejecting versions 2 and 3.

L12 L46

Record version 1 as the selected baseline.

Continue version 3 because it is newest.

## E10

The generation result says SUCCESS and there is no creative review.

L39

Mark technical success and creative acceptance unknown.

Promote the take to approved.

## E11

Snow is removed from the interior, but the action says brush snow from hair.

L34

Revise the dependent action to dry-hair care.

Only add no indoor snow to negatives.

## E12

A show uses Samuel as an antagonist; another uses Samuel as an assistant.

L14

Keep identities and references namespaced by show.

Merge the characters or their roles.
