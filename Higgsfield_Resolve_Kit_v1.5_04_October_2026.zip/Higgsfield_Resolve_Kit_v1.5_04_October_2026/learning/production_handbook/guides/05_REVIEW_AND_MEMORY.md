# Review and memory

Did it work, what needs repair, and where do we resume?

Source-derived working guidance. Apply the active brief and project context. See 00_START_HERE.md for scope and evidence limits.

## L39 Keep generation status separate from approval

When: When recording results or choosing examples.

Store technical job status and creative review separately. Approval belongs to a specific result, element, or interval.

Example: SUCCESS in the archive does not establish accepted acting, correct continuity, or usable timing.

Check: Is the actual acceptance evidence linked, and is its scope clear?

Scope: Apply within the current brief and approved scene context.

Evidence: D00031 D00032 D00351 D00356 A003 A017 A018. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L40 Review story before polish

When: When judging a take.

Check story meaning, causal action, geography, identity, props, performance, timing, audio, text, and crop before visual polish.

Example: Beautiful lighting cannot compensate for the child entering voluntarily when the event requires forced separation.

Check: Can any story or continuity failure be hidden by an average score? Keep it visible.

Scope: Apply within the current brief and approved scene context.

Evidence: D00368 D00369 D00370 A020 A022. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L41 Diagnose a specific failure

When: When a result is wrong.

Classify the observed issue, record the affected frame or interval, and separate observation from the suspected cause.

Example: An unwanted laptop was reported; blaming the phrase laptop-style bag is a hypothesis.

Check: Does the diagnosis show evidence and a testable next change?

Scope: Apply within the current brief and approved scene context.

Evidence: D00229 D00230 D00231 D00232. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L42 Repair the smallest failing part

When: When most of an output works.

List protected elements, change the failing component, and check that the repair did not regress accepted elements.

Example: Reduce a few paintings while preserving the room’s worn surfaces, books, furniture, and lived-in feeling.

Check: Did a local edit accidentally reset the scene’s visual story?

Scope: Apply within the current brief and approved scene context.

Evidence: D00091 D00092 D00259 D00260 D00261 D00262 D00353 A012 A017. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L43 Change method after repeated failure

When: When successive wording changes reproduce the same defect.

Check contradictions, reduce simultaneous actions, replace the reference, isolate the component, or choose another shot method.

Example: A third-person discovery view can preserve the art-view beat when POV keeps creating binocular framing.

Check: Does the new test address a changed cause or merely add another prohibition?

Scope: Apply within the current brief and approved scene context.

Evidence: D00093 D00094 D00095 D00121 D00233 D00234 D00235. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L44 Preserve uncertainty about tool failures

When: When a generation is rejected or a model limitation is suspected.

Record the actual returned status or error and keep causal explanations provisional unless tested.

Example: A FAILED archive label alone does not tell us whether the cause was service, content, reference, or prompt format.

Check: Are guesses about filters or keywords being mislabeled as proven fixes?

Scope: Historical workaround suggestions are source material, not instructions for the current system.

Evidence: D00038 D00236 D00237 D00238 D00357 A001 A002. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L45 Check the delivered prompt itself

When: Before generation or handoff.

Verify syntax when JSON is required, registered tag membership, character limits, output count, and exact requested format.

Example: A006 contains an unquoted value, 4.5 seconds, so strict JSON parsing fails. A033 has a blank tag assignment; A071 contains @duke_bdfor.

Check: Does a valid machine input also retain the intended action, references, and words?

Scope: Apply within the current brief and approved scene context.

Evidence: D00240 D00241 D00365 D00366 A006 A033 A071. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L46 Keep selected, rejected, and provisional versions

When: When recording a review.

Save accepted render, exact qualification, requested repair, and rollback target. Do not let a newer file silently replace the chosen one.

Example: Everything good except the book does not prove that the later book repair worked.

Check: Can the editor identify the approved take and the pending exception?

Scope: Apply within the current brief and approved scene context.

Evidence: D00031 D00032 D00106 D00273 D00274 D00354. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L47 Make the next action explicit

When: When stopping or handing off a run.

Record active scene, last accepted state, current tags, in-flight jobs, pending corrections, paused work, deprecated assets, and exact next action.

Example: The DC sequence should resume its active scene even if an older handoff points to the memorial.

Check: Could another agent continue without replaying a completed action or resurrecting a rejected asset?

Scope: Apply within the current brief and approved scene context.

Evidence: D00079 D00107 D00108 D00109 D00386. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L48 Test whether a lesson transfers

When: When adding a new rule to the library.

Store condition, intervention, protected elements, evidence, and status. Test on a different scene before claiming a general improvement.

Example: A longer hug supports emotional aftermath in that context; it does not require every ending to be eight seconds.

Check: Is this one scene preference, repeated evidence, a hypothesis, or a measured result?

Scope: Apply within the current brief and approved scene context.

Evidence: D00030 D00228 D00362 D00363 D00364. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.
