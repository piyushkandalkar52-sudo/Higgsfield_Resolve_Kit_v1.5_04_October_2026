# User collaboration

How should the assistant interpret and deliver your request?

Source-derived working guidance. Apply the active brief and project context. See 00_START_HERE.md for scope and evidence limits.

## L09 Deliver the exact requested kind of work

When: When the user asks for a prompt, edit, alternatives, or media.

Match the requested output type, count, format, and scope. A prompt request produces a prompt.

Example: The manual records image-generation responses to prompt-only requests as delivery failures.

Check: Did the response provide the requested artifact and stay within authorized work?

Scope: Apply within the current brief and approved scene context.

Evidence: D00239 D00240 D00241 D00332. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L10 Return the complete revised prompt

When: When a prompt needs correction.

Provide a complete usable revision while keeping the conceptual change as small as the request permits.

Example: Fix the book placement and preserve camera, clothes, lighting, acting, and the completed handshake.

Check: Can the user use the revision directly, and did unrelated choices drift?

Scope: Apply within the current brief and approved scene context.

Evidence: D00090 D00091 D00092 D00305 D00306 D00307 A012 A013 A017. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L11 Read corrections within their scope

When: When a user changes one part of a scene.

Record what changed, what stays protected, and where the correction applies. Later scene-specific direction can narrow a broad default.

Example: A request for new lighting can preserve architecture. A blocking reference need not dictate the lens or opening angle.

Check: Did the assistant widen a local correction into an unrequested redesign?

Scope: Apply within the current brief and approved scene context.

Evidence: D00030 D00098 D00100 D00105 A011 A080. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L12 Respect the selected version and paused work

When: When a later attempt is rejected or the user changes focus.

Record the chosen baseline, rejected versions, paused sequence, and next action. Support a rollback to an earlier version.

Example: Doris’s first phone version became the active baseline after two later revisions were rejected.

Check: Does the next action follow the selected state rather than chronological recency?

Scope: Apply within the current brief and approved scene context.

Evidence: D00106 D00108 D00109 D00271 D00272 D00273 D00274. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L13 Explain the decision in scene language

When: When an instruction such as more cinematic or more emotional is ambiguous.

Identify the concrete missing element and connect the proposed change to its purpose. Mark unresolved interpretation rather than presenting it as the user’s intention.

Example: More cinematic may mean stronger foreground depth, clearer scale, or a more revealing reaction.

Check: Is the explanation about what the viewer sees and feels, with uncertainty stated where needed?

Scope: Apply within the current brief and approved scene context.

Evidence: D00127 D00231 D00232 D00371 D00372 D00373. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.
