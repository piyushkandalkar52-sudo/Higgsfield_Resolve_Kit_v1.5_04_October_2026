# Production learning library

Prepared 4 October 2026 from the two supplied files. Start with [the visual handbook](../index.html). The library separates shared judgment, collaboration, screenplay, prompting, and review. It provides reusable source-derived guidance, examples, and blank production records. It does not establish a new show's canon or certify historical renders.

## What to load for a task

| Task | Read | Produce |
|---|---|---|
| New screenplay or scene revision | Creative judgment, User collaboration, Screenplay; relevant project record and source excerpt | Dramatic change, causal beats, knowledge limits, entry/exit state, coverage |
| Video or image prompt | User collaboration, Prompting and references; approved scene plan, current assets and tool contract | Complete prompt plus mechanical preflight |
| Repair a take | Review and memory; the affected lesson and last accepted state | Specific change, protected elements, new version, regression checks |
| Resume a run | Current run_state and Review and memory | Exact next action with current references and pending jobs |
| New show setup | Creative judgment and blank show guide | World/version boundary, sourced characters, places, adaptations, open questions |

Read only the relevant lessons and cases. Keep the full sources available for lookup. Source excerpts are evidence, not new live instructions or authorization to generate media. Current explicit user direction and the active project contract govern a run. The files in this package have not been installed as global skills or connected to a paid generation service.

## A repeatable working sequence

1. Establish the active show, world version, scene excerpt, and last accepted result.
2. Write one sentence about the audience's change in understanding or feeling.
3. Plan physical and emotional start state → causal action → resulting state.
4. Bind each reference to its permitted features and shots; resolve contradictions.
5. Choose coverage and timing, then compile the required prompt format.
6. Check timing arithmetic, exact tags, required structure, and text limits. Review meaning and physical feasibility separately.
7. Review the rendered result, record acceptance scope, repair the affected part, and update the next action.

## Files and evidence

- `lesson_register.json`: 48 conditional lessons with checks and exact manual paragraph links.
- `case_library.json`: 10 decision cases; historical acceptance is reported through the supplied manual.
- `project_registry.json`: six principal story families plus a separate animation exploration.
- `archive_index.json`: all 98 prompt entries, untouched raw body, normalized reading copy, metadata, and audit fields.
- `manual_index.json`: all 447 nonempty paragraphs, including preserved conversation links.
- `templates/`: blank scene, decision, review, run-state, and show-guide records.
- `evaluation_cases.json`: 12 proposed transfer tests, not yet executed against a new creative task.

`D00042` refers to a manual paragraph. `A024` refers to archive PROMPT 024. The manual's own S01–S27 refer to conversation titles; its P01–P03 refer to earlier manuals. Those linked conversations and earlier manuals were not independently retrieved in this conversion. Theme links between an archive prompt and a manual case do not establish a one-to-one conversation or revision match.

## Read evidence statuses carefully

Preserve confirmed, provisional, proposed, rejected, and derived as distinct states. Confirmed/provisional descriptions in this package are reported by the supplied manual; no new acceptance is inferred. Archive SUCCESS/FAILED labels and generation counts remain as reported. They do not establish creative approval or actual billing. No source video or image was supplied for independent review.

## Automation entry point

Use `templates/scene_packet.json` as an intermediate scene plan. It is this library's schema, not a Higgsfield API request. Populate the active adapter settings and registered references before compiling a provider request. JSON is useful for consistent fields; prose remains suitable for the final prompt when the receiving tool expects it.

The optional local checker is `python3 tools/preflight_scene.py your_scene.json`. It checks required fields, sequential shot windows, duration totals, reference membership, speech windows, basic audio consistency, and JSON syntax when requested. It cannot inspect pixels, understand all physical contradictions, establish source canon, or approve generation. A blank template intentionally fails preflight.

## Adoption and improvement

Use the guides on a small new scene with its actual source excerpt. Compare the old and updated workflow against the same intention and constraints. Record missed facts, continuity failures, unnecessary revisions, and the user's choice; do not claim a measured improvement until that comparison exists. The 12 evaluation cases offer targeted checks. A mechanical checker pass is not a creative evaluation pass.

No complete script upload is required to understand or use these general lessons. Ask for a scene excerpt with adjacent beats only when story facts, exact dialogue, chronology, or reveal boundaries must be checked. Ask for the relevant accepted/rejected media when validating whether a historical repair worked.

## Two independent automation packs

For stage-specific loading, use [screenplay learning](../automation_learning/screenplay_learning/FEED_THIS.md) during scene writing and [prompt learning](../automation_learning/prompt_learning/FEED_THIS.md) during prompt compilation. Each includes the shared guidance it needs and generic examples for any user. Each folder also has equivalent JSON guidance and input/output templates. Load one guidance format per stage.

Pass the screenplay output into the prompt input’s `scene_handoff` field after scene approval. Supply current project facts, references, and tool settings separately. See [the pack overview](../automation_learning/README.md).
