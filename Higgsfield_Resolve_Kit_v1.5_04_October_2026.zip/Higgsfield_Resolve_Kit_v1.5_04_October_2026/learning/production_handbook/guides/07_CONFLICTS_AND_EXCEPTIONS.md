# Conflicts and exceptions

## Fast cuts or one held shot

Choose by the information and emotional change. A continuous embrace and a quick confrontation can both be appropriate.

L05 L08 L18

A001 versus A008

## Restrained acting or strong distress

Set intensity for the event and character; keep facial emotion distinct from the strength of physical action.

L03 L04

D00146–D00154

## Copy the master or use a new camera

Give the reference a domain: opening composition, blocking, identity, or environment. Preserve only its authorized domains.

L11 L23

A080 separates composition from positions; A096 restricts a reference to a later shot

## Repeat locks or keep prompts short

Repeat fragile facts where they matter. Keep stable facts once and check the current length limit.

L32

D00297–D00298

## Speech, ambience, or total silence

Use the active clip’s audio contract and map every voice. Historical audio choices remain local.

L30

A063 silent insert; A024 voice references

## Old long clips or current shorter run limits

Archive durations describe historical drafts. Select current model mode, limits, and approved run settings before compilation.

L29 L31

A003 and A007 have long targets plus arithmetic mismatches

## Most recent draft or approved draft

Follow the selected baseline and record rollback explicitly. Archive numbering alone does not establish revision order.

L12 L46

D00271–D00274

## SUCCESS label or accepted creative result

Record technical completion separately from acceptance and its scope.

L39

96 archive entries carry SUCCESS; no supplied renders were independently reviewed
