# Prompting and references

How do we communicate the scene to the generator?

Source-derived working guidance. Apply the active brief and project context. See 00_START_HERE.md for scope and evidence limits.

## L23 Give each reference one clear job

When: When binding images, video, or audio to a prompt.

Specify which features each reference controls, which it must not control, and which shots use it.

Example: A continuity clip may control positions and emotion while allowing a new camera angle.

Check: Could two references be claiming control over the same feature in incompatible ways?

Scope: Apply within the current brief and approved scene context.

Evidence: D00097 D00098 D00099 D00100 A001 A024 A080 A096. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L24 Fix conflicting inputs at the source

When: When repeated text changes cannot remove a visible contradiction.

Inspect the reference, correct or replace the conflicting asset, then retry a bounded change.

Example: Charlie’s bagless character reference removed a strap that conflicted with the bag-on-desk state.

Check: Does the input still visibly demand what the prompt forbids?

Scope: Apply within the current brief and approved scene context.

Evidence: D00101 D00102 D00267 D00268 D00269 D00270. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L25 Keep world, body, and screen directions separate

When: When describing left/right, approach, or a reverse view.

Locate the action relative to stable architecture first; specify anatomical side separately from camera-relative screen position.

Example: Tomas approaching behind Amelia’s seated body does not always mean behind her in the frame.

Check: Would the instruction still be true after the camera reverses?

Scope: Apply within the current brief and approved scene context.

Evidence: D00110 D00111 D00112 D00113 D00114 A024 A080 A096. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L26 Check every camera view against the room

When: When adding arcs, reverses, POVs, or overheads.

State what lies behind each subject from that camera position; reduce camera travel when it breaks the scene.

Example: A camera looking outward from a building cannot place the same façade behind approaching people.

Check: Can a simple floor plan satisfy the camera, subject, and background instructions?

Scope: Apply within the current brief and approved scene context.

Evidence: D00115 D00116 D00117 D00118 D00119 D00120 D00123 D00124 A030 A068 A093. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L27 Track props through occlusion

When: When an object passes behind a body or across cuts.

Record owner, count, position, orientation, contact, and permitted transitions. Hidden objects keep their state.

Example: The book stays beside the cups when a hand or actor temporarily covers it.

Check: Check before hiding, during contact, after reappearance, and at the ending.

Scope: Apply within the current brief and approved scene context.

Evidence: D00129 D00130 D00131 D00132 D00249 A012 A013 A024. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L28 Budget hands and bodily movement

When: When a shot combines props, contact, and movement.

Assign hand use and body orientation; include a release before a hand performs another task.

Example: A two-handed rescue requires putting down bags first; a phone call requires raising the phone.

Check: Is any hand occupied by incompatible actions or any head turn physically implausible?

Scope: Apply within the current brief and approved scene context.

Evidence: D00136 D00137 D00138 D00141 A027 A046. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L29 Check time in two separate passes

When: Before submitting a timed sequence.

First verify shot arithmetic, gaps, and overlaps. Then check whether speech and physical action can fit naturally.

Example: A 25-second declared prompt can contain 28 seconds of listed shots; arithmetic repair alone cannot prove the dialogue fits.

Check: Are declared duration, timed shots, speech windows, and final hold all feasible?

Scope: Apply within the current brief and approved scene context.

Evidence: D00155 D00156 D00157 D00158 D00159 A003 A007 A040 A066. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L30 Declare the audio contract for this clip

When: When adding voices, fixed recordings, narration, or silence.

Distinguish voice identity from supplied dialogue audio. Map each speaker and specify exactly which sound types are allowed.

Example: A silent visual under external narration must not generate its own narration; a voice sample does not set the new line’s duration.

Check: Do audio instructions conflict, add a speaker, or bind the wrong voice?

Scope: Apply within the current brief and approved scene context.

Evidence: D00160 D00161 D00162 D00163 A024 A063 A089 A094. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L31 Preserve the automation boundaries

When: When compiling a scene for an external workflow.

Keep the current system’s generation segments, exact tags, length units, and required format intact.

Example: Dramagic’s fixed narration segments can contain improved internal coverage without being merged.

Check: Does the compiled output still fit the current integration contract?

Scope: Historical limits are evidence of a past contract, not current provider specifications. Confirm the active adapter before generation.

Evidence: D00164 D00165 D00166 D00241. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L32 Keep prompts concise through selective repetition

When: When long prompts become contradictory or exceed the limit.

Write stable facts once; repeat only the fragile fact at the shot where it can drift.

Example: Repeat doorway side at the crossing and bag state when visible, rather than copying the whole inventory into each shot.

Check: Did compression remove any causal action or necessary reference binding?

Scope: Apply within the current brief and approved scene context.

Evidence: D00095 D00296 D00297 D00298 D00361. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L33 Use clear light sources and separate exposure

When: When bright/cool, warm materials, or relighting requests are misunderstood.

Describe illumination direction and source separately from brightness, material color, and grade.

Example: Cold overcast light can leave faces well exposed; warm wood can stay warm as a material.

Check: Did relighting preserve the intended architecture, identity, and visible detail?

Scope: Do not infer current output resolution, frame rate, or physical lighting control from decorative prompt wording. Use the active model settings.

Evidence: D00184 D00185 D00186 D00187 D00188 A011. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L34 Remove actions that imply a removed condition

When: When editing weather, dirt, injuries, or other states.

Update dependent actions as well as exclusions.

Example: After removing indoor snow, replace wiping snow from hair with a caring hand smoothing dry hair.

Check: Does any remaining action still require the excluded condition?

Scope: Apply within the current brief and approved scene context.

Evidence: D00189 D00190 D00191 D00279 D00280 D00281 D00282. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L35 Separate identity, outfit, pose, and style

When: When making character canvases, costume edits, or variants.

Bind each dimension deliberately; preserve approved expression when requested, and keep adult anatomy in adult characters.

Example: An outfit reference contributes clothing without importing its fashion pose; a softer expression must not make an adult look like a child.

Check: Check face, age, body, expression, pose, clothing, and style individually.

Scope: Apply within the current brief and approved scene context.

Evidence: D00196 D00197 D00198 D00199 D00200 D00201 D00202 D00207 D00208 D00209. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L36 Split a difficult design into controllable parts

When: When identity, clothing, style, and accessory all keep drifting.

Resolve one design dimension at a time, then integrate it into the approved base.

Example: Design the mask as an asset, select its shape and material, then fit it on the intended anatomical side.

Check: Which dimension changed in this test, and what remains protected?

Scope: Apply within the current brief and approved scene context.

Evidence: D00093 D00094 D00210 D00275 D00276 D00277 D00278. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L37 Match a composite to its environment

When: When a person looks pasted into a location.

Match scale, perspective, light direction, softness, focus, grain, occlusion, and contact shadows.

Example: A receptionist needs to sit behind the desk with room-consistent lighting and focus.

Check: Do face preservation and photographic integration both hold?

Scope: Apply within the current brief and approved scene context.

Evidence: D00192 D00193 D00194. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.

## L38 Test crop safety through the action

When: When one master must serve multiple crops.

Keep essential faces, hands, contact, and props inside the actual shared safe area at the opening, action peak, and ending.

Example: A safe first frame can fail when a reaching arm crosses the crop edge.

Check: Inspect the real requested crop through motion; a prompt label is not proof.

Scope: Apply within the current brief and approved scene context.

Evidence: D00223 D00224 A001 A003 A009. Derived guidance from the supplied synthesis; archive examples are supporting prompt text, not independently reviewed renders.
