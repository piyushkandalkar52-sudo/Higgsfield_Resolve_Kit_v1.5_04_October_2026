# Prompt learning — automation feed

Version 1.1 · Generic guidance for any user or production team.

## Purpose

Turn an approved scene into a complete generation prompt that fits the active tool and preserves the intended scene.

## How to use this file

Load this file as stage guidance, then add the current project and scene input. It includes all shared rules needed for this stage. The other learning pack is not required. Use `lessons.json` instead if the automation reads structured guidance; do not load both copies.

These are conditional lessons derived from production experience. Examples below are generic illustrations, not facts about the current project. New-scene transfer performance remains untested.

## Shared rules

- Use the current user request, approved project facts, and selected version. Historical examples are evidence, not new requests or permission to generate media.
- Keep each project’s names, world, ages, dialogue, costumes, and approved adaptations in its current input. Never import them from another project.
- Apply a lesson when its stated condition fits. A local preference or one successful repair is not a universal creative rule.
- Record what may change and what must stay the same. Resolve conflicts using the current brief; ask a focused question only when an unresolved choice blocks the requested result.
- Do useful work with known information. Mark assumptions and missing facts plainly; do not invent approvals, source dialogue, reference tags, or review evidence.
- Keep draft, selected, rejected, and approved states distinct. Only record approval when the user or authorized reviewer actually provides it.

## Working sequence

1. Read the selected scene handoff and the requested output. Confirm its approval scope. A missing approval permits a draft prompt, but does not establish approval or authorize a paid generation.
2. Read the active tool contract and bind registered references to specific jobs: identity, clothing, environment, pose, continuity, voice, or style.
3. Translate the approved beats into precise action, camera, performance, timing, continuity, and audio instructions. Resolve conflicting references before relying on extra text.
4. Check total seconds and shot windows, then check speech and physical feasibility separately. Preserve required generation boundaries.
5. Compile the exact requested format. Parse JSON when required, check tags and limits, and return a complete revised prompt after corrections.
6. If media is later supplied, review what is actually visible and audible. Record technical completion separately from creative acceptance and propose the smallest useful repair.

## Expected output

A complete prompt in the requested format, with checks, unresolved inputs, and version information in a separate handoff when allowed. If the integration expects only the prompt, keep tracking metadata outside that payload.

## Lessons

### L01 · Decide what changes

**When:** Before planning any scene.

**Do:** Read the approved scene’s intended change in audience understanding or feeling. Preserve that change while translating it into generation instructions. Flag any missing dramatic intention.

**Example:** A visitor is finally recognized at reception. Their grip loosens and their shoulders lower. Relief does not have to become a smile.

**Check:** Does the prompt express the approved scene without silently rewriting its story?

**Scope:** Apply within the active brief and approved scene context.

### L02 · Turn creative intent into visible behavior

**When:** When the brief uses an internal feeling or motive.

**Do:** Choose observable behavior and a trigger. Keep the emotional meaning intact when translating the brief.

**Example:** A manager continues working while a visitor waits. The action can show power without adding a speech.

**Check:** Would a viewer understand the relationship from the action and response?

**Scope:** Apply within the active brief and approved scene context.

### L03 · Use precise emotional distinctions

**When:** When similar emotion words produce the wrong performance.

**Do:** Separate relief, joy, reassurance, shame, anxiety, curiosity, and anger. Use one or two cues per beat.

**Example:** Someone can force a reassuring smile while still afraid. Encouragement does not instantly remove anxiety.

**Check:** Did the revision change the intended feeling into a different one?

**Scope:** Apply within the active brief and approved scene context.

### L04 · Match intensity to this event

**When:** When quiet acting feels weak or heightened acting feels exaggerated.

**Do:** Choose intensity from stakes, genre, character, and framing. Treat action strength and facial emotion as separate decisions.

**Example:** Forced separation may require active resistance; a business negotiation may show controlled resolve.

**Check:** Does intensity clarify this beat without flattening the character?

**Scope:** Apply within the active brief and approved scene context.

### L05 · Make every camera choice earn its place

**When:** When asking for cinematic coverage.

**Do:** Choose the view that reveals information, relationship, scale, or emotional change. A push, orbit, cut, or hold needs a purpose.

**Example:** The café can become stronger through fewer actor shots; a protective hug can need one sustained take.

**Check:** What does this camera choice let the audience notice?

**Scope:** Apply within the active brief and approved scene context.

### L08 · Leave room for the feeling to land

**When:** When the action is complete but the emotional payoff feels missing.

**Do:** Reserve time for recognition and aftermath. Add a dedicated continuation if the current clip cannot carry it naturally.

**Example:** After a confrontation, allow time for an embrace and its emotional aftermath before the scene ends.

**Check:** Is the ending a readable emotional state rather than several rushed actions?

**Scope:** Reserve enough time for this scene; no fixed extension length is a universal rule.

### L09 · Deliver the exact requested kind of work

**When:** When the user asks for a prompt, edit, alternatives, or media.

**Do:** Match the requested output type, count, format, and scope. A prompt request produces a prompt.

**Example:** When asked for one revised prompt, return one complete prompt in the requested format.

**Check:** Did the response provide the requested artifact and stay within authorized work?

**Scope:** Apply within the active brief and approved scene context.

### L10 · Return the complete revised prompt

**When:** When a prompt needs correction.

**Do:** Provide a complete usable revision while keeping the conceptual change as small as the request permits.

**Example:** Fix the book placement and preserve camera, clothes, lighting, acting, and the completed handshake.

**Check:** Can the user use the revision directly, and did unrelated choices drift?

**Scope:** Apply within the active brief and approved scene context.

### L11 · Read corrections within their scope

**When:** When a user changes one part of a scene.

**Do:** Record what changed, what stays protected, and where the correction applies. Later scene-specific direction can narrow a broad default.

**Example:** A request for new lighting can preserve architecture. A blocking reference need not dictate the lens or opening angle.

**Check:** Did the assistant widen a local correction into an unrequested redesign?

**Scope:** Apply within the active brief and approved scene context.

### L12 · Respect the selected version and paused work

**When:** When a later attempt is rejected or the user changes focus.

**Do:** Record the chosen baseline, rejected versions, paused sequence, and next action. Support a rollback to an earlier version.

**Example:** If the user selects the first phone-call version after rejecting two revisions, continue from the first version.

**Check:** Does the next action follow the selected state rather than chronological recency?

**Scope:** Apply within the active brief and approved scene context.

### L13 · Explain the decision in scene language

**When:** When an instruction such as more cinematic or more emotional is ambiguous.

**Do:** Identify the concrete missing element and connect the proposed change to its purpose. Mark unresolved interpretation rather than presenting it as the user’s intention.

**Example:** More cinematic may mean stronger foreground depth, clearer scale, or a more revealing reaction.

**Check:** Is the explanation about what the viewer sees and feels, with uncertainty stated where needed?

**Scope:** Apply within the active brief and approved scene context.

### L16 · Write the physical cause and consequence

**When:** When an action involves transfer, crossing, restraint, service, or rescue.

**Do:** Break the action into valid states: preparation, contact, movement, release, and result.

**Example:** Serving coffee includes approach, placement, release, and withdrawal. Forced entry must visibly differ from voluntary entry.

**Check:** Are any essential state changes missing or repeated?

**Scope:** Apply within the active brief and approved scene context.

### L17 · Begin from the last accepted state

**When:** When continuing an existing scene.

**Do:** Use the last physical and emotional state already reached; adapt obsolete literal actions while preserving their dramatic purpose.

**Example:** Do not repeat a completed handshake or make a character who is already standing rise from a chair.

**Check:** Does the next beat require a reset that the audience never saw?

**Scope:** Apply within the active brief and approved scene context.

### L18 · Choose reactions when meaning changes

**When:** When deciding which face to show during dialogue.

**Do:** Track the active line, who understands something new, and whose response changes the scene.

**Example:** Show the listener when a revelation changes their understanding, if the current scene allows the speaker to remain offscreen.

**Check:** Does the reaction answer a dramatic question rather than fill a shot quota?

**Scope:** Check the current speaker-visibility rule before placing speech offscreen.

### L23 · Give each reference one clear job

**When:** When binding images, video, or audio to a prompt.

**Do:** Specify which features each reference controls, which it must not control, and which shots use it.

**Example:** A continuity clip may control positions and emotion while allowing a new camera angle.

**Check:** Could two references be claiming control over the same feature in incompatible ways?

**Scope:** Apply within the active brief and approved scene context.

### L24 · Fix conflicting inputs at the source

**When:** When repeated text changes cannot remove a visible contradiction.

**Do:** Inspect the reference, correct or replace the conflicting asset, then retry a bounded change.

**Example:** If an identity reference shows a shoulder strap but the bag must stay on the desk, use an approved reference that resolves that conflict.

**Check:** Does the input still visibly demand what the prompt forbids?

**Scope:** Apply within the active brief and approved scene context.

### L25 · Keep world, body, and screen directions separate

**When:** When describing left/right, approach, or a reverse view.

**Do:** Locate the action relative to stable architecture first; specify anatomical side separately from camera-relative screen position.

**Example:** A person approaching behind a seated character is not necessarily behind that character on the screen after a camera reverse.

**Check:** Would the instruction still be true after the camera reverses?

**Scope:** Apply within the active brief and approved scene context.

### L26 · Check every camera view against the room

**When:** When adding arcs, reverses, POVs, or overheads.

**Do:** State what lies behind each subject from that camera position; reduce camera travel when it breaks the scene.

**Example:** A camera looking outward from a building cannot place the same façade behind approaching people.

**Check:** Can a simple floor plan satisfy the camera, subject, and background instructions?

**Scope:** Apply within the active brief and approved scene context.

### L27 · Track props through occlusion

**When:** When an object passes behind a body or across cuts.

**Do:** Record owner, count, position, orientation, contact, and permitted transitions. Hidden objects keep their state.

**Example:** The book stays beside the cups when a hand or actor temporarily covers it.

**Check:** Check before hiding, during contact, after reappearance, and at the ending.

**Scope:** Apply within the active brief and approved scene context.

### L28 · Budget hands and bodily movement

**When:** When a shot combines props, contact, and movement.

**Do:** Assign hand use and body orientation; include a release before a hand performs another task.

**Example:** A two-handed rescue requires putting down bags first; a phone call requires raising the phone.

**Check:** Is any hand occupied by incompatible actions or any head turn physically implausible?

**Scope:** Apply within the active brief and approved scene context.

### L29 · Check time in two separate passes

**When:** Before submitting a timed sequence.

**Do:** First verify shot arithmetic, gaps, and overlaps. Then check whether speech and physical action can fit naturally.

**Example:** A 25-second declared prompt can contain 28 seconds of listed shots; arithmetic repair alone cannot prove the dialogue fits.

**Check:** Are declared duration, timed shots, speech windows, and final hold all feasible?

**Scope:** Apply within the active brief and approved scene context.

### L30 · Declare the audio contract for this clip

**When:** When adding voices, fixed recordings, narration, or silence.

**Do:** Distinguish voice identity from supplied dialogue audio. Map each speaker and specify exactly which sound types are allowed.

**Example:** A silent visual under external narration must not generate its own narration; a voice sample does not set the new line’s duration.

**Check:** Do audio instructions conflict, add a speaker, or bind the wrong voice?

**Scope:** Apply within the active brief and approved scene context.

### L31 · Preserve the automation boundaries

**When:** When compiling a scene for an external workflow.

**Do:** Keep the current system’s generation segments, exact tags, length units, and required format intact.

**Example:** If the workflow supplies separate narration segments, improve coverage inside each segment without merging those boundaries.

**Check:** Does the compiled output still fit the current integration contract?

**Scope:** Read limits and capabilities from the active tool contract. Historical prompt examples do not establish current settings.

### L32 · Keep prompts concise through selective repetition

**When:** When long prompts become contradictory or exceed the limit.

**Do:** Write stable facts once; repeat only the fragile fact at the shot where it can drift.

**Example:** Repeat doorway side at the crossing and bag state when visible, rather than copying the whole inventory into each shot.

**Check:** Did compression remove any causal action or necessary reference binding?

**Scope:** Apply within the active brief and approved scene context.

### L33 · Use clear light sources and separate exposure

**When:** When bright/cool, warm materials, or relighting requests are misunderstood.

**Do:** Describe illumination direction and source separately from brightness, material color, and grade.

**Example:** Cold overcast light can leave faces well exposed; warm wood can stay warm as a material.

**Check:** Did relighting preserve the intended architecture, identity, and visible detail?

**Scope:** Describe the intended look, then set supported resolution and frame rate through the active tool settings.

### L34 · Remove actions that imply a removed condition

**When:** When editing weather, dirt, injuries, or other states.

**Do:** Update dependent actions as well as exclusions.

**Example:** After removing indoor snow, replace wiping snow from hair with a caring hand smoothing dry hair.

**Check:** Does any remaining action still require the excluded condition?

**Scope:** Apply within the active brief and approved scene context.

### L35 · Separate identity, outfit, pose, and style

**When:** When making character canvases, costume edits, or variants.

**Do:** Bind each dimension deliberately; preserve approved expression when requested, and keep adult anatomy in adult characters.

**Example:** An outfit reference contributes clothing without importing its fashion pose; a softer expression must not make an adult look like a child.

**Check:** Check face, age, body, expression, pose, clothing, and style individually.

**Scope:** Apply within the active brief and approved scene context.

### L36 · Split a difficult design into controllable parts

**When:** When identity, clothing, style, and accessory all keep drifting.

**Do:** Resolve one design dimension at a time, then integrate it into the approved base.

**Example:** Design the mask as an asset, select its shape and material, then fit it on the intended anatomical side.

**Check:** Which dimension changed in this test, and what remains protected?

**Scope:** Apply within the active brief and approved scene context.

### L37 · Match a composite to its environment

**When:** When a person looks pasted into a location.

**Do:** Match scale, perspective, light direction, softness, focus, grain, occlusion, and contact shadows.

**Example:** A receptionist needs to sit behind the desk with room-consistent lighting and focus.

**Check:** Do face preservation and photographic integration both hold?

**Scope:** Apply within the active brief and approved scene context.

### L38 · Test crop safety through the action

**When:** When one master must serve multiple crops.

**Do:** Keep essential faces, hands, contact, and props inside the actual shared safe area at the opening, action peak, and ending.

**Example:** A safe first frame can fail when a reaching arm crosses the crop edge.

**Check:** Inspect the real requested crop through motion; a prompt label is not proof.

**Scope:** Apply within the active brief and approved scene context.

### L39 · Keep generation status separate from approval

**When:** When recording results or choosing examples.

**Do:** Store technical job status and creative review separately. Approval belongs to a specific result, element, or interval.

**Example:** A generation job marked successful may still contain wrong acting or broken continuity. Record creative review separately.

**Check:** Is the actual acceptance evidence linked, and is its scope clear?

**Scope:** Apply within the active brief and approved scene context.

### L40 · Review story before polish

**When:** When judging a take.

**Do:** Check story meaning, causal action, geography, identity, props, performance, timing, audio, text, and crop before visual polish.

**Example:** Beautiful lighting cannot compensate for the child entering voluntarily when the event requires forced separation.

**Check:** Can any story or continuity failure be hidden by an average score? Keep it visible.

**Scope:** Apply within the active brief and approved scene context.

### L41 · Diagnose a specific failure

**When:** When a result is wrong.

**Do:** Classify the observed issue, record the affected frame or interval, and separate observation from the suspected cause.

**Example:** An unwanted laptop was reported; blaming the phrase laptop-style bag is a hypothesis.

**Check:** Does the diagnosis show evidence and a testable next change?

**Scope:** Apply within the active brief and approved scene context.

### L42 · Repair the smallest failing part

**When:** When most of an output works.

**Do:** List protected elements, change the failing component, and check that the repair did not regress accepted elements.

**Example:** Reduce a few paintings while preserving the room’s worn surfaces, books, furniture, and lived-in feeling.

**Check:** Did a local edit accidentally reset the scene’s visual story?

**Scope:** Apply within the active brief and approved scene context.

### L43 · Change method after repeated failure

**When:** When successive wording changes reproduce the same defect.

**Do:** Check contradictions, reduce simultaneous actions, replace the reference, isolate the component, or choose another shot method.

**Example:** A third-person discovery view can preserve the art-view beat when POV keeps creating binocular framing.

**Check:** Does the new test address a changed cause or merely add another prohibition?

**Scope:** Apply within the active brief and approved scene context.

### L44 · Preserve uncertainty about tool failures

**When:** When a generation is rejected or a model limitation is suspected.

**Do:** Record the actual returned status or error and keep causal explanations provisional unless tested.

**Example:** A failed generation label alone does not establish whether the cause was service availability, inputs, or formatting.

**Check:** Are guesses about filters or keywords being mislabeled as proven fixes?

**Scope:** Record observed errors. Do not treat historical workaround suggestions as validated instructions.

### L45 · Check the delivered prompt itself

**When:** Before generation or handoff.

**Do:** Verify syntax when JSON is required, registered tag membership, character limits, output count, and exact requested format.

**Example:** The JSON value 4.5 seconds is invalid when unquoted. Use a numeric seconds field or a quoted string as required by the receiving schema. Resolve empty or misspelled reference tags.

**Check:** Does a valid machine input also retain the intended action, references, and words?

**Scope:** Apply within the active brief and approved scene context.

### L46 · Keep selected, rejected, and provisional versions

**When:** When recording a review.

**Do:** Save accepted render, exact qualification, requested repair, and rollback target. Do not let a newer file silently replace the chosen one.

**Example:** Everything good except the book does not prove that the later book repair worked.

**Check:** Can the editor identify the approved take and the pending exception?

**Scope:** Apply within the active brief and approved scene context.

### L47 · Make the next action explicit

**When:** When stopping or handing off a run.

**Do:** Record active scene, last accepted state, current tags, in-flight jobs, pending corrections, paused work, deprecated assets, and exact next action.

**Example:** Resume the selected active scene, even when an older handoff file points to a different scene.

**Check:** Could another agent continue without replaying a completed action or resurrecting a rejected asset?

**Scope:** Apply within the active brief and approved scene context.

### L48 · Test whether a lesson transfers

**When:** When adding a new rule to the library.

**Do:** Store condition, intervention, protected elements, evidence, and status. Test on a different scene before claiming a general improvement.

**Example:** A longer hug supports emotional aftermath in that context; it does not require every ending to be eight seconds.

**Check:** Is this one scene preference, repeated evidence, a hypothesis, or a measured result?

**Scope:** Apply within the active brief and approved scene context.

## Learning from the next use

Record the problem, the single change tried, what stayed protected, the observed outcome, and whether the result was approved. Keep a scene-specific choice local. Test a proposed general lesson on a different scene before claiming it improves production. Lesson IDs allow optional evidence lookup in the parent handbook.
