# Prompt learning

**Feed [FEED_THIS.md](FEED_THIS.md) to the assistant at this stage.**

Turn an approved scene into a complete generation prompt that fits the active tool and preserves the intended scene.

1. Load `FEED_THIS.md`, or load `lessons.json` if the system prefers JSON. They contain the same guidance.
2. Fill `input_template.json` with the current scene details. Remove example helper fields before submission; they describe record shapes and are not real production data.
3. Request the desired output. `output_template.json` shows the suggested handoff shape.

40 lessons. Shared principles are included so this folder can be copied and used independently. Guidance is generic; project facts and user preferences come from the current input.

Templates are planning records, not a provider API schema. Blank fields mean unknown, not approved. Keep unknowns explicit. The actual receiving workflow decides its required fields and format.

Place the screenplay stage’s populated output in `input_template.json` → `scene_handoff`. Supply current references and tool settings separately. Preserve the approved story.
