# Screenplay learning — automation feed

Version 1.1 · Generic guidance for any user or production team.

## Purpose

Turn a brief or source excerpt into a clear, playable scene with a useful handoff.

## How to use this file

Load this file as stage guidance, then add the current project and scene input. It includes all shared rules needed for this stage. The other learning pack is not required. Use `lessons.json` instead if the automation reads structured guidance; do not load both copies.

These are conditional lessons derived from production experience. Examples below are generic illustrations, not facts about the current project. New-scene transfer performance remains untested.

## Shared rules

- Use the current user request, approved project facts, and selected version. Historical examples are evidence, not new requests or permission to generate media.
- Keep each project’s names, world, ages, dialogue, costumes, and approved adaptations in its current input. Never import them from another project.
- Apply a lesson when its stated condition fits. A local preference or one successful repair is not a universal creative rule.
- Record what may change and what must stay the same. Resolve conflicts using the current brief; ask a focused question only when an unresolved choice blocks the requested result.
- Do useful work with known information. Mark assumptions and missing facts plainly; do not invent approvals, source dialogue, reference tags, or review evidence.
- Keep draft, selected, rejected, and approved states distinct. Only record approval when the user or authorized reviewer actually provides it.

## Working sequence

1. Read the request, source excerpt, relevant project facts, and last accepted scene state. Ask for adjacent beats only when continuity or reveal timing needs them.
2. State what changes for the audience. Separate source facts, approved adaptations, and proposed choices.
3. Write cause → visible action → reaction → result. Track character knowledge, physical positions, props, and emotional changes.
4. Choose coverage for meaning. Check dialogue, estimated runtime, scene geography, and the intended crops.
5. Review the scene using the checks below. Return the requested screenplay plus a structured scene handoff when the workflow requests one.
6. Record the selected version and unresolved questions. Keep approval as draft or pending until it is actually given.

## Expected output

The requested screenplay and a scene handoff containing facts, intent, causal beats, dialogue, start/end states, continuity, estimated timing, approval state, and open questions.

## Lessons

### L01 · Decide what changes

**When:** Before planning any scene.

**Do:** State what the audience understands or feels before the scene, what causes a change, and what they understand afterward.

**Example:** A visitor is finally recognized at reception. Their grip loosens and their shoulders lower. Relief does not have to become a smile.

**Check:** Can every important shot be connected to that change?

**Scope:** Apply within the active brief and approved scene context.

### L02 · Turn creative intent into visible behavior

**When:** When the brief uses an internal feeling or motive.

**Do:** Choose observable behavior and a trigger. Keep the emotional meaning intact when translating the brief.

**Example:** A manager continues working while a visitor waits. The action can show power without adding a speech.

**Check:** Would a viewer understand the relationship from the action and response?

**Scope:** Apply within the active brief and approved scene context.

### L03 · Use precise emotional distinctions

**When:** When similar emotion words produce the wrong performance.

**Do:** Separate relief, joy, reassurance, shame, anxiety, curiosity, and anger. Use one or two cues per beat.

**Example:** Someone can force a reassuring smile while still afraid. Encouragement does not instantly remove anxiety.

**Check:** Did the revision change the intended feeling into a different one?

**Scope:** Apply within the active brief and approved scene context.

### L04 · Match intensity to this event

**When:** When quiet acting feels weak or heightened acting feels exaggerated.

**Do:** Choose intensity from stakes, genre, character, and framing. Treat action strength and facial emotion as separate decisions.

**Example:** Forced separation may require active resistance; a business negotiation may show controlled resolve.

**Check:** Does intensity clarify this beat without flattening the character?

**Scope:** Apply within the active brief and approved scene context.

### L05 · Make every camera choice earn its place

**When:** When asking for cinematic coverage.

**Do:** Choose the view that reveals information, relationship, scale, or emotional change. A push, orbit, cut, or hold needs a purpose.

**Example:** The café can become stronger through fewer actor shots; a protective hug can need one sustained take.

**Check:** What does this camera choice let the audience notice?

**Scope:** Apply within the active brief and approved scene context.

### L06 · Make worlds believable through use

**When:** When designing poverty, wealth, school, hospital, or workplace.

**Do:** Build the social meaning through function, maintenance, scale, privacy, and behavior.

**Example:** An older modest home can be clean. A primary classroom needs child-sized furniture and learning materials.

**Check:** Does the place support the story and age group rather than only a surface style?

**Scope:** Apply within the active brief and approved scene context.

### L07 · Offer genuinely different choices

**When:** When presenting design alternatives.

**Do:** Vary meaningful structure: layout, silhouette, construction, circulation, materials, or dramatic function. Explain the difference plainly.

**Example:** Two costumes should differ in construction and role, not only color.

**Check:** Would choosing between these options change a meaningful creative decision?

**Scope:** Apply within the active brief and approved scene context.

### L08 · Leave room for the feeling to land

**When:** When the action is complete but the emotional payoff feels missing.

**Do:** Reserve time for recognition and aftermath. Add a dedicated continuation if the current clip cannot carry it naturally.

**Example:** After a confrontation, allow time for an embrace and its emotional aftermath before the scene ends.

**Check:** Is the ending a readable emotional state rather than several rushed actions?

**Scope:** Reserve enough time for this scene; no fixed extension length is a universal rule.

### L09 · Deliver the exact requested kind of work

**When:** When the user asks for a prompt, edit, alternatives, or media.

**Do:** Match the requested output type, count, format, and scope. A prompt request produces a prompt.

**Example:** When asked for one revised prompt, return one complete prompt in the requested format.

**Check:** Did the response provide the requested artifact and stay within authorized work?

**Scope:** Apply within the active brief and approved scene context.

### L11 · Read corrections within their scope

**When:** When a user changes one part of a scene.

**Do:** Record what changed, what stays protected, and where the correction applies. Later scene-specific direction can narrow a broad default.

**Example:** A request for new lighting can preserve architecture. A blocking reference need not dictate the lens or opening angle.

**Check:** Did the assistant widen a local correction into an unrequested redesign?

**Scope:** Apply within the active brief and approved scene context.

### L12 · Respect the selected version and paused work

**When:** When a later attempt is rejected or the user changes focus.

**Do:** Record the chosen baseline, rejected versions, paused sequence, and next action. Support a rollback to an earlier version.

**Example:** If the user selects the first phone-call version after rejecting two revisions, continue from the first version.

**Check:** Does the next action follow the selected state rather than chronological recency?

**Scope:** Apply within the active brief and approved scene context.

### L13 · Explain the decision in scene language

**When:** When an instruction such as more cinematic or more emotional is ambiguous.

**Do:** Identify the concrete missing element and connect the proposed change to its purpose. Mark unresolved interpretation rather than presenting it as the user’s intention.

**Example:** More cinematic may mean stronger foreground depth, clearer scale, or a more revealing reaction.

**Check:** Is the explanation about what the viewer sees and feels, with uncertainty stated where needed?

**Scope:** Apply within the active brief and approved scene context.

### L14 · Keep facts and adaptation separate

**When:** When interpreting or relocating a story.

**Do:** Track source facts, authorized adaptation, assistant interpretation, and approved production assets separately.

**Example:** Moving a story to a different city is an adaptation. Record its approval separately from the original setting.

**Check:** Can each changed story fact be traced to its source or approved adaptation?

**Scope:** Apply within the active brief and approved scene context.

### L15 · Protect who knows what

**When:** When a mystery, concealed identity, or delayed reveal matters.

**Do:** Record character knowledge, audience knowledge, and the permitted reveal point. Clarify the event while preserving the intentional secret.

**Example:** An acquisition can be legible while the new chairman remains unseen.

**Check:** Does a shot, line, face, or symbol reveal information too early?

**Scope:** Apply within the active brief and approved scene context.

### L16 · Write the physical cause and consequence

**When:** When an action involves transfer, crossing, restraint, service, or rescue.

**Do:** Break the action into valid states: preparation, contact, movement, release, and result.

**Example:** Serving coffee includes approach, placement, release, and withdrawal. Forced entry must visibly differ from voluntary entry.

**Check:** Are any essential state changes missing or repeated?

**Scope:** Apply within the active brief and approved scene context.

### L17 · Begin from the last accepted state

**When:** When continuing an existing scene.

**Do:** Use the last physical and emotional state already reached; adapt obsolete literal actions while preserving their dramatic purpose.

**Example:** Do not repeat a completed handshake or make a character who is already standing rise from a chair.

**Check:** Does the next beat require a reset that the audience never saw?

**Scope:** Apply within the active brief and approved scene context.

### L18 · Choose reactions when meaning changes

**When:** When deciding which face to show during dialogue.

**Do:** Track the active line, who understands something new, and whose response changes the scene.

**Example:** Show the listener when a revelation changes their understanding, if the current scene allows the speaker to remain offscreen.

**Check:** Does the reaction answer a dramatic question rather than fill a shot quota?

**Scope:** Check the current speaker-visibility rule before placing speech offscreen.

### L19 · Choose the grammar of time

**When:** When writing a montage, memory, or age progression.

**Do:** Declare whether this is one continuous event, separate moments, compressed years, or a continuous transformation. Vary activities and feelings appropriately.

**Example:** Four years of romance should include routine care, shared study, teasing, and quieter moments rather than constant laughter.

**Check:** Are costume, age, prop, and location changes consistent with the chosen passage of time?

**Scope:** Apply within the active brief and approved scene context.

### L20 · Design the set around required action

**When:** When a scene depends on entrances, escape, or movement.

**Do:** Establish routes, usable thresholds, scale, and camera access before decorating.

**Example:** A room used for an escape needs a usable door or window, a clear route, and enough space for the action.

**Check:** Can the scene actually be staged in the proposed set?

**Scope:** Apply within the active brief and approved scene context.

### L21 · Build an opening around a dramatic question

**When:** When designing a promo opening.

**Do:** Make the consequential event understandable quickly; carry a question through the next beats and let the response matter.

**Example:** An opening can establish one clear question: will the visitor be allowed inside?

**Check:** Do the opening image, action, and words support the same question?

**Scope:** This is a writing principle, not a measured promise of audience retention.

### L22 · Let motifs develop meaning

**When:** When repeating a prop, threshold, or visual symbol.

**Do:** Track its first meaning, later changes, physical state, and reveal limits.

**Example:** A window can first mean confinement and later become an escape route. Preserve its location and physical state.

**Check:** Does the repetition develop the story, and is the symbol established or authorized?

**Scope:** Apply within the active brief and approved scene context.

### L29 · Check the planned runtime

**When:** When the scene has a target duration.

**Do:** Add the planned beat durations, then allow enough time for dialogue, physical action, reactions, and the ending. Mark unmeasured timing as an estimate.

**Example:** A short scene needs time for a person to approach, put down a cup, release it, and receive a response.

**Check:** Does the scene fit naturally without skipping causes or rushing the emotional change?

**Scope:** Apply within the active brief and approved scene context.

### L30 · Separate dialogue, narration, thought, and silence

**When:** When writing the sound plan.

**Do:** Label who speaks, which words are spoken, which words are narration or internal thought, and where silence matters. Preserve supplied dialogue when required.

**Example:** A scene played under external narration can specify silent actors without adding new spoken lines.

**Check:** Can the next stage distinguish spoken words from action descriptions and production notes?

**Scope:** Apply within the active brief and approved scene context.

### L38 · Plan for the required frame

**When:** When one master must serve multiple crops.

**Do:** Plan essential faces, hands, contact, and props so the intended action can remain readable in the requested crops. Mark final motion and crop checks for the rendered review.

**Example:** A safe first frame can fail when a reaching arm crosses the crop edge.

**Check:** Can the planned staging support the requested frame, and is final crop review still recorded as pending?

**Scope:** Apply within the active brief and approved scene context.

### L40 · Review the scene before polishing the wording

**When:** Before handing off a screenplay.

**Do:** Check story meaning, source facts, reveal limits, cause and consequence, geography, character intent, props, performance, and estimated timing. Keep unresolved problems visible.

**Example:** Beautiful lighting cannot compensate for the child entering voluntarily when the event requires forced separation.

**Check:** Does the written scene make sense and preserve the intended emotional change?

**Scope:** Apply within the active brief and approved scene context.

### L42 · Repair the smallest failing part

**When:** When most of an output works.

**Do:** List protected elements, change the failing component, and check that the repair did not regress accepted elements.

**Example:** Reduce a few paintings while preserving the room’s worn surfaces, books, furniture, and lived-in feeling.

**Check:** Did a local edit accidentally reset the scene’s visual story?

**Scope:** Apply within the active brief and approved scene context.

### L46 · Keep selected, rejected, and provisional versions

**When:** When recording a review.

**Do:** Save the selected screenplay version, accepted elements, pending changes, and rollback target. A newer draft does not automatically replace the chosen one.

**Example:** The user accepts the dialogue but requests a new entrance. Dialogue remains protected while blocking is revised.

**Check:** Can the next stage identify the selected scene version and its unresolved changes?

**Scope:** Apply within the active brief and approved scene context.

### L47 · Make the next action explicit

**When:** When stopping or handing off a run.

**Do:** Record the project, active scene, selected screenplay version, physical and emotional end state, unresolved facts, pending changes, paused work, and next action.

**Example:** Resume the selected active scene, even when an older handoff file points to a different scene.

**Check:** Can another person continue the scene without repeating completed action or using a rejected draft?

**Scope:** Apply within the active brief and approved scene context.

### L48 · Test whether a lesson transfers

**When:** When adding a new rule to the library.

**Do:** Store condition, intervention, protected elements, evidence, and status. Test on a different scene before claiming a general improvement.

**Example:** A longer hug supports emotional aftermath in that context; it does not require every ending to be eight seconds.

**Check:** Is this one scene preference, repeated evidence, a hypothesis, or a measured result?

**Scope:** Apply within the active brief and approved scene context.

## Learning from the next use

Record the problem, the single change tried, what stayed protected, the observed outcome, and whether the result was approved. Keep a scene-specific choice local. Test a proposed general lesson on a different scene before claiming it improves production. Lesson IDs allow optional evidence lookup in the parent handbook.
