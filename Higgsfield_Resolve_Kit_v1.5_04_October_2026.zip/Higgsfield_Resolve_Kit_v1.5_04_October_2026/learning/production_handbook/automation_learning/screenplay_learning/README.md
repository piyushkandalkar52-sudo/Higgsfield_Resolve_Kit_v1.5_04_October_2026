# Screenplay learning

**Feed [FEED_THIS.md](FEED_THIS.md) to the assistant at this stage.**

Turn a brief or source excerpt into a clear, playable scene with a useful handoff.

1. Load `FEED_THIS.md`, or load `lessons.json` if the system prefers JSON. They contain the same guidance.
2. Fill `input_template.json` with the current scene details. Remove example helper fields before submission; they describe record shapes and are not real production data.
3. Request the desired output. `output_template.json` shows the suggested handoff shape.

29 lessons. Shared principles are included so this folder can be copied and used independently. Guidance is generic; project facts and user preferences come from the current input.

Templates are planning records, not a provider API schema. Blank fields mean unknown, not approved. Keep unknowns explicit. The actual receiving workflow decides its required fields and format.

After the scene is selected and approved, pass the populated output to the prompt stage as `scene_handoff`.
