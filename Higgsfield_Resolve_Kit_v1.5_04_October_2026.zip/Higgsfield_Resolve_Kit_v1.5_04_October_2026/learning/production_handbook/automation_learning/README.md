# Two separate automation learning packs

These folders are for every user. All examples inside them use generic roles. Project names, characters, personal preferences, and model settings are supplied with each task.

```text
automation_learning/
├── screenplay_learning/  → Write what happens and why
│   └── FEED_THIS.md
└── prompt_learning/      → Tell the generator how to show it
    └── FEED_THIS.md

Scene input + screenplay learning
                ↓
        Screenplay + scene handoff
                ↓
          Scene approval
                ↓
Approved handoff + references + tool settings + prompt learning
                ↓
       Prompt → checks → generation when authorized → review
```

## Which file should I feed?

| Stage | Feed this | Add current task information |
|---|---|---|
| Screenplay | [screenplay_learning/FEED_THIS.md](screenplay_learning/FEED_THIS.md) | Brief, relevant script excerpt, approved facts, last state, requested change |
| Prompt writing | [prompt_learning/FEED_THIS.md](prompt_learning/FEED_THIS.md) | Approved scene handoff, references, current tool settings, audio requirements |

Every folder has five files: `README.md` explains use; `FEED_THIS.md` is the complete stage guide; `lessons.json` is the equivalent structured guide; `input_template.json` and `output_template.json` define suggested task records. Feed either Markdown or JSON guidance, not both.

Each pack includes relevant shared principles. This intentional overlap lets either folder work alone. All 48 parent-handbook lessons are represented across the two packs. The screenplay output fits the prompt input’s `scene_handoff` field.

No full script collection is needed to load these lessons. Supply a specific scene and adjacent beats when the current task needs source facts or continuity checks. The parent handbook preserves historical evidence; it is optional for these feeds. Source-specific names and reference tags are not defaults for a new production.

These packs are ready to load manually or connect to an automation. Creating these folders does not itself connect a running workflow or prove improved creative results.
