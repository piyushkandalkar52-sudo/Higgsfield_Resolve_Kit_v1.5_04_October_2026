# Production learning library

Open [the visual handbook](index.html). For machine use, begin with [the loading guide](guides/00_START_HERE.md). Original files are preserved under `sources/`; evidence can be explored in [the source browser](sources.html).

Prepared 4 October 2026. General guides are usable now; selected scene facts and media outcomes still need the specific source excerpt or render when a production task requires them.

## Separate stage feeds

Use [screenplay learning](automation_learning/screenplay_learning/FEED_THIS.md) for scene writing and [prompt learning](automation_learning/prompt_learning/FEED_THIS.md) for generation prompts. Both are generic, independent packs with JSON alternatives and task templates. [Folder guide](automation_learning/README.md).
