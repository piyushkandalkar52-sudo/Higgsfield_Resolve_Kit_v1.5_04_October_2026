# RULES — every production rule, numbered

These rules come from real failures on *The Duke's Masked Bride* (TDMB), *The Royal Accident*
(TRA) and *His Secret Fortune* (HSF). `WORKFLOW.md` cites them as **[R-xx]**.

- **Precedence:** a rule marked **BINDING** can't be waived. The others give way only to the
  person's explicit direction for a specific beat. Log every such override in the project's
  `HANDOFF.md`.
- **Conflicts:** if two rules conflict, stop and ask. Explicit mode-specific exceptions are not
  conflicts: extension mode omits audio references under I4, even where generic prompt guidance
  says to attach every speaker voice; E14 already limits those references to keyframe mode.

---

## A. Session conduct
- **A1 · Plan first (BINDING).** Read, plan, and ask the person's decisions; generate nothing
  before the plan is approved.
- **A2 · Ask, don't guess.** Ask only decisions that belong to the person (`AskUserQuestion`, up to
  4 at a time, recommendation first). Look up everything else.
- **A3 · No hallucination.** Never claim a check you didn't run. Say what you couldn't verify.
- **A4 · Keep the person posted.** Post a one-line status during long waits, and report spend
  after every scene.
- **A5 · The handoff is live.** Update `HANDOFF.md` after every decision, batch, QA pass and build.
  Never delete failed attempts or log rows.
- **A6 · Persistent preferences.** When the person states a lasting preference ("always…",
  "from now on…"), add it to the project's `HANDOFF.md` rules and confirm it in one line.
- **A7 · CURRENT RUN box first.** The top of every `HANDOFF.md` is a five-line box: current scene /
  part, latest approved clip, jobs still running (job ids), next action, blocker. Update it after
  every submit, every take review and every build, so it is true whenever a session stops. Read it
  first on every resume.
- **A8 · The handoff holds current state only.** When a run or part is finished, move its report
  (deliverables, known issues, media ids, QA notes) to `logs/handoff_history.md` under a dated
  heading, newest first, and leave a one-line pointer. Reports must not pile up in the handoff.

## B. Spend
- **B1 · Confirm new runs; version decisions (BINDING).** Confirm output spec, budget cap and
  continuity method in Step 3 for each new run or materially changed scope. A resume of the same
  approved run reuses its recorded decision version; display that version and ask only for missing
  or changed decisions. Never silently inherit these choices into a new run. Changes affecting
  approved work require an impact review and the relevant approval before new spending.

- **B2 · Stop at limits (BINDING).** On a `429` / daily workspace credit limit, or when the cap is
  reached: stop, report, and list the jobs not done. Never retry around it.
- **B3 · Test before batching.** Preflight new recipes with `get_cost: true`. The approved plan
  names tests and maps them to production risks: new looks/locations, identity, dialogue/voice,
  movement/contact, signature details and continuity joins. Cover every relevant risk before
  dependent production. A representative test may cover several scenes only when the plan records
  why their conditions match; different risks in one scene may require multiple tests. Changing
  or reducing test coverage requires plan approval. QA is local only, never paid video analysis.

- **B4 · Regenerate only the failing part.** A clip with one bad shot gets a short fix-up clip, or
  is fixed in the edit [J5]. The whole clip isn't redone.
- **B5 · Never double-submit.** Poll pending jobs with `jobs_wait`; never resubmit a job that is
  still pending.

## C. Output defaults (confirm them in Step 3)
- **C1.** Seedance 2.5, `480p`, `4:3`, `generate_audio: true` for dialogue clips and `false` for
  silent clips. Resolve timeline: custom 1440×1080, 24 fps.
- **C2.** Each clip is at most 10 s for keyframe clips. Extensions can be 4–30 s, but keep them at
  14 s or less for control.

## D. Script and dialogue
- **D1 · Read the whole script first (BINDING).** Before planning any part, read the whole
  script. Pay special attention to the sequence before this one and to the ending, and write the
  story position in three lines: the previous sequence's end state, this sequence's start state,
  and how the story ends.
- **D2 · Dialogue is verbatim.** Use the exact words, in order, with no ad-libs, lip-synced on
  camera unless the script puts the line off-screen. Narration stays narration, with no lip movement.
- **D3 · Wording changes need approval.** Any change to spoken text (grammar repair, location
  correction, a new line adapted from a report) is listed and approved before recording.

## E. Continuity
- **E1 · Parallelize only independent dependencies.** Model dependencies between actual takes,
  anchors, references and story states, not scene numbers. Separate scenes can depend on the same
  evolving prop or character state; clips in one scene may be independent when their checked
  anchors establish the required states. A dependent chain remains sequential: render the parent,
  inspect its real endpoint, approve its continuity handoff, then finalize the successor prompt.
  Independent ready chains may render together under the approved budget. Drafting later coverage
  is allowed, but speculative blocking never authorizes a dependent submission.

- **E2 · Chain from the real last frame.** The keyframe method uses the previous clip's last wide
  (`tools/lastframe`, uploaded) as the next `start_image`. The extension method continues the
  parent job directly.
- **E3 · Seam check.** Before accepting clip N+1, compare clip N's last frame with clip N+1's first
  frame. They must match in geography, positions, props, costume and scale. Ending on a wide isn't
  enough: the join is what the viewer sees.
- **E4 · Write blocking from the frame, not from the script.** Describe the positions and the
  background exactly as the previous last frame shows them. Never add props or positions the
  frame doesn't show. **Rewrite the FIRST FRAME / LOCATION MAP for every clip**; never copy it from
  the master. Props change state (an envelope pocketed, a mug broken), people move (a character
  stepped forward), people leave frame (say who is out of view and where they enter from).
- **E5 · Start every clip on its start frame.** With the keyframe method, the first ~1 s shows the
  start frame's composition. Never open with a hard cut to a new angle, or the model invents the
  background. With extensions, the first 0.6 s is "the same shot, continuing seamlessly".
- **E6 · Keyframe chains end on a wide.** The last shot is a wide with every character fully
  visible: the position reference for the next clip. Keep it short; the edit trims it [J3].
- **E7 · Fragile signature details get a close-up keyframe.** Masks, scars and jewellery: build a
  close-up keyframe with the detail correct, and start that character's lines from it as one
  continuous shot.
- **E8 · Reactions are push-ins, not hard-cut singles.** Hard-cut singles let the model re-seat
  people. Push in from the wide, or pan across.
- **E9 · Anchor-frame workflow (for regeneration rounds).** Design the wide anchor keyframes first
  and get them approved. Then render with `start_image` + `end_image` (in parallel is allowed),
  and seam-check every join.
- **E10 · Confirm continuity method per run (BINDING).** Ask for extension chains / keyframe
  chaining / mix at a new run or material scope change. Record the answer with the run and decision
  version. Reuse the same version on a resume and for scenes already covered by the approved plan;
  do not ask again merely because an agent rotates or a scene begins. A proposed method change
  requires an impact review and confirmation. Extension facts are in `REFERENCE.md` §3.

- **E11 · Fix the frame, not the prompt.** When a look or pose is wrong, edit the keyframe with GPT
  Image 2.5 (add a mask, make someone stand, remove an extra) and start from the edited frame.
- **E12 · State changes must survive the ending wide.** The model snaps back to the start
  composition, so check that a character who stood up is still standing.
- **E13 · Master first, checked, per location.** Before any clip in a new location, make its
  master frame (GPT Image 2.5 from the plate and character sheets) and check hands and limbs,
  duplicate people, prop counts and agreed light. Fix flaws in the image [E11]. If a master or
  reference is later found defective or changed, first mark affected descendants for re-review and
  block their use as continuity parents. Inspect which takes actually inherit the defect; preserve
  those verified unaffected with evidence. Fix the frame and propose the smallest supported repair
  for affected takes. Obtain the required regeneration/spend approval [J5] before submitting;
  never automatically regenerate every descendant. Revalidate changed joins and downstream states.

- **E14 · Attach every reference on every call.** `start_image` = the start frame; one
  `image_references` entry per visible character (face and costume) and one for the location
  plate; one `audio_references` entry per speaker (keyframe method). Map each `@imageN` /
  `@audioN` in ACTIVE REFERENCES. Naming a face or a place in text alone doesn't hold it.
- **E15 · End on the established master angle.** A closing wide from a new camera position invents
  props (HSF: two suitcases became four). If the story needs a new wide, check the prop counts.
- **E16 · Re-anchor after two handoffs.** Wides soften with every last-frame handoff. After at
  most two, make a fresh sharp anchor (GPT Image edit of the last frame: same positions and prop
  state, master-level detail), check it, and start the next clip from it.

## F. Coverage, pacing and framing
- **F1 · Dynamic coverage.** At least 40% of a STILL clip's runtime is varied coverage (MCU, CU,
  low or high angle, POV, OTS, inserts), with the same room geography in every shot.
- **F2 · MOVEMENT or STILL.** A MOVEMENT clip is one continuous uncut shot following the move,
  with at most two characters moving, and the distance and speed written in ("walks about 1.5 m at
  4 km/h"). A STILL clip (nobody moves) may cut, about 4–5 shots in 8–10 s.
- **F3 · Pace.** Shots are about 2 s, never over 3 s. STILL clips run 8–10 s, MOVEMENT clips 5–6 s.
  People walk at a natural 4–5 km/h. Write "brisk, natural pace, no pause longer than half a
  second". Avoid "slow / quiet / still / holding / restraint" as pace words.
- **F4 · Dialogue opens on a close shot.** No line starts on a wide. The opening wide is a silent
  continuity frame (0.5–1 s, cut in the edit); hard cut to an MCU or CU, and the first word starts
  there.
- **F5 · Geography per shot.** Say what's behind whom in each shot, from that camera. Left and
  right are valid only for the master camera. State each character's position at every beat.
- **F6 · Lean prompts.** Keep the block order, the verbatim AUDIO, the tags and the first-frame
  lines; remove repeated lock lists.

## G. Acting
- **G1 · An acting note per line, not adjectives.** For each line write what the character wants,
  what they hold back, where their eyes go, and a target intensity. Add "never neutral: the
  expression shifts on every line" and "no wide eyes, raised brows or big mouth shapes".
- **G2 · An acting sheet per character**, written once in the handoff (temperament, how they hold
  tension, eye habits) and reused.
- **G3 · Subtle shock.** Shock and revelation beats are pitched at about 3/10. Write the tells: a
  half-second pause, a fractional widening of the eyes, a chest gone still, a swallow, a slow
  blink. **Banned words:** gasp, stunned, shocked, "lips parted", "mouth open", "hand to chest",
  "hand to mouth", "step back", recoils. Keyframes never bake in a gasp.
- **G4 · Confrontations have energy.** Pitch them at about 7–8/10, with a handheld, slightly shaky
  camera pushing in. Menace, not shouting.

## H. Realism and prompt language
Full detail is in the prompt skill (`.claude/skills/pocketfm-seedance-prompt/SKILL.md`): the
**PRODUCTION LEARNING LAYER** (48 lessons from real Higgsfield + GPT production — resolve the scene
first, one job per reference, geography, props and hands, performance, timing, audio contract,
preflight, review and repair) and the REALISM LAYER.
- **H1 · Skin line per character.** Name concrete, small flaws matched to age (pores, stubble pores,
  fine lines, a slight sheen, loose strands). Mark flaws "subtle" or "faint", and don't add
  freckles unless the sheet shows them. Over-literal wording turns sweat into beads and chapped
  hands into raw red patches.
- **H2 · Lighting as physics, no Kelvin.** One key light with its side, almost no fill, a rim light,
  and warm or cool words. **Never write colour temperatures.**
- **H3 · Required phrases, word for word:** "realistic lighting ratio between key and fill"; "face
  never overexposed, skin detail still visible in the brightest areas"; "handheld stabiliser or
  light handheld"; "real lens bokeh"; "natural depth of field".
- **H4 · Quality cues.** The STYLE line always opens with "Ultra-HD 4K, 30fps, cinematic realistic
  portrait texture." These change the render quality, not the output size.
- **H5 · Fire and prop safety (mandatory).**
  - Never put fire, flame, flare, glow or burn words in a sentence that mentions eyes. The only
    light wording for eyes is "small soft warm pinpoint catch-lights, iris colour clearly visible".
  - Flames stay inside the hearth and their holders.
  - Flammable props get a distance and the word "intact" ("lies flat and intact, about 30 cm from
    the nearest candle"), repeated in POSITIVE LOCKS.
  - Never use these words near a face or a prop: guttering, smoke, sparks, embers, blaze, fiery.
- **H6 · No beauty words:** flawless, perfect skin, glowing, porcelain, stunning, gorgeous.
- **H7 · Positive phrasing only; FOV in degrees from the anchor table; speeds in km/h; left and
  right from the camera; no director, film or equipment names.** Exception: the tested exclusion
  lines in [G3], [H10], [I1] and [I5] ("no warm bokeh", "No thunder", "no breathing… sounds") are
  kept word for word, because they work; and a targeted exclusion for one specific, observed
  failure ("the handshake has already finished") is allowed. Never grow an endless negative list:
  after a defect survives two wording changes, change the method (prompt skill, PRODUCTION
  LEARNING LAYER §K).
- **H8 · Location wear.** Describe the set as lived-in (scuffs, soot, worn fabric, dust), even with
  the plate attached.
- **H9 · Keep modern or legible details out of frame.** Frame flags, legible crests and modern
  objects out ("framed from the cobbles to the awnings, the rooftops above the frame"). If a
  location sheet contains them, drop it from extensions once the scene is established.
- **H10 · Guard the agreed light.** If the show's look is cool-only (or any fixed palette), reverse
  close-ups into doorways and hallways still pick up warm lamp bokeh. Write it out in LIGHTING
  ("every hallway light switched off; no lamps, no warm bulbs, no warm bokeh anywhere in frame"),
  check every close-up background on the contact sheet, and fix repeated leaks in the image.
- **H11 · Image masters look like a movie screenshot.** Natural tone, subdued saturation,
  controlled highlights. No heavy film-grain or HDR / tone-mapping wording in GPT Image prompts
  (rejected as oversaturated and grainy on HSF, 2026-10-04). Grain wording belongs in the video
  STYLE line only.
- **H12 · Tears.** "No tears" is ignored on child close-ups. Write "dry eyes, dry cheeks", or
  accept it and list it as a known issue.

## I. Audio
- **I1 · No invented sounds.** Every AUDIO block says "only the spoken lines and room tone; no
  music, no breathing, gasping, sighing or sobbing sounds". In QA, read transcripts for
  `[thud]`, `(gasping)`, `[sigh]`, music and so on, and mute those stretches in the edit.
- **I2 · Narration is cloned and verbatim.** Generate narration with `seed_audio` from the
  narrator's sample, one line per job. Transcribe every take; regenerate gibberish or missing
  words. Spell out numbers ("twenty-second") when a take drops them, and trim leading silence.
- **I3 · Voice references must be 15 s or shorter** (longer ones give a 422 error).
- **I4 · Extension mode refuses voice references** (422 error). Dialogue inside an extension gets a
  model-made voice: describe it in the ACTIVE REFERENCES line, or put that line in a keyframe clip
  with the voice reference.
- **I5 · Rain and weather.** Write "No thunder" in every rain scene's AUDIO; otherwise the model adds
  thunder under the lines.
- **I6 · Voice-over inside a clip** (the alternative to Seed Audio narration [I2]). Generate it as
  its own clip with the narrator's voice reference: "Voice-over only… the voice is not from anyone
  in the room; no lips move", plus "no lips move at all" in POSITIVE LOCKS. The QA result
  "NO LIPSYNC" is the pass. A voice-over insert started from an older master uses only its
  close-ups if props have changed since.
- **I7 · Check source dialogue levels.** Measure each clip's spoken level and its line endings
  before editing. Higgsfield sources can have quiet endings with no fade anywhere in the edit;
  level them in the mix rather than regenerating.

## J. Edit
- **J1 · Fast micro-drama pace.** Trim dead space: held wides, pauses, silent tails.
- **J2 · Cut only at real shot boundaries; no slivers.** No leftover piece under 2 s at a clip's
  head or tail, and no complete edge shot under 1.2 s. Boundaries come from `tools/shotcuts.py`.
  Extension heads that continue the previous shot (`"cont": true`) are exempt.
- **J3 · Wide-to-wide joins.** If the next clip's opening wide is longer than 2 s, punch in
  about 1.4×. If it's 2 s or shorter, cut it out.
- **J4 · Split edits for dialogue in a leftover.** Use an L-cut (`a_post`) or a J-cut (`a_pre`)
  onto a silent neighbour. Never leave the sliver.
- **J5 · Edit fixes before regeneration.** Fix review notes by trimming, reordering, reusing or
  letting voice-over run over neighbouring picture. Regenerate only when the person asks or no
  edit fix exists, and ask first, with the cost.
- **J6 · Captions on, verbatim.** Every timeline gets a CAPTIONED version; re-count the captions
  against the script after every re-edit.
- **J7 · Never touch the person's timelines.** Build new, versioned timelines (`<SLUG> v1`, v2…) in
  the agreed Resolve project. Render or export beyond the preview only when asked.
- **J8 · Voice-over never overlaps dialogue or another voice-over line**, and never runs past the
  last clip of a render part.
- **J9 · No flash frames.** An EDL in or out point exactly on a cut can show two frames of the
  neighbouring shot: keep in/out points about 2 frames (0.08 s) off a cut. `tools/shotcuts.py` can
  miss a cut that is followed by fast motion (a slap, a whip pan): when the contact sheet shows a
  shot change the JSON lacks, add it by hand. `build_edit.sh` scans the preview and stops on any
  shot under 0.5 s.
- **J10 · Reviewed takes only; repairs verified before final.** Every EDL clip must have an
  approved or needs_repair row in `logs/qa_index.csv` [K4]; `build_edit.sh` checks this. A
  needs_repair take is permitted only in a clearly labelled review cut with a tracked repair.
  Final delivery requires evidence that the specified repair was applied and verified in that cut,
  or explicit acceptance of a permissible remaining issue. An accepted issue cannot bypass a
  binding rule or an open dialogue/continuity failure. The build's review-list check alone is not
  final acceptance; do not mark a defective source approved merely because its edit was repaired.

## K. QA
- **K1 · Per clip, targeted checks with playback.** Watch each clip and listen to its audio;
  contact sheets and numerical reports are supporting evidence, not substitutes.
  - For speech, verify the transcript against exact line IDs and listen for invented sounds.
  - For visible on-camera speech, inspect lip timing during actual line windows. `tools/lipqa`
    sd > 0.015 detects motion only; it does not prove synchronization, pronunciation or the right
    speaker. Do not run speech lip checks on silent clips; mark them not applicable with a reason.
  - For narration over visible faces, inspect for unwanted speaking; a NO LIPSYNC result alone
    does not prove the whole clip passed. Inspect silent clips for unwanted speech/audio too.
  - Faces and costumes match the sheets; acting matches the approved line notes.
  - Blocking is as written, with no extra or duplicated characters ("exactly ONE <name>").
  - Prop colours and state match neighbouring clips; motion is physically coherent.
  - Fire and prop safety holds [H5], and safety holds [L].
  - The join holds [E3] where a predecessor exists. Mark absent joins not applicable.
  Missing playback, audio access or evidence is unverified, never a pass.

- **K2 · Inside a clip,** compare positions between each pair of consecutive shots, not only the
  first and last frames.
- **K3 · The whole cut.** Play the complete exported preview at normal speed with sound;
  inspect story clarity, acting, pacing, motion, joins, dialogue intelligibility and sound levels.
  Check the contact sheet against the locks. Match every caption's text and order to the approved
  line list, and verify timing, readability and placement in playback; matching counts alone is
  insufficient. Verify no slivers [J2], flash frames [J9] or voice-over overlaps [J8]. Confirm output
  spec and all repair obligations in this export. Log timestamped evidence and any unverified
  checks; final delivery requires no open dialogue or continuity failures.

- **K4 · One review row per take, written at once.** After reviewing each take, add one row to
  `logs/qa_index.csv` (and the same verdict in `HANDOFF.md` §6.2): `clip` (the EDL path, e.g.
  `SC01/A1_a2.mp4`), `verdict` = **approved / needs_repair / rejected**, `reason` (one line),
  `evidence` (where the contact sheet, transcript and lip report are saved), `edit_use` (which EDL
  uses it, or "do not use"). Rejected and superseded takes get a row too; the list is never empty
  while clips exist. approved = use as is; needs_repair = usable in a review cut, with a known fault
  to fix before final; rejected = never use. Gates and deliverables (master frames, spec, spend,
  every cut sent for review: pending → approved by name) go in `logs/approvals.csv`.

## L. Safety and platform filters
- **L1 · Restraint is never at the throat or neck.** A hold is on the upper arm, sleeve or wrist,
  and the prompt says "her neck stays clear in every shot". Reject any take that shows a hand
  at the throat.
- **L2 · Children.** Lifted gently under the arms, never by the neck. No violent close-ups of a
  child. Distress is shown through separation, not screaming.
- **L3 · Content-filter triggers.** An adult leaning over a child in bed was flagged as NSFW;
  restage it (asleep at the table, a shawl laid over the shoulders). Everyone stays fully clothed;
  intimacy is implied, never explicit.
- **L4 · Implied violence.** A slap reads well and stays PG when shot past the striker's shoulder:
  the head turns with a single sound, and the hand stays off-frame. One strike, never repeated.

## M. Review rounds
- **M1 · Frame.io.** Timecode 01:00:00:00 = timeline 0. Map each note to its clip through the EDL,
  and pull the frame. For vague notes, propose an interpretation and ask. Log a table per round
  (#, TC, clip, note, decision, cost).

## N. Multi-agent coordination
- **N1 · Shared rules, named accountability.** Role ownership identifies who prepares or checks
  work; every agent remains responsible for all applicable rules. Use `MULTI_AGENT.md` and the
  assigned `agents/` brief. Roles cannot waive gates or reinterpret approved creative choices.
- **N2 · One director owns canonical state and submission.** Only the director updates decisions,
  approved plan/packets, HANDOFF and canonical logs/coordinator state, or submits paid jobs. Workers
  return proposals and evidence in assigned task folders. Reserve estimated commitments before
  submission; check actual spend plus outstanding commitments plus proposed cost against the cap.
  Record unknown submission outcomes and reconcile them before any retry [B5].
- **N3 · One Resolve owner.** Only the assigned QA/editor accesses the active Resolve project,
  including `transcribe.py`, project-opening helpers, timeline edits, builds and saves. This owner
  also serializes `shotcuts.py`, which writes shared `4_renders/edit/shotcuts.json`. Workers
  request these operations through that owner. Rotate ownership only after an explicit handoff
  with no operation in flight; never run concurrent Resolve operations.
- **N4 · Observed parent handoff.** Before dependent submission, store the accepted parent take/job
  and version, actual inspected end-frame path/time, positions and facing, camera, props/hands,
  costume/light, unfinished movement/audio and QA evidence. The director releases the dependency
  only after review. No planned endpoint or cached summary substitutes for the actual frame.
  Rejected, superseded or invalidated parents block their descendants until reviewed again.
- **N5 · Bound tasks and fallback honestly.** Give workers versioned inputs, an owned output path,
  acceptance criteria and explicit dependencies. Reject stale results or review their impact before
  adoption. If real sub-agent execution is unavailable, perform the same roles sequentially and
  report that mode; never present role-play as concurrent independent review.

## Prompt-learning integration — synced 2026-10-04
The prompt skill's PRODUCTION LEARNING LAYER refines prompt construction conditionally;
it does not waive plan approval, budget, reference/test gates or role ownership. Keep
F3/J2 and supported rendering constraints unless a specific approved exception is executable.
Previous-video continuity with a new opening angle is a separately approved per-clip method,
not an instruction to ignore E5 in a start-frame chain. Verify mode/tool support before use.
Image/video edit modes described in the archive are historical candidates, not verified current
capabilities. Paid repairs remain director-submitted and subject to J5 approval. After two
failed wording changes, propose a method change with evidence and cost; do not auto-spend.
The layer's archival SUCCESS labels mean completion, not QA approval. Keep its provisional
lesson status and require actual-media review. Generic preserve-all wording is scoped by the
explicit role of each attached reference; extension audio exclusions still follow I4.

## O. Visual review and oversight
- **O1 · Whole-scene setup before downstream spend.** Apply the user's source rules through
  docs/VISUAL_REVIEW.md. The first master must support all relevant participants, listeners,
  later action, access and protected reveals. Reuse the scene record; reopen changed checks.
- **O2 · Evidence before visual release.** Inspect actual media at intended size and required
  opening/closing wides, boundaries and action moments. Missing mandatory evidence is NEEDS
  REVIEW, never PASS. Reviewer PASS is not human selection or complete audio/editor acceptance.
- **O3 · Complete, version-bound coverage.** Reviewers use the same asset and scene/reference
  versions; a named lead reconciles all nine checks and disagreements. No averaging away serious
  defects. Split checks or assets explicitly; no duplicated repair orders.
- **O4 · Bounded repairs per defect.** One targeted repair proposal, then one changed approach
  if still failing, then escalate. Track the same defect across takes/agents; rotation does not
  reset attempts. This limit does not authorize spending: J5 approvals and budget still apply.
  Recheck the defect, protected elements and joins; regenerated media gets a complete quick review.
- **O5 · Oversight is advisory and bounded.** Supervisor and watcher return actionable evidence
  to the director at defined events. No continuous polling, self-spawning, spending, approval,
  cancellation, reassignment, or canonical-state edits. Silence alone proves neither failure nor
  poor performance. Respect actual host capacity and include monitoring overhead in benchmarks.
