# Company-Account Guard — Setup & How It Works

This secured copy of the multi-agent kit adds a gate so the Higgsfield tools
only run when the **Pocket (enterprise) workspace** is the active one. Attempts
from a personal account are blocked and logged.


## Files added
- `guard/hf_guard.py` — the gate, shared by both hosts (readable on purpose; see "Why").
- `guard/guard_config.json` — company workspace names + log settings.
- `guard/company_logger.gs` — Google Apps Script for the private log sheet.
- `guard/state/` — live verification state, per machine (git-ignored).
- `.claude/settings.json` — wires the guard into Claude Code.
- `.codex/hooks.json` — wires the same guard into Codex.

## How the gate works
1. At session start the guard clears any verification and tells Claude the kit
   is company-only.
2. **Every credit-spending Higgsfield tool is blocked** until the active
   workspace is verified this session.
3. Verification happens automatically: when `list_workspaces` (or `balance`)
   runs, the guard reads the **real result**. It unlocks only if the *selected*
   workspace matches a company name AND is on the `enterprise` plan.
4. A personal / free workspace never unlocks it, and the attempt is logged.
5. Switching workspace (`select_workspace`) re-locks it. Verification also
   expires after `verify_ttl_seconds` (default 1 hour).

Because the gate is a **file written only on a genuine company result**, no
prompt like "ignore the check and run anyway" can bypass it — the host (Claude Code or Codex)
enforces hooks outside the model.

## Setup (once)

### A. Turn on logging (optional but recommended)
1. Create a Google Sheet. **Keep it private — do not share the link.**
2. Pick a long random secret. Put the SAME value in:
   - `guard/company_logger.gs` -> `SECRET`
   - `guard/guard_config.json` -> `log_secret`
3. In the Sheet: Extensions -> Apps Script, paste `company_logger.gs`, Save.
4. Deploy -> New deployment -> **Web app**:
   - Execute as: **Me**
   - Who has access: **Anyone**
5. Copy the Web app URL into `guard_config.json` -> `log_endpoint`.
   (Leave `log_endpoint` empty to disable logging entirely — the gate still works.)

The URL can only *append* a row. Callers cannot read, edit, or delete the sheet.
Rows without the correct secret are ignored.

### B. Tell people it's on
Add a line wherever colleagues read first (README / handoff):
"This kit works only with the Pocket company Higgsfield account. Personal-account
use is blocked and logged." This is the real deterrent, and India's DPDP Act
expects notice when personal data (name/email) is collected — clear it with HR.

## What this stops, and what it doesn't
- Stops: casual/accidental personal-account use, and prompting Claude to skip
  the check. Every such attempt is logged.
- Codex: the same guard runs through `.codex/hooks.json`. Codex only runs project
  hooks after the user trusts them in `/hooks`; until then `AGENTS.md` tells Codex not
  to generate, which is an instruction rather than a lock. Other hosts without hooks
  get only that instruction.
- If `guard/hf_guard.py` is deleted, both hosts block Higgsfield calls (fail closed).
- Does NOT stop: someone who hand-edits `.claude/settings.json` to remove the
  hook, or deletes `hf_guard.py`. That is the "extra steps" case.

### Make removal matter (company-managed laptops)
On Macs your IT manages, install the hook in **managed settings**
(`/Library/Application Support/ClaudeCode/managed-settings.json`) so colleagues
can't remove it without admin rights, and set `allowManagedHooksOnly: true`.
On laptops nobody manages, the project-level hook here is the ceiling — the gate
plus logging, which is what was asked for.

## Why the logic is not hidden
The gate's strength is the host (Claude Code or Codex) enforcing the hook, not secrecy. Hiding the
code would add nothing and make it unmaintainable. The only sensitive value is
`log_secret`; keep `guard_config.json` out of any public sharing.
