# Dispatch review and oversight without slowing production

Seven role definitions are available; the current host has four active slots including the
director. Role definitions do not change that limit. Use real host agents, not pretend concurrency.
No recursive spawning from reviewers, supervisor or watcher. Director dispatches all work.

## Three additions
- **Visual reviewer:** based on the supplied document. Reads the whole relevant scene once at
  setup, inspects actual images/clips, consolidates defects, returns PASS / REPAIR / NEEDS REVIEW.
- **Workflow supervisor:** short audit of gates, dependencies, costs, uncertain jobs, versions,
  repairs and ownership. Returns recommendations; does not approve or release anything itself.
- **Agent watcher:** one task-health snapshot at meaningful events. Distinguishes working,
  tool-running, render-wait, user-wait, dependency-wait and no-signal. Reports evidence-backed
  abandoned work, conflicting ownership or repeated loops. Never infers laziness from elapsed time.

## Default allocation
During production: director + production + visual reviewer + QA/editor. Story/continuity remains
an assigned responsibility via its prepared scene packet; rotate a worker back when it needs new
analysis. During reference planning, swap editor duties for story/continuity until editing is needed.
When a worker finishes, use that slot briefly for a supervisor or watcher check if a trigger exists,
then reuse it for production/review. The director may perform those checklists inline when capacity
is full, explicitly recording that no independent supervisor ran. Never interrupt useful work just
to run oversight. Do not transfer editor ownership while a Resolve operation is in flight.

## Multiplying visual reviewers
Default: one reviewer per independent ready asset, with a stable scene record. Two reviewers can
clear two ready assets while the director and editor/production worker keep moving. Do not create
reviewers waiting for media that does not exist. Independent remote jobs may keep rendering even
when agent slots are temporarily used for review; director still reconciles their results.

For a complex critical asset, split into three lanes under docs/VISUAL_REVIEW.md: story/geography/
state; identity/look/realism; action/performance/temporal. One of these workers is the lead, not an
extra fourth reviewer. With four total slots this occupies all worker capacity temporarily; use
only when the critical-path benefit warrants it. Prefer two lanes or per-asset parallelism otherwise.
All mandatory checks must be allocated. Shared R6/R9 boundaries need explicit lead coverage.

Never have several reviewers independently send paid repair requests or interpret different asset
versions. They return reports to the lead/director; one consolidated repair brief goes forward.
A new generated version needs its own review. Same defect IDs/counts persist across worker swaps.
Use templates/VISUAL_REVIEW_SCENE_TEMPLATE.md and docs/REVIEW_GATE.md.

## Oversight triggers
Supervisor: setup readiness, test-to-production gate, affected dependency release/change/failure,
resume, assembled scene and final cut. Batch unchanged releases and cite earlier valid evidence.
Watcher: local task handoff/completion or a missed agreed checkpoint with a stated expectation basis.
No always-on watcher, timer polling, new scheduled automation or repeated unchanged alerts.
Checkpoints are expectations, not permissions to kill/retry. Reconcile remote jobs before reassigning.
Supervisor owns process correctness; watcher owns observable task health. Neither repeats media QA.

## Release and evidence
Visual PASS recommends acceptance within its scope only. Director checks human selection/approval,
editor-owned sound/dialogue checks and observed continuity before accepting/releasing downstream.
REPAIR and NEEDS REVIEW block affected branches; global credit/service stops remain global.
Only director writes canonical state/submits paid jobs; only editor changes Resolve/shared edit data.
All other roles write unique work/<task-id>/ reports. User's source document remains reference
material; it does not authorize production or override the user's current explicit direction.

Measure time to accepted cut and rerun cost including review/consolidation/oversight overhead.
Retain the extra reviewer only where ready-queue delay or costly avoided rework justifies it.
No speedup is claimed until the isolated comparison is run at equal quality thresholds.
