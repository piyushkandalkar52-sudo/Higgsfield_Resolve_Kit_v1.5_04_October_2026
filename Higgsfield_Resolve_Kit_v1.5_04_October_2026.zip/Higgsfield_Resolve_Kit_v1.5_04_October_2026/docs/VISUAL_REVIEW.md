# Visual review protocol

Source: the user's **AI Production Reviewer Agent Rules**, preserved as
[DOCX](reviewer_source/AI_Production_Reviewer_Agent_Rules.docx) and
[extracted text](reviewer_source/AI_Production_Reviewer_Agent_Rules.txt). The source supplies
review requirements, not authorization to produce, spend, or rewrite approved creative choices.
This protocol implements all nine numbered rules and its efficient-review, evidence, decision,
repair-loop and compact-record sections. It adds multi-agent ownership and mode-aware gates.
`RULES.md`, `MULTI_AGENT.md` and `docs/COORDINATOR.md` retain their production authority.

## Shared review inputs

The director publishes one short versioned scene record using the template. A reviewer proposes
updates; only the director adopts canonical changes. Every task names the exact asset ID and
version, media path/digest, scene-record version, script/direction version, approved reference
versions/digest and role, parent take/version and actual endpoint where relevant. A digest is an
actual file/content checksum or an explicitly identified immutable version set, never an invented
hash. Do not merge reports with mismatched inputs without an impact review and fresh checks.

Read the complete relevant scene/sequence before its setup is accepted; include later dialogue,
narration, reactions and exit beat, with adjacent context where relevant. Whole-script reading
before planning remains required by R-D1. Once checked, reuse the concise scene record; update
changed fields and reopen affected checks after cast, script, reference, staging or state changes.
Historical manuals and past SUCCESS labels are evidence, not live decisions or proof of quality.
Active script, latest explicit direction, approved references and preceding accepted output govern
the event. Escalate unresolved contradictions; preserve selected work and intentional reveals.

## Nine-rule source map and acceptance checks

| Source rule | Required review | Kit relationship |
|---|---|---|
| **1. Whole scene before setup** | Read the entire relevant event. Locate every necessary participant as visible, offscreen, arriving later or deliberately concealed. Map hearing range, entrances, movement routes, listener positions and space needed by later action. Do not invent unspecified relatives or counts. A hidden person may be present, but the reveal must remain physically possible. Block downstream use of a master that excludes required people, access or later beats. | D1, E13; scene setup gate |
| **2. Frame from an unfolding film** | Identify each person's activity, attention and relationship to the space. Check motivated gaze, body angles, hands, depth, natural spacing and individual listener behavior. Reject unintended portrait poses, camera gazes, identical postures, lineups or showroom staging. Story-motivated stillness, symmetry and formal staging are valid; clutter, blur and tilt are not automatic cures. | G, H11; master/keyframe review |
| **3. Blocking and readability** | Confirm who does what to whom and where. Check sitting/standing support, feet/ground contact, scale, furniture intersections, obstacles, entrances, exits and routes. Separate world position, anatomical left/right and screen side; reverse angles may change screen side without moving people. Propose only coverage needed to clarify the event, never decorative extra cuts or camera movement. | E3–E5, F5, K2 |
| **4. Coherent scene look** | Compare to the approved look anchor AND adjacent accepted shots to prevent gradual drift. Check white balance, exposure, contrast, saturation, natural skin, shadow quality and light direction/softness. Allow motivated window/practical/camera-angle differences and separately approved flashback/location/time looks. Warm wood does not demand orange skin; cool daylight does not justify dark faces. Verify color-space/transfer metadata only when actually available, never from appearance alone. | H10–H11, E13; photographic match |
| **5. Photographic realism** | At intended viewing size check skin, anatomy, materials, perspective, reflections, light falloff, contact shadows, depth of field, scale, focus, texture/grain and occlusion against the surroundings. Flag waxy smoothing, halos, sharp-edge artifacts, glowing shadows or excessive saturation. Preserve natural complexion and approved palette; realism is not a mandate for darkness, dirt or desaturation. Prompt labels such as 4K/photorealistic are not output evidence; realistic-but-posed can still fail rule 2. | H, K1; actual-output check |
| **6. Both required wide portions** | Inspect opening AND closing master/wide portions when required, not just the middle. Compare with the approved master and intervening action: identity, proportions, wardrobe, scale, geometry, blocking, props, light, detail and distortion. The closing wide must retain the completed action and listeners rather than reset the scene. Judge distant faces at delivery size; enlarge suspicious regions without demanding close-up detail everywhere. | E6, E12–E16; mode policy below |
| **7. Physical and emotional state** | Track relevant presence, identity, wardrobe, positions, occupied hands, props, injuries, wetness and emotion across every actual cut and join. Preserve people/objects through occlusion and offscreen intervals. Catch repeated completed actions, duplicated/disappearing objects or people, unexplained hand swaps, room changes and emotional resets. Allow scripted changes, clear time jumps and plausible editorial omissions of routine movement. | E2–E4, E12, K2, N4 |
| **8. Action and performance** | Inspect cause, contact, release and result for important sitting, arrival, handover, pouring, embrace, lift and door actions. Check free hands, body turns, timing, reactions after triggers and emotional carry-through. Flag impossible/rushed action or camera movement hiding essential evidence. Relief need not be a broad smile; anxiety need not become shame; forced motion must not read voluntary. Do not add a microgesture per word or irrelevant business. | G, K1, L; temporal evidence |
| **9. Reference conflicts and narrow repairs** | Scope each reference to identity, wardrobe, architecture, blocking, lighting or previous state. Resolve conflicts such as a reference shoulder strap versus the approved bag-on-desk state; do not strengthen preserve-all language. Each repair names the observed defect, location/time, required replacement state, protected elements and recheck scope. Separate observation from suspected cause and preserve accepted faces, room, light and acting. | E11, J5, H7; repair gate |

The kit's fire/prop, child, restraint and other applicable safety checks (H5, L) still apply.
No added role relaxes F3/J2, generation boundaries, audio contracts or approved tool limits.

## Wide and boundary policy

The source's rule 6 is applied to each clip's approved mode and packet. Record opening-wide and
closing-wide obligations independently. If both are required, inspect both and flag either missing
required wide as REPAIR. Always inspect actual first/last boundaries, every relevant internal cut,
and the actual predecessor seam. A closing master is a quality/geography anchor, not an order to
undo an action. Required keyframe-chain wides remain required under E6.

An explicitly approved no-wide extension or insert does not gain artificial wides from this
review protocol. Record each non-applicable wide with the mode/approval reference; inspect its
real boundaries and continuity instead. This is not a reviewer-created waiver of the packet.
If requirements genuinely conflict or the exception is unsupported, return NEEDS REVIEW to the
director before dependent work. An extension alone is not proof that no-wide approval exists.

## Efficient evidence pass

- **Before generation:** review changed instructions for contradictions, missing/conflicting
  references, impossible blocking and overloaded actions. Use deterministic tag, duration and
  format validators where available. Do not reinterpret tool limits or submit a generation.
- **Each image:** inspect the whole composition against the scene record, approved anchors and
  relevant previous state at intended viewing size. Enlarge only suspicious regions.
- **Each clip:** play actual media when available and inspect required wides, actual boundaries,
  internal cuts and meaningful contact moments. Inspect crop safety at opening, action peak and
  ending. Add targeted frames only to resolve a specific defect or uncertainty. State playback
  speed and checked ranges; do not substitute a rapid skim for required temporal evidence.
- **Limited evidence:** record sampled timestamps and unavailable playback/audio. Sampled frames
  cannot verify intervening motion, flicker, contact or performance timing. A missing mandatory
  visual check yields NEEDS REVIEW. Separate visual coverage from editor-owned audio obligations.
- **After repair:** recheck the defect, protected elements and affected boundaries. A completely
  regenerated output gets a quick complete review because unrelated details may change. Reuse
  prior evidence only for portions proven unchanged; retain failed revisions and accepted baseline.

Only the QA/editor operates Resolve, transcription, shared speech windows, EDL/SRT and shared
`shotcuts.py` data. Request those results through that owner; unique frame/evidence output paths
must not collide. The visual reviewer may inspect provided playback but does not claim audio,
verbatim dialogue or lip-sync acceptance on the editor's behalf. An apparent speech issue is a
flag for the editor. Final whole-cut playback and creative acceptance remain required.

## Three decisions and bounded repair

**PASS:** all applicable checks in the assigned visual scope meet requirements, with coverage
recorded. Minor aesthetic preferences do not block. PASS is neither human selection nor whole-clip
acceptance; missing mandatory editor checks still block release.

**REPAIR:** an observed defect materially harms scene setup, story meaning, realism, continuity,
scene matching or required wide quality. Consolidate all material defects into one repair brief
per asset, ordered story/setup first, then physical continuity/identity, then photographic quality.
Use stable defect IDs to retain history through revised takes. Never average a major failure away
with attractive lighting, a numeric score, or other reviewers' passes.

**NEEDS REVIEW:** required evidence is missing, references conflict materially, a consequential
story fact remains unresolved, or the bounded repair loop is exhausted. Name exactly what evidence
or decision is needed. Continue independent eligible work; do not release affected dependencies.
When a known defect and missing evidence coexist, report both; neither condition may be hidden by
choosing a single summary label. Consolidated PASS requires every mandatory visual lane complete.

For each defect: baseline finding → **one targeted repair proposal** → inspect result → if still
failing, inspect reference/staging/task complexity and propose **one changed approach** within
remaining authorized retry/spend budget → inspect result → if unresolved, NEEDS REVIEW and escalate.
This is a ceiling, not automatic authorization for two paid attempts. The director checks edit-first
repair possibilities with QA/editor and obtains required J5 approval, then alone submits any paid
repair. Budget or evidence gaps can require escalation earlier. A surviving defect keeps its ID and
attempt history; renaming a take/defect or switching lanes must not reset the count. New unrelated
defects are tracked separately, without using them to conceal an exhausted repair loop.

The director alone maps recommendations into existing canonical QA rows and the generation
ledger. Visual PASS alone never triggers ledger `accept`. REPAIR does not automatically qualify
for `needs_repair` review-cut use; the editor must establish a feasible tracked repair. NEEDS REVIEW
never maps to approved or accepted. Retain explicit reports for evidence gaps even where the legacy
CSV vocabulary has no matching status. Do not invent new coordinator CLI commands or silently
extend its schema. The director releases a successor only after full required acceptance and an
observed handoff; no reviewer approves its own downstream submission.

## Parallel review without duplicated queues

Start with **one reviewer per independent asset**. Batch only assets sharing stable inputs and
keep separate verdicts. Parallel assets usually save more time than several reviewers reading the
same short clip. Review an upstream master before generating dependent clips; unrelated chains
can continue. Keep a named lead on each scene to preserve context.

For a demonstrably complex asset or costly critical master, the director may explicitly assign:

| Lane | Main ownership | Shared boundary |
|---|---|---|
| Story, geography and state | Rules 1–3, 7: scene intent, participants, routes, blocking, natural staging, persistent state | Rule 6 geography/state; rule 9 story/reference conflicts |
| Identity, look and realism | Rules 4–5 plus identity/wardrobe and photographic integration | Rule 6 wide quality; rule 9 appearance/reference conflicts |
| Action, performance and temporal continuity | Rule 8 plus every cut/join and temporal aspects of rule 7 | Rule 6 opening/ending changes; rule 9 action repair |

All lanes use the SAME asset/version, scene record and reference digest. Rules 6 and 9 are
explicit shared obligations, not gaps between owners. A named **visual review lead** (one of the
workers, not automatically another agent) maintains a coverage matrix for rules 1–9, receives
lane reports at unique paths, inspects cross-lane contradictions and returns one consolidated
verdict and repair brief. The lead reads the whole-scene context and cannot average away a fail.
A lane cannot mark an unchecked rule PASS; record not applicable with reason or unverified.
Overlapping findings use a shared defect ID after consolidation to prevent duplicate repairs.

Current host capacity is **four active agents including the coordinator**. Three visual lanes
therefore temporarily occupy all worker slots; they cannot also imply concurrent production and
an editor. Prefer one or two lanes when production/editing needs capacity. Rotate at task boundaries,
respect exclusive editor ownership and never spawn recursively to fill the roster. With fewer
slots, perform these lanes sequentially and report actual concurrency. These files define roles;
they are not an automatic dispatch service or a claim that agents ran.

Use same-asset splitting only when expected avoided delay/rework exceeds shared-context and
consolidation overhead. Record actual review queue time, review duration, consolidation effort,
rerun cost and downstream escapes in the benchmark. No fixed speedup is promised. Keep the
workflow supervisor and watcher event-driven so they do not consume workers during every render.

## Compact result

Passing: `asset/version — PASS — scene/reference version — coverage/evidence — reviewer/lead`.
Failure or uncertainty: add defect IDs, location/timestamp, observation, required replacement state,
protected elements, recheck scope, attempt history, affected dependencies and next action. Keep
suspected causes separate. Report all material defects found in the same pass, not serial requests.
Use `templates/VISUAL_REVIEW_SCENE_TEMPLATE.md` for the reusable scene record and coverage ledger.

## Optional read-only coverage merger

See `docs/REVIEW_GATE.md` for the supported `tools/review_gate.py` report schema and usage.
It merges declarations; it does not inspect media, create approval, spend or release dependencies.
Machine reports bind `asset_id`, `asset_version`, the actual asset SHA256 and scene-packet SHA256.
Use check IDs **R1–R9** for the nine user-source rules above (not the kit's lettered rule IDs), with
PASS / REPAIR / NEEDS REVIEW / NOT APPLICABLE, reasons and evidence. Missing, incomplete or
contradictory required coverage yields NEEDS REVIEW; otherwise an unresolved defect yields REPAIR;
only complete passing coverage yields PASS. An image requires full-image inspection; video
requires playback and actual opening/closing boundary review. Explicit unknown evidence remains
unverified. Scene-setup image reviews still account for all nine rules, using genuine image-scope
NOT APPLICABLE reasons for temporal checks rather than pretending action has been verified.
Cryptographic binding prevents accidental version mixing; it cannot establish that a claimed
review happened or that a media check was correct. The director must inspect report quality.
