# WORKFLOW — guided multi-agent production

Every step has the same five parts:
- **Goal:** what the step is for.
- **You do:** the coordinator assigns work and incorporates worker evidence.
- **Ask:** the missing user decisions, through the host's supported question interface
  (`AskUserQuestion` on Claude). Respect the host's question limit.
- **Gate:** what must be true to move on.
- **Outputs:** the files written.

Rule numbers like **[R-E3]** refer to `RULES.md`. Show the progress tracker at every step change.
For measurement, choose orchestration-only or full enhanced workflow in `docs/BENCHMARK.md`;
record the selected comparison and do not claim unmeasured speedups.
Read `MULTI_AGENT.md` for the task protocol and coordinator tooling; do not invent CLI commands.

## Operating model
Use up to **four active agents including the coordinator**, rotating duties as work changes:
1. **Coordinator/director:** whole-story understanding, decisions, approved plan, dependency graph,
   spend, submissions, and authoritative state. This is the **only paid submitter and only writer
   of the manifest, shared logs, approval records, and HANDOFF.md**. Register uploads centrally.
2. **Story/continuity lead:** full-source understanding, timing, asset audit, shared locks,
   dependency proposals and observed continuity reviews.
3. **Production specialist:** references, prompts, narration preparation and chain-specific proposals.
4. **QA/editor:** independent actual-media checks, repair recommendations and rolling assembly.
   This is the single editor. Rotate workers into independent production/audio work when useful,
   but explicitly transfer edit ownership with no Resolve operation in flight.
Workers return evidence and write only their assigned task artifacts. They never approve their own
work, spend credits, or concurrently edit shared state. The coordinator incorporates results using
`MULTI_AGENT.md`. One named editor alone writes the EDL/SRT and operates the Resolve project.

A scene label is **not** proof of independence. Connected action, prop state, costume changes,
injuries and character positions can cross scene boundaries. Only release tasks whose exact
versioned prerequisites are approved. Prioritize the longest dependency chain. Draft upcoming
prompts early, but finalize their blocking only after inspecting the real parent output.

The tracker describes gates, not a global barrier: independent references, tests, QA, approved
production, voice work and provisional editing may overlap when their prerequisites permit.
No overlap bypasses user approval, per-scene reference gates or continuity checks. Never claim
parallel speedup for the generation time of a single job.

```
0 Setup ▸ 1 Project ▸ 2 Read & story ▸ 3 Decisions ▸ 4 Plan & cost ▸ 5 References
▸ 6 Test clips ▸ 7 Production ▸ 8 Assembly ▸ 9 Whole-cut QA ▸ 10 Delivery ▸ 11 Review rounds
(Q = quick test, a short side path)
```

---

## Step 0 — Setup check
**Goal:** the machine and accounts are ready, so nothing fails halfway through.

**You do:**
1. Run `tools/check_setup.sh` and show its OK / MISSING list. If the tools are not compiled, run
   `tools/build_tools.sh` yourself.
2. Load the Higgsfield tools in **one** `ToolSearch` call:
   `balance, models_explore, media_upload, media_confirm, generate_image, generate_video,
   generate_video_batch, generate_audio, generate_audio_batch, jobs_wait, show_generation_by_ids,
   transactions`.
3. Call `balance` and record it. Setup checks may overlap with the read-only input inventory.
4. Confirm available agent slots; use the same ownership model sequentially if fewer are available.

**Ask** (only if something is missing):
- "DaVinci Resolve isn't running. Should I open it?" Options: *Open it (Recommended)* / *I'll open it*.
- If Resolve scripting fails, give the exact setting:
  Preferences → System → General → External scripting using: **Local**. Then wait.

**Gate:** every line is OK, or the person accepts a missing item. Without Resolve you can still
generate, but Steps 8–9 must wait.

**Outputs:** the balance line, written to the handoff in Step 1.

---

## Step 1 — Project
**Goal:** one folder that holds everything for this job.

**You do:**
- **New project:** agree a short slug (e.g. `TRA_EP02`) and run `tools/new_project.sh <slug>`. It
  creates `projects/<slug>/` with the standard layout, `HANDOFF.md` and `logs/`.
- **Existing experimental project:** resume it in place. For a baseline project or A/B test,
  create a separate project and copy only approved source inputs; never share writable outputs,
  logs or Resolve projects between arms. Do not initialize over an existing baseline handoff.
- **Resume within the same versioned run:** read the **CURRENT RUN box** at the top of `HANDOFF.md` first [R-A7], then the whole
  handoff: the tracker, the in-flight jobs (poll them first), the decisions and the next steps.
  Reconcile the manifest, reservations and job ids before dispatch. An uncertain submission is
  investigated, never automatically resubmitted. Then jump to the step the tracker shows.
- Assign a run ID, plan version and artifact owners. Approvals persist only for their recorded
  scope/version within that run. A new run requires Step 3 spec, cap and continuity approval.
- List what's in `00_input/` and say what's missing: the script, the character sheets, the
  location plates and the voice samples.

**Ask** only for missing project information:
1. "Project name?" Suggest a slug from the script's title.
2. "Where are the inputs?" Options: *They're already in 00_input* / *I'll drop them in now* /
   *Use files from another folder (give the path)*.
3. "Resolve project for this job?" Options: *New project named after the slug (Recommended)* /
   *An existing Resolve project (name it)*.

**Gate:** the folder exists, a script is present, and the Resolve project name is chosen.

**Outputs:** `projects/<slug>/HANDOFF.md`, tracker at Step 1 ✔.

---

## Step 2 — Read everything and set the story position
**Goal:** know the whole story before planning any part of it **[R-D1]**.

**You do:**
1. Convert documents: `textutil -convert txt -stdout file.docx`.
2. Read the **whole** script, the screenplay and any recording text, end to end.
3. Read every asset sheet. To see them all at once, make a contact montage:
   `tools/montage out.jpg 6 300 400 <images…>`.
4. Map every character in scope to its sheet and its voice sample. Flag anything that's missing.
5. The coordinator reads the full story; workers may independently audit assets and extract line
   IDs in parallel. All creative workers receive the complete script and the approved story brief,
   not isolated scenes without context. Reconcile their findings before planning.
6. Write the **story position** in three lines:
   - the previous sequence's end state,
   - this sequence's start state,
   - how the story ends.

**Ask:** nothing yet. Collect your questions for Step 3.

**Gate:** the story position and the character/asset map are written in the handoff.

**Outputs:** `HANDOFF.md` §1 (story position, verbatim line list) and §3 (look table).

---

## Step 3 — Decisions (the person chooses)
**Goal:** every choice that belongs to the person is made before anything is planned or spent.

**You do:** recover already approved decisions for this run, identify changed or missing fields,
and record each approval against its scope and plan version. Initialize the coordinator ledger
only after the run ID and explicit budget cap are confirmed, following `MULTI_AGENT.md`. Keep aspect ratio, resolution,
frame rate/timeline dimensions and budget as separate fields. The existing pipeline assumes 1440×1080 at 24 fps. Check renderer support before
promising a format; output defaults do not prove the build tools support a requested alternative.

**Ask** in batches of up to 4 through the available user-question interface.

**Batch A (binding for every NEW run) [R-B1, R-E10]:**
1. **Scope:** which scenes or minutes? (*First 2 minutes* / *Scenes 1–3* / *Whole script*)
2. **Output spec:** confirm separate values for resolution, aspect ratio, frame rate and timeline
   dimensions. Show supported choices and any build-tool limitation.
3. **Budget cap:** explicit credits cap, including images, voice, tests and rerun reserve.
   Show current `get_cost` preflight results; the old 480p ≈ 3 credits/s is only a historical estimate.
4. **Continuity method:** *Extension chains* / *Keyframe chaining* / *Mix (recommended for dialogue)*.
   Explain trade-offs from `REFERENCE.md` §3. Extensions depend on the parent job and do not
   accept voice references; keyframes permit voice references but require seam checks.
5. **Reuse:** *Fresh outputs; input sheets/voices allowed* / *Fresh, nothing at all* /
   *Reuse approved outputs*. Ask in the next batch, not as a fifth simultaneous question.

For a resume of the **same run and unchanged approved scope/version**, summarize these choices
instead of asking again. A new run or material change to scope, spec, cap or continuity requires
explicit approval. Do not let workers reinterpret a creative lock independently.

**Batch B (creative, when relevant):**
- **Voices:**
  - *On-camera lines cloned from the voice samples, narration cloned (Recommended)*
  - *The model's native voices*
- **Edit pace:** *Fast micro-drama: about 2 s shots, no dead air (Recommended)* /
  *Propose specific held beats*. The latter requires explicit beat-level rule exceptions and
  renderer/lint feasibility checks; it does not silently waive [R-F3] or [R-J2].
- **Flashback look:** *Sepia with a soft vignette* / *Natural colour*
- **Script wording changes:** list each proposed change (exact source wording → proposed wording →
  reason). The options are *approve all* / *keep the source* / *decide each*.
- **Missing assets** (age variants, new characters, props):
  - *Generate new 1800s-accurate sheets* (or whatever era the script is in)
  - *Skip those beats*
  - *I'll supply them*

**Gate:** batch A is answered and recorded. Batch B is answered, or the person says "your call".
In that case, write down the defaults you chose.

**Outputs:** `HANDOFF.md` §2 Decisions.

---

## Step 4 — Plan and cost (approval gate)
**Goal:** a plan the person approves before any credit is spent.

**You do:** write `projects/<slug>/01_prompts/PLAN.md` from `templates/PLAN_TEMPLATE.md`. It contains:
- the story position;
- the scene list;
- the **clip list**, with for each clip:
  - STILL or MOVEMENT [R-F2]
  - its duration (STILL 8–10 s, MOVEMENT 5–6 s)
  - its shots, each about 2 s and never over 3 s
  - its continuity source: a base clip, an extension of clip X, or a keyframe
  - its lines (dialogue IDs and voice-over IDs)
- costume and look locks, from the sheets;
- an **acting note per line** [R-G1];
- the voice-over line list with target windows;
- the parallel plan: which chains run side by side and which run sequentially [R-E1];
- **the cost:** a `get_cost` preflight on one representative clip of each kind, then the total, the total with a 30% rerun reserve, and the voice and image costs;
- a risk-based test matrix: identity, dialogue/lip sync, interaction, geography, signature props,
  extensions and seams. Default to one test per scene; any shared test coverage or extra tests
  must be named and explicitly approved in this plan. Every scene retains its own reference/look
  gate; scene labels alone never establish that a test or chain is independent;
- four rotating role assignments, task ownership, exact prerequisites and planned overlap;
- a **scratch timing pass before paid generation**, using supplied stills/placeholders and existing
  or locally recorded scratch speech. No paid generation for this pass. Check natural line fit,
  emotional beats, transitions and missing reactions. Record estimated versus measured windows;
  if scratch speech is unavailable, mark timing provisional and test it before dependent batching;
- the permitted release policy: default all planned tests approved before production, or explicit
  user approval to release individual scenes after their applicable tests and master gates pass.

The story/continuity lead drafts coverage and checks dependencies while production prepares
reference/prompt proposals and the QA/editor checks scratch timing. The coordinator resolves conflicts into one plan. Preserve [R-F3], [R-J2],
clip limits and the existing renderer constraints; list deliberate style exceptions by exact beat
and verify tool support before treating them as executable.

Show a short summary in chat (story position, clip count, cost, test clips) and link `PLAN.md`.

**Ask:** "Approve the plan?" Options:
- *Approve: start the test clips*
- *Approve with changes (tell me)*
- *Change the scope*
- *Stop here*

**Gate (binding):** scratch timing has no unresolved line-fit or missing-beat issue (or a named
provisional timing test blocks affected production), the cost includes all paid work and reserve,
and the person explicitly approves the versioned plan, test coverage and release policy.

**Outputs:** `PLAN.md`; `HANDOFF.md` §6.1 clip plan.

---

## Step 5 — References
**Goal:** every image and voice the prompts need is on Higgsfield once, with its id recorded.

**You do:**
1. **Upload** the sheets, plates and voice samples:
   - Run `media_upload` (one call, up to 20 files) and save the response to a file.
   - Run `python3 tools/hf_put.py <response.json> <files in the same order>`.
   - Run `media_confirm`.
   - Write every id into `HANDOFF.md` §4. Never upload the same file twice.
   - Voice samples must be 15 s or shorter [R-I3].
2. **Missing sheets** (if approved in Step 3): generate them with GPT Image 2.5 in the script's era,
   with a new costume on each day change. Show them as a montage.
3. **Masters and keyframes:** build and check the master wide **per location/state** [R-E13] for
   every scene before its first video, including an extension chain's base. For keyframe work add a
   close-up keyframe for any fragile signature detail [R-E7]. Check every master before any clip:
   hands and limbs, duplicate people, prop counts, the agreed light and a natural movie-screenshot
   tone [R-H10, R-H11]. Fix flaws in the image [R-E11]. Log each approved master in
   `logs/approvals.csv` through the coordinator. Reuse an approved master only when its character,
   costume, time, light, prop and geography state matches this scene. A new scene is not
   automatically covered by another scene's master or test.
4. Prepare independent reference groups in parallel after shared character/look locks are approved.
   The coordinator alone uploads/registers media and submits approved image jobs; workers inspect
   results. Do not start a scene's test while any required master or sheet remains unapproved.

**Ask** (only if you generated new sheets or keyframes): "Use these sheets and scene masters/keyframes?" Options: *Approve all* /
*Redo some (say which)*.

**Gate:** each released scene has all required confirmed media ids and approved sheets/masters,
with their versions recorded. Other scenes may remain in reference preparation.

**Outputs:** `HANDOFF.md` §4 media ids, §5 keyframes.

---

## Step 6 — Tests from the approved risk matrix
**Goal:** prove each scene's look and approach before spending on the whole thing.

**You do:**
1. Write each test clip's prompt with the prompt skill, then run the skill's pre-submit checklist.
   Save it as `01_prompts/<SCENE>/<CLIP>_v1.txt`.
2. The coordinator submits only tests with approved references and no unresolved dependencies.
   Independent tests may run in parallel within reserved budget and service limits. Review each
   result as it arrives; do not wait for a whole batch. Workers prepare future prompts meanwhile.
3. **QA each clip** [R-K]:
   - Fetch it with `tools/fetch_clip.sh <project> <SUB> <NAME> <URL>`; this also makes its contact sheet and last frame.
   - The single editor runs `tools/transcribe.py` (it can mutate Resolve/shared speech data).
   - Use `tools/lipqa` only on visible speech windows [R-K1]; inspect synchronization in playback.
     Mark irrelevant speech checks not applicable rather than spending time on silent clips.
   - The single editor runs `tools/shotcuts.py` (it writes shared shotcut data). Workers inspect
     resulting artifacts; do not concurrently invoke tools that mutate shared project state.
   - Look at the sheet. Check the faces against the sheets, the costumes, the blocking, extra
     people, prop counts, fire and props [R-H5], safety [R-L], invented sounds [R-I1], light
     leaks such as warm bokeh behind close-ups [R-H10], and the clip's dialogue level [R-I7].
   - Play the entire clip with sound to check motion, performance, lip sync and sound continuity;
     contact sheets alone are insufficient. If playback/audio cannot be inspected, report this as
     unverified and obtain review before claiming a pass.
   - The reviewer returns evidence; the coordinator **writes the review row at once** in `logs/qa_index.csv` and §6.2 (approved / needs_repair /
     rejected, reason, evidence) [R-K4], and update the CURRENT RUN box [R-A7].
4. Report each clip in the standard card format (`CLAUDE.md` §3), with the spend.

**Ask:** "Test clips: next step?" Options:
- *Approve: run production*
- *Change these (notes)*
- *Regenerate only the failing part*

If the person gives a direction that overrides a rule (e.g. "make this beat brutal, she cries"),
confirm the override for that beat only and log it.

**Gate:** the approved test matrix passes and the person approves production (or explicitly
accepts listed issues). A rolling scene release is allowed only when approved in Step 4 or here;
it requires that scene's applicable tests, timing checks and reference gates to pass. Reuse a
successful test in the finished cut when suitable. A failed shared test blocks all scenes it covers.

**Outputs:** clips in `02_output/video/shots/<SUB>/`, QA sheets in `03_qa/<SUB>/`, `logs/attempts.csv`.

---

## Step 7 — Production
**Goal:** generate every remaining clip, plus the voice-over, at the approved quality.

**You do:**
- **Order:** schedule ready independent chains; different scene IDs alone do not establish
  independence. Within a chain, run one clip at a time. Inspect and accept the parent before
  submitting its child, and rewrite FIRST FRAME / BLOCKING from the observed endpoint [R-E1, R-E4].
- **Versioned handoff:** QA returns the source clip/take/job/version, approved extracted endpoint
  (or keyframe), visible people and positions, screen direction, costume, prop/hand state, action,
  lighting, who is out of frame and where they may enter, plus unresolved issues. The coordinator
  records it and releases only children whose prerequisite versions still match. Never infer an
  unseen state from the script. Replacing a parent or master invalidates dependent approvals;
  recheck affected descendants and follow [R-E13] for flawed-master regeneration.
- Keep one worker responsible for each chain's prompts. The QA/editor checks returned clips while
  an available worker prepares voice or a second independent chain under an explicit assignment. Start provisional Step 8 work
  as soon as approved footage permits; reserve a single editor for shared timeline changes.
- **Every call carries all its references:** the start frame, a sheet per visible character, the
  location plate and, for keyframe dialogue only, each speaker's voice [R-E14, R-I4].
  Extensions use the parent video and omit audio references. End on the established master angle [R-E15];
  re-anchor from a sharp edited frame after two handoffs [R-E16].
- **Extension chains** [R-E10]:
  - `mode: video_extension`, `extension_mode: forward`, with `video_references` set to the parent job id.
  - Start the prompt with "Continue the video straight on from its last frame", and a 0.6 s
    "same shot, continuing seamlessly" segment.
  - Don't add `audio_references`; extension mode refuses them with a 422 error.
- **Keyframe chains:** the start frame is the last wide extracted with `tools/lastframe`
  (uploaded), or the approved keyframe. Run the seam check on every join [R-E3].
- **Voice-over:** run `generate_audio_batch` with `seed_audio` cloned from the narrator's sample,
  one line per item. Transcribe every line, regenerate any line with gibberish or a missing word,
  and trim leading silence.
- **QA every clip** as in Step 6. A failed clip is regenerated **only for the failing part** [R-B4];
  fix it in the edit when you can [R-J5].
- **Spend:** the coordinator reserves the estimated cost before every paid submission. Actual
  charges + outstanding commitments + proposed work must fit the approved cap. Record each
  attempt and job id immediately, including failures; reconcile charges without double counting.
  Poll pending jobs together and never duplicate an uncertain/pending submission. Report after
  every scene. Stop new submissions at the cap or on a 429 error [R-B2]; do not retry around it.
- Keep `HANDOFF.md` §6.2 attempts current: the job id, status, verdict and notes for every submit,
  failures included, plus one `logs/qa_index.csv` row per reviewed take [R-K4]. Keep the
  CURRENT RUN box's "Jobs still running" equal to what is really pending [R-A7].

**Ask:** only when a clip fails in a way that changes the plan (e.g. "the model keeps putting the
hand at her throat: restage as a wrist hold?"), when spend would pass the cap, or before
new paid generation for a repair [R-J5]. A rerun reserve is budget capacity, not automatic repair
approval. Bundle independent repair requests with their exact scope and cost.

**Gate:** every clip in the plan has an approved take, or a logged accepted issue.

**Outputs:** clips, voice-over in `02_output/audio/vo/<SUB>/`, attempts log.

---

## Step 8 — Assembly in Resolve
**Goal:** a captioned Resolve timeline and preview, with problems found during production.
Begin provisional scene assembly when approved takes are ready; final build waits for the complete
approved selection. Scratch/provisional cuts are labelled and cannot satisfy delivery gates.

**You do:** the single editor owns EDL/SRT and Resolve writes. Other agents may propose timing,
caption corrections or scene edits in separate task artifacts. The coordinator merges approved
selections into authoritative state; parallel workers never operate the same Resolve project.
1. Run `python3 tools/shotcuts.py <project>`, which updates `02_output/data/shotcuts.json`.
2. Write the EDL `02_output/data/<SLUG>_edl_v1.json`:
   - Set `"edge_shots"` for the edit list: `"wides"` (keyframe clips open and close on
     continuity wides) or `"designed"` (extension chains or clips that open on a close shot).
   - Use only takes with an approved or needs_repair row in `logs/qa_index.csv` [R-J10]. A
     needs_repair take is provisional until its specified edit repair is applied and verified;
     it cannot pass delivery merely because the build accepts its status.
   - Cut only at real shot boundaries [R-J2], with in/out points about 2 frames off a cut [R-J9].
   - Mark the head of an extension clip with `"cont": true` when it continues the previous
     clip's last shot.
   - Mute stretches with invented sounds by splitting the clip at a shot boundary and setting
     `vol 0` on that piece.
   - Place each voice-over line inside its picture window with no overlaps [R-J8].
3. Write the captions SRT, script-verbatim, one entry per line.
4. Build with
   `tools/build_edit.sh <project> <edl> <srt> "<SLUG> v1" "<Resolve project>"`.
   That one command runs the review-list check, the lint, the FCPXML, the timeline and its
   CAPTIONED copy, the single-track check, the preview and a flash-frame scan of the preview
   (no shot under 0.5 s), then saves the project.
5. Open the preview folder in Finder (`open <project>/05_delivery`).

**Ask:** only for a material creative change or unsupported output specification; routine assembly
within the approved plan proceeds without another approval.

**Gate:** the final build printed DONE, required repairs are verified, and the preview plays at
normal brightness. Check a contact sheet and playback; a contact sheet does not establish motion
or audio quality. Custom formats/pace exceptions must also pass the actual supported build checks.

**Outputs:** `<SLUG> v1` and `<SLUG> v1 CAPTIONED` in Resolve; `05_delivery/<SLUG>_v1.mp4`.

---

## Step 9 — Whole-cut QA
**Goal:** catch what per-clip QA misses.

**You do:** freeze one preview version for parallel reviews: continuity/visual QA and
speech/audio/caption QA. Reviewers return timestamps, severity, source take and evidence; the
coordinator consolidates one issue list and the single editor applies fixes.
- Watch the **entire preview with sound**, checking story clarity, emotional progression, acting,
  dialogue accuracy/intelligibility/lip sync, motion artifacts and every join. If unavailable,
  mark these checks unverified and request playback review; never substitute sampled frames.
- Make a 24-frame contact sheet of the preview: `tools/sheet <preview> out.jpg 24`. Read it
  against the locks: positions, costumes, extra people, readable crests or text, flags.
- Check caption count, exact wording and order against the approved line list, then synchronization,
  readability and placement during playback. Count alone is not acceptance.
- Check that no voice-over overlaps dialogue. The editor checks source shot boundaries against
  the EDL for R-J2 clip-edge slivers and runs `python3 tools/flash_check.py <preview>`.
  Inspect reported short shots in playback. `shotcuts.py` accepts a project folder, not a preview
  filename; do not invoke it on a standalone preview.
- Keep the existing 0.5 s flash-frame scan and 2 s clip-edge requirement: they check different
  problems. An explicit artistic exception does not disable lint or authorize unsupported cuts.
- Classify defects as must-fix, explicitly accepted or cosmetic. Fix in the edit where possible,
  then rebuild as v+1 and inspect changed sections, joins and the final complete playback.

**Ask:** only for an explicit issue acceptance, changed creative direction, or required playback
review when local playback cannot be verified.

**Gate:** full playback and required checks are verified; no open dialogue/continuity failures or
unverified required repairs; explicit accepted issues and cosmetic issues are listed with timestamps.

**Outputs:** `HANDOFF.md` §8 known issues, with timestamps.

---

## Step 10 — Delivery report
**Goal:** the person knows exactly what they got and what it cost.

**You do:** report, then update `HANDOFF.md` (tracker, cut, issues, credits, next steps, session log):
- the timeline names and the preview path;
- what passed;
- known issues, with timestamps;
- a credit table by type (video, voice, images, rejected takes), from the `transactions` list;
- a time table by phase, separating elapsed time from agent effort, generation wait and rework;
- approval/plan versions, remaining reservations, and any unverified checks (never labelled passed).

**Ask:** "What next?" Options:
- *Review notes / Frame.io round*
- *Continue with the next part of the script*
- *Stop here*

When the run or part is finished, move its full report to `logs/handoff_history.md` under a dated
heading and leave a one-line pointer [R-A8]. Log the delivered cut in `logs/approvals.csv` as
pending review.

**Gate:** the report is given and the handoff is updated.

**Outputs:** delivered preview/timeline references, cost/time report, updated handoff/history and
coordinator-recorded delivery approval status.

---

## Step 11 — Review rounds (Frame.io or written notes)
**Goal:** apply review notes quickly, in the edit wherever possible.

**You do:**
1. Read the notes. For Frame.io links, open them with Claude in Chrome and read the comments;
   timecode 01:00:00:00 = timeline 0.
2. Workers may map independent notes to clips using the frozen delivered EDL and pull frames.
   Do not treat notes from different cut versions as sharing the same timecodes. Trace upstream
   changes before proposing dependent regenerations.
3. Build a table with these columns: #, TC, clip, note, proposed fix (edit / regenerate), cost.
4. **Edit fixes first** [R-J5]. For anything that needs a new generation, ask first, with the cost.
5. Rebuild as v+1 with `tools/build_edit.sh`, and log the round table in the handoff.

**Ask:** "Regenerate these N items (~X credits)?" Options: *Yes* / *Edit-only fixes for now* /
*Let me choose per item*. Vague notes: propose an interpretation and ask.

**Gate:** every note is fixed or answered and the revised preview passes Step 9.

**Outputs:** versioned cut, review-note table, repair evidence and coordinator-updated handoff.

---

## Step Q — Quick test (side path)
**Goal:** answer one question cheaply, e.g. "does this prompt idea work?", "does extension hold
the join?" or "is the realism better?".

**You do:** define the single hypothesis, spec and cost (`get_cost`). The coordinator alone
submits approved work and logs attempts/cost immediately, even for failed tests. Generate the
minimum (usually 1–2 clips), QA it, and show a side-by-side or before/after render. A test result
does not silently change approved project decisions or permanent rules.

**Ask:** approve spec/cost and, for a comparison, whether all other variables stay identical.
Ask before promoting the result into project creative decisions or permanent rules.

**Gate:** the question is answered. Then offer to return to the Start Menu.


**Outputs:** test artifacts, evidence and coordinator-recorded attempts/cost; any separately approved decision change.
