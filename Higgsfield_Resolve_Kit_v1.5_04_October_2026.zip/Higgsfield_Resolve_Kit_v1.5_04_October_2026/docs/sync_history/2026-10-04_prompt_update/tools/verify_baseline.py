#!/usr/bin/env python3
"""Read-only verification that the original kit matches its captured file hashes."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    kit = Path(__file__).resolve().parent.parent
    recorded = json.loads((kit / 'BASELINE_SHA256.json').read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', default=recorded['source'])
    args = parser.parse_args()
    source = Path(args.source)
    if not source.is_dir():
        parser.exit(1, f'Original folder unavailable: {source}\n')
    current = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
               for p in source.rglob('*') if p.is_file()}
    changes = sorted(name for name in set(current) | set(recorded['files'])
                     if current.get(name) != recorded['files'].get(name))
    if changes:
        for name in changes:
            print('DIFFERENT', name)
        return 1
    print(f'PASS: original kit unchanged; {len(current)} files match SHA-256 snapshot')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
