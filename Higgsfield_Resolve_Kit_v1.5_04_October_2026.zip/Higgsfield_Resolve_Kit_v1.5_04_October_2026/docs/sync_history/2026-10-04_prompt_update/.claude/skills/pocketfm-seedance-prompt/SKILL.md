---
name: pocketfm-seedance-prompt
description: How to write every Seedance 2.5 / Higgsfield video prompt in this kit — block structure, timed multishot, FOV table, the REALISM LAYER (skin lines, physical lighting with no Kelvin, required phrases, "Ultra-HD 4K, 30fps" quality cues) and the fire/candle/prop safety rules, plus the extension-prompt recipe. Use before writing, revising or reviewing any video, keyframe or narration prompt in this kit.
---


# Seedance prompt writer (Pocket FM kit)

> Extension clips: see REFERENCE.md §3 and templates/PROMPT_TEMPLATE.md §B (start with "Continue the video straight on from its last frame", a 0.6 s continuation segment, no audio_references).

Turn scripts, scenes, and ideas into Seedance 2.0 prompts. Block, light, and pace each shot like a film.

**Output: always a single standalone prompt in a code block.**

---

## CORE PRINCIPLE: WRITE THE VISIBLE

The model reacts to what can be **seen and measured**, not to mood words.

Translate every abstraction into something observable.
- ❌ "tense scene" → ✅ "man freezes, slowly clenches his fist, light only from the side, half his face in shadow"
- ❌ "cool cinematic shot of a car, epic, fast" → ✅ "low tracking shot alongside the car as it powers through a wet curve, headlights glowing, spray off the tyres, hard buffeting camera shake"

Write in plain, clear, instruction-style language. Fewer precise words beat many vague ones.

Before generating, mentally "watch" the prompt as a viewer: is everything unambiguous, is the first frame non-empty, is it clear where the subject is and where it looks, where is the light coming from.

---

## WORKFLOW

1. **Read as a director.** Find the dramatic shape: where the scene turns, lands, breathes.
2. **Define continuity anchors.** Who is in frame, how they look, what they carry across cuts.
3. **Write the prompt** using the block structure below.
4. **Tag assets.** Tagging rules below.

If the idea is ambiguous, close the gaps in conversation first — blocking, angle, light, timing, character behavior, what is in the first frame, how it ends. The model fills any gap on its own, usually not the way intended.

---

## ASSET TAGGING

Reference image (`@tag`) sets **appearance and identity**. Text sets **what happens** and locks critical details. Both are required.

**Tag naming:**
- If the user specifies tags as `@tag_name`, use those.
- If no tags are specified, name them by load order of the supplied assets: `@image1 @image2 ...` for images, `@video1 @video2 ...` for videos, `@audio1 @audio2 ...` for audio.
- Otherwise follow the user's explicit instruction.

**Reference + text rule:** keep the character description minimal — long appearance text conflicts with the image and degrades it.

```
@TAG: age + role/build + current state + unique visible features + action-critical details + voice (only if it has a line). 100% matches the reference.
```

State critical details (small text, logos, color) in words even if they appear on the reference — the model can drop them.

Never place an `@tag` in a shot where that object is not present; the model will try to force it into frame.

---

## CONTEXT ISOLATION

Each generation is a blank slate — **no memory of previous shots.** A prompt is a sealed single-shot document.

Do not carry in: scene numbers, script headings, summaries of prior scenes, unused tags/characters, "as above / continues" phrasing, or people and props from a previous line that are not needed in this shot.

---

## STYLE — DISTRIBUTED, NOT A PREFIX

There is **no separate style-prefix block at the top of the prompt.** Style is not one thing in one place — it is a set of aspects, and each aspect lives in the block that already governs it, where it is most effective and unambiguous. State the target look, never what to avoid; adapt every line to this specific scene.

Cover these aspects, each in its home block:

| Aspect | Lives in | What to write |
|--------|----------|---------------|
| Lighting | **LIGHTING** | source, direction, exposure, key/fill, haze for THIS scene |
| Color / grade | **COLOR GRADE** (own block if grade is strong, e.g. teal-cyan desaturated) or folded into **LOCATION** + **LIGHTING** for a naturalistic look | palette as material + light beam + role, never a flat list |
| Lens / optical character | **OPTICS** | FOV°, rectilinear/anamorphic, prime-lens character, motion-blur |
| Camera body / tonal character | **CAMERA** | tonal latitude, highlight roll-off, color science — as a look, not a model name |
| Skin / micro-realism | **PERFORMANCE** (or inside **ACTION**) | pore-level realism, capillary flush, living eyes, catch-lights, visible breath |
| Acting | **PERFORMANCE** (or inside **ACTION**) | micro-pauses, precise eye-line, restraint, muscle-level emotion |
| Physics realism | **PHYSICS** | gravity, inertia, mass, contact shadows, fluids, particles |
| Composition / blocking | **FIRST FRAME / BLOCKING** | framing rule for THIS scene; everyone moving from frame one |
| Continuity | **POSITIVE LOCKS** | characters, props, environment identical across cuts |
| Wardrobe | **WARDROBE** (own block when costume matters) | material + condition, scene-logical |
| Format / resolution / grain / fps / bitrate | **STYLE** + **OUTPUT SETTINGS** at the **end**, just before LOCKS | STYLE opens with "Ultra-HD 4K, 30fps, cinematic realistic portrait texture" (see REALISM LAYER), then photoreal, fine grain, real-time vs slow-mo per segment |

**Placement principle:** descriptive style (light, color, optics, physics, acting) sits *inside the content block it describes*, in the body of the prompt. Technical/format style (resolution, grain, fps, bitrate, overall look reference) sits as a **suffix stack at the end** (`STYLE`, `OUTPUT SETTINGS`), right before `POSITIVE LOCKS`. Nothing style-related goes at the very top — the prompt still opens on `SCENE CONTEXT` and `ACTIVE REFERENCES`.

Use only the aspects the shot needs. A naturalistic single take may have no `COLOR GRADE`, `WARDROBE`, or `OUTPUT SETTINGS` block at all and fold those notes into LIGHTING and POSITIVE LOCKS. A graded, multi-segment piece earns the full suffix stack.

If the user supplies their own prefix or block text, use it verbatim.

---

## PROMPT STRUCTURE

Write blocks in this order. Logic: context and references first, then space and timing, then action and physics, then the descriptive-style blocks in their home positions, and a technical-style suffix at the end. Use only the blocks the shot needs; drop the rest.

```
SCENE CONTEXT
[1–2 sentences: what happens, where, when. Geo-positions of characters.]

ACTIVE REFERENCES
[@tag + minimal anchor of critical details + "100% matches the reference"]

LOCATION MAP
[Foreground / midground / background, where the camera is, where light comes from, movement paths. Naturalistic color can live here.]

FIRST FRAME / BLOCKING
[Who is where in the first frame: positions, orientation, gaze. Composition rule for this scene.]

FORMAT MODE
[Choose the level of control the shot needs:
 - Single continuous shot — "one continuous shot, the camera does not cut on its own."
 - Sequence of cuts, no timecodes — "CUT 1 … CUT 2 … CUT 3", described in order.
 - Timed multishot — explicit HARD CUTs at stated seconds.]

OPTICS
[Shot size + FOV per segment + lens/optical character. For multishot add "no drift mid-segment".]

CAMERA
[Operator behavior: height, distance, movement, focus. Camera-body tonal character as a look.]

ACTION
[Events at the precision the shot needs. Camera motion and subject motion stated separately.]

PERFORMANCE        (when acting matters)
[Acting + skin/micro-realism: muscle-level emotion, eye-line, catch-lights, breath, pore-level detail.]

PHYSICS
[Mass, inertia, contact, fluids, particles.]

LIGHTING
[Source, direction, exposure, warm/cool words (no Kelvin values) — priority block. Realism layer phrases required.]

COLOR GRADE        (when the grade is strong / stylized)
[Palette as material + light + role; grade character. Omit for naturalistic looks — fold color into LOCATION/LIGHTING.]

WARDROBE           (when costume matters)
[Material + condition, scene-logical.]

AUDIO
[Only the needed sound / line.]

STYLE              (technical-style suffix)
[Opens with "Ultra-HD 4K, 30fps, cinematic realistic portrait texture." Then the overall look in words, photoreal, grain — no director or equipment names.]

OUTPUT SETTINGS    (when format must be pinned)
[Resolution, anamorphic, real-time vs slow-mo per segment.]

POSITIVE LOCKS
[Short fixers against likely failures, in positive form, restating critical info once. Continuity lives here.]
```

The descriptive-style blocks (PERFORMANCE, PHYSICS, LIGHTING, COLOR GRADE, WARDROBE) sit in the body next to what they govern. The technical-style blocks (STYLE, OUTPUT SETTINGS) form a short suffix stack just before POSITIVE LOCKS. Nothing style-related opens the prompt.

A **lock** is a short hard fixer placed next to what it protects, e.g. `"headlights stay glowing in every shot"`. Write densely where control matters, sparsely where it does not. Say each important thing once, clearly.

---

## CUTS AND TIMING

Pick the precision the shot actually needs — these are points on a scale, not a binary:

- **Single shot (oner)** → "one continuous shot, the camera does not cut on its own."
- **Sequential cuts, no timecodes** → describe shots in order as `CUT 1 … CUT 2 … CUT 3`. Use when you want specific cuts but exact timing does not matter.
- **Timed multishot** → explicit HARD CUTs at stated seconds. Use when beats must land on a clock.
- **Freestyle b-roll** → do not lock cuts; let the model find angles.

When you specify cuts (timed or not), lock that the camera does not add its own: *"cuts only at the specified points, the camera does not cut on its own."*

**Timecode format** (only when timing matters):
```
0.0s to 1.0s — [description]
1.0s HARD CUT
1.0s to 3.0s — [description]
```

**Sequential format** (cuts without timecodes):
```
CUT 1 — [description]
CUT 2 — [description]
```

**Cut types:** `HARD CUT`, `SMASH CUT`, `MATCH CUT`, `INSERT CUT`, `REVERSE CUT`, `WHIP CUT`. Fades / crossfades only if explicitly requested.

Across internal cuts hold: same character set, same geometry, screen direction, gaze, light, wardrobe, prop state.

---

## DIRECTING

**Blocking.** State where each character stands, sits, moves; what their hands do; what sits between them. "She sits across from him at the diner booth, knees touching under the table" beats "they sit and talk."

**Pace.** Read the dramatic structure. Confession scene → air, held shots, beats of silence. Action → compression, short cuts. A reveal lands on one held close-up.

**Acting.** Translate emotion into concrete on-shot direction:
- ❌ "she looks sad" → ✅ "her eyes drop to the table, jaw tightens, she swallows once before answering"
- ❌ "he is angry" → ✅ "knuckles whiten on the glass, breath shortens, eyes never leave hers"

Restraint by default — a whisper out-acts a shout most of the time.

**Continuity** (hold in mind, do not write as a block): state carried forward (wet/dry/bloodied), appearance not drifting, emotional carry from the previous scene, one time-of-day and weather unless the location changes.

**Camera language.** Be concrete: FOV°, height, movement, motivation. Motivate every camera move.
- "Low-angle 18° dolly-in, slow push from waist to chest as she realizes."
- "Static 47° two-shot, eye-level, locked off — lets the silence sit."
- "Handheld 63°, follow from behind — camera lags half a beat."

---

## PROMPTING RULES

- **Positive only.** Describe what should happen, not what to avoid. ❌ "does not fall backward" → ✅ "stays upright, feet planted."
- **Speeds in km/h.** ❌ "fast/slow" → ✅ "moves at 40 km/h", "camera pans at 5 km/h."
- **Atmosphere in percent / meters.** ❌ "light fog" → ✅ "fog density 40%", "haze visible at 15 meters depth."
- **Atmosphere builds in steps across shots.** Shot 1: fog 20% → Shot 2: 40% → Shot 3: 60%.
- **Giant scale via human-height comparison.** ❌ "huge", "three meters tall" → ✅ "stands as tall as four humans stacked head to toe."
- **Left/right is from the camera.** "Subject moves left" = left from the camera's view.
- **Environment interaction stated physically.** Snow melts on skin, rain runs down hair, wind moves fabric.
- **Emotion through muscle movement, not labels.**

---

## REALISM LAYER (Pocket FM, learned 2026-10-01, TRA realism test)

Apply to EVERY prompt. Wording only: it needs no extra references or resolution; the regular workflow (480p, 4:3, character sheets + location plate + voice sample, start/end keyframes) stays the same. Where this layer conflicts with a rule above, this layer wins.

### Core idea

The model renders the words literally. Realism comes from naming *specific
physical flaws and physical light behaviour*, not from words like "realistic",
"cinematic" or "beautiful". Every word placed next to a face, an eye or a prop
can show up on it.

---

### 1. Skin block (biggest single gain)

In PERFORMANCE, add one `Skin:` line per on-screen character. List concrete,
small flaws matched to age, sex and the light of the scene. Write it once per
character per show (next to the acting sheet) and reuse it.

- Men: visible pores across nose and cheeks, stubble pores at the beard line,
  faint weathered lines at the eye corners, slight oily sheen on forehead and
  nose, a few loose hairs, (optional) one small old scar.
- Women: period make-up that is light and not flawless, a little powder settled
  in fine lines, visible pores on nose and cheeks, faint marks of old blemishes,
  fine lines under the eyes, natural redness at the nostrils, lip texture with
  tiny vertical lines and a little moisture, real lashes, loose strands escaping
  the hairstyle.
- Children: smooth but real skin, faint flush on cheeks, small dry patch or
  scratch, flyaway hair. Never adult lines.
- Eyes, all: "living eyes: wet surface, small soft pinpoint catch-lights, iris
  colour clearly visible". (See the fire-safety rules, 7: never "fire" or "flame" near eyes.)

Never use beauty words: flawless, perfect skin, glowing, porcelain, stunning,
gorgeous, beautiful face, high-end face. They pull towards plastic AI skin.

### 2. Lighting as physics

Write the LIGHTING block as a light plan: each source with a direction and a
warm/cool word. **Never write colour temperatures (no Kelvin values such as
2200K or 6500K)**, in any block.

- **Key:** one named source, side stated from camera ("warm fire and candle
  light from camera-right, falling on the side of each face toward the
  fireplace").
- **Fill:** "almost none; the far side of each face falls into shadow with
  detail still visible."
- **Rim / background:** a second, contrasting source ("cool moonlight from the
  window, a thin edge on hair and shoulders").
- **Required phrases (always include, word for word):** "realistic lighting
  ratio between key and fill" and "face never overexposed, skin detail still
  visible in the brightest areas".
- **Behaviour:** "flame flicker moves the key level gently on skin and walls".

Every light must have a visible, logical source in the room.

### 3. Optics

"Real lens behaviour: real lens bokeh, natural depth of field, focus held on the
eyes and the bridge of the nose in every close-up, background falling into soft
round bokeh from the practical lights, gentle natural vignetting, no drift
mid-segment."
"Real lens bokeh" and "natural depth of field" are required, word for word.

### 4. Camera as an operator

"Handheld stabiliser or light handheld, at chest-to-eye height, about 1 m from
the actors, like an operator on a light shoulder rig: a small constant breathing float, micro-corrections,
tiny focus breathing on push-ins. Pushes are short and physical (about 20 cm)."
"Handheld stabiliser or light handheld" is required, word for word. For calm
scenes add "on a gimbal with a slight breathing float".

### 5. Location text: worn materials

Even with the location plate attached, describe the set in words with wear and
use: wax-polished but scuffed panelling, soot on the mantel, velvet nap worn
shiny, fringe hanging unevenly, dull pitted metal, worn rug, dust in the air.
The plate gives the layout; the words take the glossy concept-art finish off it.

Optional stronger fix: rework each location plate once (GPT Image edit) into "a
photograph of a real period set, worn surfaces, lit only by its practical
lights", so the reference itself passes on realism instead of gloss.

### 6. STYLE line and locks

STYLE always opens with the quality-cue tokens, then the look:
"Ultra-HD 4K, 30fps, cinematic realistic portrait texture. Live-action period
drama shot on a real set: photoreal people with natural, imperfect skin, real
fabric weight (velvet nap, linen creases, lace with loose threads), fine organic
film grain, true lens softness at the frame edges, gentle highlight roll-off,
rich but natural colour."

The quality cues ("Ultra-HD 4K, 30fps, cinematic realistic portrait texture")
do not change the output resolution or frame rate; those stay as parameters
(480p/720p/1080p, fixed fps). They are kept on purpose: they push the model
toward finer detail and a higher-quality render. Always include them; never
remove them as "redundant".

POSITIVE LOCKS add: "Faces stay stable and true to the references in every
shot: same eye shape, nose, jawline. Eyes hold steady on their target; lips
move only for the spoken words."

---

### 7. Fire, candle and light-source safety (mandatory)

Two failures from the test that must never repeat:

| Failure | Wording that caused it | Rule |
|---|---|---|
| Flames visible inside Amelia's eyes | "small fire catch-lights", "her catch-lights grow" during a fire flare | Never put fire, flame, flare, blaze, burning or glow words in the same sentence as eyes, irises or pupils. |
| The contract on the table caught fire | parchment "beside a guttering tallow candle, a curl of smoke rising from the wick" | Never place a flammable prop "beside" a flame, and never use guttering / smoke / sparks / embers near a prop. |

Required wording:

- **Eyes:** "small soft warm pinpoint catch-lights, iris colour clearly visible."
  That is the only light wording allowed for eyes.
- **Flames stay in their holders:** "the fire burns steady inside the stone
  hearth", "each candle flame stays small and steady in its holder".
- **Flammable props** (paper, parchment, letters, contracts, cloth, curtains,
  hair, sleeves, veils, flowers): state the distance and state that they are
  intact. "The parchment contract lies flat and intact on the table, about 30 cm
  from the nearest candle; its red wax seal unbroken." Repeat in POSITIVE
  LOCKS: "All paper, fabric and hair stay intact; flames stay inside the hearth
  and candle holders."
- **Inserts of a prop:** frame the prop itself and keep candles out of the
  insert, or "a steady candle out of focus 30 cm behind it". Never a smoking or
  guttering wick in a prop insert.
- **Light events** (a log shifts, a door opens, lightning): put the event on the
  source and on skin/walls only: "the flames in the hearth rise for half a
  second; the warm light on the side of her face brightens, then settles".
  Never "flare" near the eyes or near a prop.
- **Banned words anywhere near faces or props:** guttering, smoke, smoking,
  sparks, embers, ignite, flare (outside the hearth sentence), blaze, burning
  (except "the fire burns steady inside the hearth"), fiery, fire in her eyes,
  eyes glowing.
- Same rule for other sources: torches, lanterns, lamps, braziers, lightning,
  the sun through glass. The source stays in its place; eyes get pinpoint
  catch-lights only; props are stated intact.

---

### QA on the result

Before accepting a clip: step through every close-up and check the eyes for reflected flames, and every prop insert for fire, smoke or scorch marks. If found, fix the wording per the fire-safety rules and regenerate; do not stitch over it.

---

## OPTICS — SHOT SIZE, LENS, FOV

Two levers define "how it is shot": **shot size** and **focal length**.

### Shot sizes
| Abbr | Meaning | In frame |
|------|---------|----------|
| ECU | Extreme Close-Up | a detail: eyes, button, headlight, hand |
| CU | Close-Up | full face / one element large |
| MCU | Medium Close-Up | head and shoulders |
| MS | Medium Shot | roughly to the waist |
| WS | Wide Shot | full figure + surroundings |
| EWS | Extreme Wide | scale, location |

### Focal length (mm — for describing size while writing, not for the prompt text)
| Lens | Effect | Use for |
|------|--------|---------|
| 24–35mm wide | space, slight perspective distortion | action, immersion, wides |
| 50mm normal | natural perspective, "as the eye sees" | realism, neutral shots |
| 85mm portrait | soft bokeh, subject separated from background | portrait, emotion |
| 135mm+ tele | strong compression, "watching from afar" | observation, distance, sport |

In the prompt text use **FOV in degrees** from the table below, not millimeters.

### FOV anchor table (degrees for the prompt)
| FOV | mm equiv | Purpose | When |
|-----|----------|---------|------|
| 180° | Fisheye | spherical distortion | POV, dream-state |
| 107° | 14–16mm | architectural ultra-wide | huge interiors, epic establish |
| 84° | 20–24mm | wide | establish, group blocking |
| 63° | 28–35mm | observational | wide observation, reportage |
| 47° | 40–50mm | neutral human perspective | universal establish, medium |
| 29° | 75–85mm | portrait compression | medium-isolate, dialogue bust |
| 18° | 100–135mm | natural portrait | close-portrait, identity-preserving |
| 12° | 180–200mm | tele-detail | hands, objects, detail-on-wide |
| 8° | 300–400mm | extreme compression | observation, broadcast |

Use only the discrete steps from the table. Not "23°" — use 18° or 29°. In a multishot, set FOV per segment and add `"no drift mid-segment"`.

### Camera placement in the prompt
Place the CAMERA block in the **3rd position** of the prompt's core layers (subject → action → camera → style → constraints). Moved to the end, FOV gets ignored; moved to the front, it conflicts with identity.

---

## OPTICAL TECHNIQUES

**Observation pattern (hidden-camera effect)** — all three ingredients at once:
1. Foreground occlusion — out-of-focus obstruction over 20–30% of frame (wall, pillar, branch, arch).
2. Atmospheric haze — fog/dust/shimmer between camera and subject.
3. Distance vantage — super-tele 8°–12°, operator anchored far away.
Change the occlusion type between beats; keep the vantage single.

**Sports broadcast:** `8° super-tele + handheld 1–2cm tremor + "anchored at distance, finding the action"`.

**Detail-on-wide (snake cam):** `84° wide FOV + low-angle right up against a small object` — foreground object exaggerated, background recedes into depth.

**Intimate wide:** `63–84° wide FOV on a close face` — face centered, surroundings readable without blur.

**Tele compressed air column** at 8°–12°: `"dust suspended in the long compressed air column between camera and subject"`, `"heat shimmer compressed into a wall of haze in front of the figure"`.

---

## SPECIAL PROTOCOLS

**4-mechanism multishot consistency stack (extreme FOV: 8°, 107°):**
1. Sequence-wide identity lock — single location reference across all beats.
2. LENS LOCK opener — explicit FOV phrase at the start of each beat.
3. LENS CHECK closer — confirm FOV at the end of the beat.
4. Color via material + light, not as a list.
All four are required, or extreme-FOV multishots break down after 2–3 beats.

**Whip-pan timing:**
```
0.3s — Subject A settled
0.8s — WHIP motion-blur transition
1.4s — Subject B settled
```
A whip under 0.8s renders as a hard cut without blur.

**Mixed time-speed (real-time + slow-mo):** hard cuts only between speed modes. Each shot is one speed start to finish.

**Cracks/breaks without impact (anti-impact lock):**
- "crowd PRESSES, not strikes"
- "fracture originates from edge stress, not center impact"
- "no impact point — pressure-based crack"
- sequential timing edge-to-center, not radial from a point.

---

## CAMERA / LIGHT / COLOR

**Colour of light** in plain warm/cool words tied to the source ("warm candle light", "cool moonlight"), fixed within a scene. **Never write Kelvin / colour-temperature values.**

**Equipment:** describe the look, not gear. No camera/film/lens model names — they get ignored or break complex moves.

**Color rule:** tie color to **material + light beam + compositional role**, never a flat list.
- ❌ "the woman wears red, the man wears blue"
- ✅ "crimson silk scarf catching the cold tungsten spill from the corridor"

**Background in layers:** state foreground / midground / background separately.

**Camera on the shadow side**, with a stated operator axis.

---

## CONTINUITY AND AUDIO LEARNINGS (Pocket FM, 2026-10-03, HSF)

- **FIRST FRAME / LOCATION MAP is written from THIS clip's actual start frame**, never copied from the master. Props change state, people move, people leave frame (say who is out of view and where they enter from). [R-E4]
- **Attach every reference to every call:** `start_image` = the start frame; one `image_references` per visible character and one for the location plate; one `audio_references` per speaker. Map each `@imageN` / `@audioN` in ACTIVE REFERENCES. [R-E14]
- **Fixed looks (e.g. cool-only):** reverse close-ups into doorways or hallways invent warm lamp bokeh. Write "every hallway light switched off; no lamps, no warm bulbs, no warm bokeh anywhere in frame" in LIGHTING. [R-H10]
- **Rain:** "No thunder." in AUDIO. [R-I5]
- **Tears:** "no tears" is ignored on child close-ups; write "dry eyes, dry cheeks". [R-H12]
- **Closing wide:** on the established master angle; a wide from a new position invents props. [R-E15]
- **Voice-over clips:** "Voice-over only: <name> in her voice @audioN … The voice is not from anyone in the room; no lips move", and "No lips move at all" in POSITIVE LOCKS. [R-I6]
- **Implied violence:** shoot past the striker's shoulder; the head turns with a single sound; the hand stays off-frame. [R-L4]
- **GPT Image masters:** natural movie-screenshot tone; no heavy film-grain or HDR / tone-mapping words. Grain wording only in the video STYLE line. [R-H11]
- These exclusion lines are the tested exception to "positive phrasing only" [R-H7].

---

## CHECKLIST (before each prompt)

- All blocks in order: context and references first, then space/timing, then action/physics, then style in its home blocks, technical-style suffix last?
- Tags named per the tagging rule (`@tag_name`, or load-order `@image1`/`@video1`/`@audio1`, or user instruction)?
- `@tag` only in shots where the object is present?
- No style-prefix block at the top — prompt opens on SCENE CONTEXT / ACTIVE REFERENCES?
- Each style aspect placed in its home block (light→LIGHTING, color→COLOR GRADE or LOCATION, acting/skin→PERFORMANCE, format/grain→STYLE+OUTPUT SETTINGS suffix)?
- Style adapted to this scene (not generic)?
- Everything positive (no "does not X")?
- Speeds in km/h, atmosphere in %/meters, giants vs human height?
- Emotion through muscle movement, not labels?
- Left/right from the camera?
- FOV in degrees from the anchor table (not mm, not arbitrary)?
- CAMERA block in 3rd position?
- Light colour in warm/cool words, NO Kelvin values anywhere?
- REALISM LAYER applied: skin line per character, required phrases ("realistic lighting ratio between key and fill", "face never overexposed, skin detail still visible in the brightest areas", "handheld stabiliser or light handheld", "real lens bokeh", "natural depth of field"), worn-material location text, STYLE opens with "Ultra-HD 4K, 30fps, cinematic realistic portrait texture"?
- Fire safety: every fire/flame/flare/glow/burn/smoke word is about the hearth or a holder only, never in a sentence with eyes or a prop; flammable props have a distance + "intact"; eyes use only "small soft warm pinpoint catch-lights, iris colour clearly visible"?
- Color via material + light + role, not a list?
- Camera on the shadow side, operator axis stated?
- Background in foreground/midground/background layers?
- Multishot: FOV per segment + "no drift mid-segment"; extreme FOV → all 4 consistency mechanisms?
- FIRST FRAME / LOCATION MAP rewritten from this clip's start frame (props, positions, who is out of frame)? Every visible face, the location plate and every speaker's voice attached and mapped?
- Fixed look guarded in LIGHTING (no warm bokeh, lamps off)? Rain: "No thunder"? Last shot on the established master angle?

---

## FINAL RULES

- **English prompts only.**
- **Positive phrasing only** — state the target, never the prohibition (except the tested exclusion lines in CONTINUITY AND AUDIO LEARNINGS, kept word for word).
- **No director names, no signature-work references, no equipment names.**
