# Scene packet — <scene> / <version>
Owner: <worker> · Approved plan: <version> · Task IDs: <ids>

## Intent and approved locks
- Source script/version and exact line IDs/text:
- Previous / start / required end story state:
- Emotional purpose and acting notes:
- Shared style/look/voice lock version:
- Master, character sheets, plate and voice reference IDs/versions:
- Timing windows; scratch cut / timing-map path:
- Output specification and generation method:

## Dependencies
- Required predecessor take/version and observed handoff packet:
- Other dependencies (props, costume, injury, time, geography):
- What may be prepared now; what must wait:
- Risk tests and approval evidence:

## Assignment
- Allowed artifact paths:
- Required output and acceptance criteria:
- Cost estimate (submission by coordinator only):
- Unverified assumptions / blockers:

Workers return findings and versioned artifacts. Do not write canonical logs,
change creative locks, mutate Resolve, or submit paid jobs independently.
