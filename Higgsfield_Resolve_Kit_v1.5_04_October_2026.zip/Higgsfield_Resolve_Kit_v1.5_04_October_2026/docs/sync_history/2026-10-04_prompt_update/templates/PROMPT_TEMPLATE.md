# Prompt skeletons (fill in from the frame and the plan; then run the prompt skill's checklist)

Fixed lines to paste as they are:
- **OPTICS:** "Real lens behaviour: real lens bokeh, natural depth of field, focus held on the eyes and the bridge of the nose in every close-up, background falling into soft round bokeh from the practical lights, gentle natural vignetting, no drift mid-segment."
- **CAMERA (operator):** "Handheld stabiliser or light handheld, at chest-to-eye height, about 1 m from the actors, like an operator on a light shoulder rig: a small constant breathing float, micro-corrections, short physical push-ins of about 20 cm."
- **Eyes:** "Living eyes: wet surface, small soft warm pinpoint catch-lights, iris colour clearly visible."
- **LIGHTING ends with:** "Realistic lighting ratio between key and fill; face never overexposed, skin detail still visible in the brightest areas."
- **STYLE:** "Ultra-HD 4K, 30fps, cinematic realistic portrait texture. Live-action period drama shot on a real set, <place and era>: photoreal people with natural, imperfect skin, real fabric weight (<fabrics>), fine organic film grain, true lens softness at the frame edges, gentle highlight roll-off, rich but natural colour."
- **Face lock:** "Faces stay stable and true to the references in every shot: same eye shape, nose, jawline. Eyes hold steady on their target."
- **Fire lock (when there are flames):** "All paper, fabric and hair stay intact; flames stay inside the hearth, lanterns and candle holders."
- **Audio lock:** "Only the spoken line and quiet room tone; no music, no breathing, gasping, sighing or sobbing sounds."

---

## A. Base clip with on-camera dialogue (omni_reference)
```
SCENE CONTEXT
<When, where, era. What happens. Exactly N people.>

ACTIVE REFERENCES
@image1: <Name>, <age>, <hair>, <costume>, <signature detail>. Voice: @audio1, <one line>. 100% matches the reference.
@image2: <Name>, … Silent in this clip. 100% matches the reference.
@image3: the <location>. 100% matches the reference.

LOCATION MAP
<Behind whom / left / right / back, from the master camera. Flammable props: distance + "intact".>
<Worn-material line: scuffs, soot, worn fabric, dust.>

FIRST FRAME / BLOCKING
<Frame one already mid-action; tight shot. Positions, hands (never at the neck), gaze.>

FORMAT MODE
Timed multishot. Cuts only at the specified points; the camera does not cut on its own. Fast pace, no pause longer than half a second between words.

OPTICS
<fixed line>

CAMERA
<fixed operator line>
0.0s to 2.0s — <29 degree … speaker; first word starts at 0.0s on a close shot>
2.0s HARD CUT
… (shots of about 2 s, never over 3 s) …

ACTION
<Speaker's lips clearly shape every word in sync. Who stays silent.>

PERFORMANCE
Never neutral: the expression shifts on every line. No wide eyes, raised brows or big mouth shapes.
<Name>: wants …, holds back …, eyes …, intensity N/10.
<Skin line per character, flaws "faint" / "subtle".>
<Eyes line>

LIGHTING
<Key source + side, warm/cool word; fill almost none; rim. No Kelvin.> <fixed-look guard if the show has one, e.g. "every hallway light switched off; no lamps, no warm bulbs, no warm bokeh anywhere in frame" [R-H10]> <fixed ending>

AUDIO
From <t>s, <Name> (@audio1), <tone>, lips synced: "<exact line>"
Only this line is spoken. <audio lock> <rain scenes: "No thunder." [R-I5]>

STYLE
<fixed STYLE>

POSITIVE LOCKS
Exactly N people, no reflections or duplicates. <face lock> <costume / prop / safety locks>
<fire lock if flames>
```

## B. Extension clip (video_extension; parent = previous job id; no audio_references)
```
SCENE CONTEXT
Continue the video straight on from its last frame. <What happens next.>

ACTIVE REFERENCES
@image1: … (character sheets only; a voice described in words if anyone speaks)

LOCATION MAP (the video's closing camera)
<Exactly what the parent's last frame shows.>

FIRST FRAME / BLOCKING
Exactly the video's last frame: <positions as visible>.

FORMAT MODE
Timed multishot … <movement = ONE continuous uncut shot>

OPTICS / CAMERA
0.0s to 0.6s — the same shot as the video's last frame, continuing seamlessly.
0.6s HARD CUT
…

(PERFORMANCE / PHYSICS / LIGHTING / AUDIO / STYLE / POSITIVE LOCKS as in A)
```

## C. GPT Image 2.5 keyframe edit or new sheet
```
Edit image 1 only as follows: <the one change>. Keep everything else identical: <each person by costume + position>, same lighting, framing and 4:3 composition. Photoreal cinematic film still, natural imperfect skin.
```
New character sheet: "Character turnaround sheet of <who>, <age>, <era-accurate costume>, front / side / back full body plus three head close-ups, neutral grey studio background, photoreal, natural imperfect skin."

## D. Narration line (seed_audio)
`prompt` = the exact line only (spell numbers out); `medias` = `audio_references` with the narrator's sample; `format: wav`, `sample_rate: 48000`; `speech_rate: +10` to fit a tight window.
