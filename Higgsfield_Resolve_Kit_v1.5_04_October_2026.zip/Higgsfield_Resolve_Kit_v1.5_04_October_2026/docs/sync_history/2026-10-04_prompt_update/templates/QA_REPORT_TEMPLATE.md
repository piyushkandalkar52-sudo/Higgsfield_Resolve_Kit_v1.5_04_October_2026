# QA — <clip/take/version>
Reviewer: · Plan/reference version: · Media path:
Verdict: approved / needs_repair / rejected

| Check | pass / fail / not applicable / unverified | Evidence and timestamp |
|---|---|---|
| Words vs exact line IDs | | |
| Lip sync through playback (motion score is supporting evidence only) | | |
| Identity, costume and intra-clip geography | | |
| Props and physical action | | |
| Incoming join / outgoing continuity | | |
| Light and image artifacts | | |
| Motion through playback | | |
| Audio intelligibility, levels, unwanted sounds | | |
| Applicable fire/prop and safety rules | | |

## Repairs
| Issue ID | Severity | Exact issue/time | Edit / regenerate proposal | Verification evidence |
|---|---|---|---|---|

Review-cut use permitted: · Final-cut use permitted:
Observed continuity handoff path:
Missing verification and next action:

No passed checkbox without evidence. Silence makes spoken-word checks not applicable,
not automatically passed. Full-cut QA additionally checks story/performance, caption
text/timing/placement, mix and delivery specification through complete playback.
