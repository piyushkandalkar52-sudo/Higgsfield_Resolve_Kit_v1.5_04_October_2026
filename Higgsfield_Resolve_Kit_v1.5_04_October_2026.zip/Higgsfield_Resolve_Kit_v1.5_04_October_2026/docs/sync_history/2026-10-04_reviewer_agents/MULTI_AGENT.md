# Multi-agent production protocol

This protocol changes coordination, not the show's creative standard. Follow `RULES.md`,
`WORKFLOW.md`, `REFERENCE.md` and the prompt skill. F3 pacing and J2 cut constraints are unchanged.
No live generation or Resolve interaction is necessary to install or review this kit.

## Four rotating roles

| Role | Primary responsibility | Rule accountability |
|---|---|---|
| Director | User decisions, approved plan, task assignment, submission, budget, canonical state, final acceptance | A, B, C, N; all gates |
| Story/continuity | Whole-script reading, emotional progression, timed coverage, asset audit, observed continuity proposals | D, E, F, G |
| Production | Prompt packages, model/mode preflight proposals, reference mapping, narration preparation, fetched job evidence when assigned | C, E, F, G, H, I, L |
| QA/editor | Independent inspection, targeted diagnostics, rolling assembly, captions, Resolve, final playback, review fixes | I, J, K, L, M |

Ownership assigns accountability, not exclusive knowledge: every role complies with every applicable
rule. All use one approved style and scene packet. The director resolves inconsistencies before
adopting outputs. The worker who wrote a prompt should not be its sole reviewer when another
worker is available. A final creative review remains necessary across the complete cut.

Use up to four actual agents, including the director. Rotate an idle worker into another bounded
role when useful. Never create extra agents just to cover a role name. The current QA/editor is
the exclusive Resolve owner; transfer that ownership explicitly with no operation in flight.
If sub-agents are unavailable, follow the role checklists sequentially and say so. Never claim
parallel execution or an independent review that did not occur.

## One versioned source of creative truth

The director publishes an approved shared packet; workers read snapshots and return proposals.
Use an assigned unique task folder (for example `work/<task-id>/`) for drafts and evidence. Do not
let several workers edit the same HANDOFF, plan, logs, packet or coordinator state. The director
alone reconciles accepted reports into canonical records. Coordinator CLI/state details and actual
supported commands are documented in `docs/COORDINATOR.md`; use that interface as documented,
not invented commands or an assumed automatic scheduler.

The shared packet contains:

- Run ID, scope, approved decision/plan version, spec, budget and continuity method.
- Complete script location and approved verbatim line IDs; story position and sequence arc.
- Character sheets, voices, acting/skin notes, costumes/day changes, signature details.
- Agreed lighting, palette, location geography, camera axis, pacing and realism/safety rules.
- Reference versions and media IDs; approved masters; risk-test coverage and evidence.

Each scene/chain packet adds start/end story state, line IDs and acting intent, timing windows,
coverage, anchor/version, dependency IDs, intended prop changes, outgoing-state requirements,
acceptance criteria and permitted task scope. Its planned endpoint is a target, not a generated
fact. A worker may flag contradictions but cannot silently change words, appearance or method.

## Dependency releases

A scene number is not proof of independence. Independent checked anchors and established states
permit parallel work. A shared evolving prop, master or preceding take can create a dependency
across scene numbers. Keep that dependency sequential.

For every dependent successor: parent completes → actual frame and clip inspected → handoff
reviewed → director releases successor → prompt finalized from that observed state → director
submits. Later coverage can be drafted during rendering, but final blocking and submission wait.
The handoff records parent take/job/version; frame path and timestamp; who is visible/out of frame;
positions, facing and eye lines; hands/props and state; costume/light; camera; unfinished motion
and audio; join risks; reviewer and evidence. The accepted parent and referenced frame must match.

On a changed reference or parent, flag affected descendants for re-review before further use.
Review actual impact; preserve verified unaffected takes. Propose repairs and obtain applicable
regeneration/spending approval before resubmission. No automatic cascade of paid regenerations.

## Useful parallel lanes

- After full-source access, story/coverage and asset audits can proceed together. Anyone making
  story judgments reads the complete script; all workers receive its position and ending.
- Once choices are fixed, production prepares prompt/reference packages while QA/editor checks
  scratch timing. Scratch work respects F3/J2; a conflict becomes a plan issue, not a silent waiver.
- After the plan and relevant risk tests pass, independent ready chains can render together.
  Narration preparation and approved audio jobs can overlap video rendering once words/windows lock.
- Review completed clips while unrelated jobs render. Assemble each approved scene as it becomes
  ready; report missing coverage before later dependent work is spent.
- Inspect independent review notes in parallel, then consolidate repairs into one editor's build.

## Tool and spending boundaries

Only the director submits paid image/video/audio jobs, including batches, fixes and tests. Workers
prepare exact request proposals and estimated cost; they do not spend. The director checks budget
against actual charges plus outstanding commitments plus proposed work, records each request/job
immediately, and reconciles unknown outcomes before retrying. This is a submission discipline;
it does not assume the generation service provides idempotency. Existing B2 stop behavior remains.

Only QA/editor runs Resolve operations, including transcription (which touches Resolve and speech
windows), project helpers, timeline builds and saves. QA/editor also serializes `shotcuts.py` because
it writes shared `02_output/data/shotcuts.json`, even for nominally separate clips. Batch requests
for these tools through that owner. Other agents may run frame, sheet or lip diagnostics to unique
assigned paths after confirming their outputs do not collide. Director alone updates canonical
review rows and approvals from the editor's returned evidence; editing media is distinct from
editing canonical production state.

## QA that answers the right question

Watch and listen to actual output. Use transcripts for spoken lines and narration; inspect unwanted
speech/audio on silent clips. Run lip-motion diagnostics for actual visible speech windows only;
mark irrelevant speech checks not applicable, with reasons. Motion scores do not prove lip sync.
For narration over faces, inspect unwanted speaking. Face/prop/light/safety and appropriate join
checks still apply to every relevant shot, including silent clips.

A review report names take/version, checked source, check coverage, verdict recommendation,
timestamped issues, evidence paths, minimal supported repair and expected dependency impact.
Unavailable playback/audio is unverified. `needs_repair` is review-cut eligibility, not final
approval. Verify each repair in the exported final cut; the existing build check alone cannot
establish that. Caption counts are supporting checks: verify exact words, order, timing and
readability in complete playback with sound. Preserve all original editing constraints and tool
limitations; do not claim a repair the current script cannot express or execute.

## Deliberate changes from the baseline

B1/E10 reuse versioned decisions only within the same approved run; new runs still confirm them.
B3 uses approved risk coverage instead of mechanically one test per scene. E1 models real
dependencies. E13 reviews affected descendants instead of automatically paying to regenerate all.
K1 interprets lip diagnostics correctly and targets them; K3 adds full playback and caption
matching. J10 separates review-cut eligibility from verified final repairs. N adds ownership,
budget commitment checks and observed handoffs. All other quality constraints remain in force.

## Prompt guidance synchronized from the original kit — 2026-10-04
The original's updated pocketfm-seedance-prompt skill is now the prompt-writing source.
Story/continuity resolves the scene change, causality, geography and inherited physical states.
Production compiles scoped references, action states, timing, audio and format checks.
QA/editor follows the learning layer's story-first review order and returns specific evidence.
Director preserves approved versions and authorizes any paid method-change experiment.
Use the updated scene packet, prompt skeletons and QA report. This update adds no agent slots
and does not weaken existing approval, continuity, budget or exclusive-editor boundaries.
