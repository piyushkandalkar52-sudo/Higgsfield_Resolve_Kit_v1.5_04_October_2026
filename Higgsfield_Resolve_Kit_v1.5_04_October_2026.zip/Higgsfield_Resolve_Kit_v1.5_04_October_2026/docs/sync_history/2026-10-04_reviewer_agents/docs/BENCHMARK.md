# Compare the original and multi-agent kits

The original kit is control A; this folder is experimental B. Never run them on
the same writable project or Resolve timeline. No paid comparison has been run yet.

## Choose what you want to learn
1. **Orchestration-only comparison:** match the approved creative plan, test set,
   footage requirements, QA criteria and generation settings. Compare sequential
   agent work against delegated work. Both may use the baseline's existing parallel
   generation capability. This isolates coordination improvements more closely.
2. **Full-workflow comparison:** run each edition as written. B includes timing,
   risk-based tests and rolling edit. Report gains as the combined workflow effect,
   not as a pure multi-agent speedup.

Record the chosen mode before starting. Begin with two comparable scenes, including
one real continuity chain and one independent branch. Give both the same source
script/version, input assets, scope, voice settings, output specification, deadline,
quality rubric and separate equal budget caps. Use the same service/model versions
where available. Do not copy generated outputs between arms unless reuse is explicitly
part of BOTH arms' design. Existing source sheets/voice samples may be shared read-only.

Create new isolated projects, for example `BENCH_A_GUIDED` and `BENCH_B_MULTIAGENT`,
with distinct Resolve project names. Never point an experiment at the original TRA
working folder. Keep generated media, prompts, manifests and logs separate.

## Procedure
1. Record input hashes, mode, expected duration, approvals, service versions, actual
   worker count, and quality criteria in BENCHMARK_REPORT.md in each project.
2. Record UTC timestamps with timezone offsets. Record start at setup, first approved
   test, first assembled scene, first reviewable cut, and final accepted cut. Include
   the early timing pass and all setup specific to the workflow.
3. Record event intervals in logs/benchmark_events.csv. Categories: production,
   user_wait, service_outage, agent_work. Multiple tasks may overlap.
4. Reconcile actual credits, including failed/rejected takes and stills/voices. Record
   agent usage/effort only if the host exposes it; otherwise write unavailable.
5. Review both anonymized cuts with the same rubric: story clarity, performance,
   continuity, identity, words/lip sync, sound, captions, technical delivery. Record
   must-fix defects and review rounds; speed is compared at the SAME acceptance bar.
6. Compute the measures below. If A ran before B, B may benefit from learning;
   disclose order. Repeat on a second matched excerpt with reversed order if useful.
   Avoid simultaneous arms when they compete for the same service quota or Resolve.

## Measures
- **Wall time:** final acceptance minus start, including all waiting.
- **Adjusted elapsed:** wall time minus the UNION of user-wait and service-outage
  intervals. Never subtract overlapping intervals twice. Generation waiting stays
  included because overlapping it is part of the benefit being tested.
- **Agent effort:** sum of measured worker active intervals; can exceed elapsed time.
- **Credit efficiency:** all charged generation credits / accepted finished minutes.
- **Time efficiency:** adjusted elapsed minutes / accepted finished minutes.
- **Rerun spend:** actual charges for failed/replaced attempts, without double-counting
  those charges again in the total.
- User interruptions, revision rounds, late continuity defects, unresolved issues.
- **Speed ratio:** A adjusted elapsed / B adjusted elapsed, only when both passed
  the same acceptance bar. Mark incomplete runs incomplete, never zero-time wins.

Do not sum phase durations to obtain elapsed time when stages overlap. Report both
raw elapsed and adjusted elapsed. A faster first preview with more late repairs is
not necessarily faster delivery. One test is a pilot, not a reliable general speed claim.
