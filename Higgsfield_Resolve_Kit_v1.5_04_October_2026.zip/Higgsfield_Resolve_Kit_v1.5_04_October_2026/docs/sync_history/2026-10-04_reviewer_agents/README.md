# Higgsfield × Resolve — Multi-agent Production Kit

A separate experimental edition of your guided kit: the same production helpers
and prompt skill, with coordinated agents, verified continuity handoffs, early
timing checks, and rolling QA/assembly. The original folder remains the baseline.

## Start
1. Open **this folder** in Claude Code or Codex with your Higgsfield access available.
2. Say: **“Start a new multi-agent project for [script]. Use four active agents at most.”**
3. The coordinator reads the kit, confirms missing decisions, prepares a timed plan,
   and asks for approval before generating anything.

Claude instructions: `CLAUDE.md`; Codex instructions: `AGENTS.md`. Native Claude
worker definitions are in `.claude/agents/`. Hosts without subagents can follow the
same workflow sequentially; no speedup is claimed for that fallback.

To compare with your current kit, say:
> Prepare an isolated A/B comparison using the same two-scene excerpt, input assets,
> output settings and quality criteria. Show the separate budgets before generating.

Follow [the comparison protocol](docs/BENCHMARK.md). Use separate project folders
and Resolve project/timeline names; do not let both kits write into your existing
TRA project. Running the comparison requires actual generation and its own approval.

## What changed
- Four rotating roles: director, story/continuity, production, QA/editor.
- Independent work overlaps; dependent clips still wait for inspected real frames.
- A timed rough cut and risk-covered tests catch expensive mistakes early.
- Same-run decisions persist; material changes and new runs still need approval.
- One writer for project state, one editor for Resolve, centralized paid submission.
- A local job/budget ledger protects against duplicate reservations and overspending.
- Full playback and verified repairs before delivery.

## Read next
| File | Purpose |
|---|---|
| [WORKFLOW.md](WORKFLOW.md) | Guided milestones, gates, overlap and outputs |
| [MULTI_AGENT.md](MULTI_AGENT.md) | Roles, task dispatch, ownership, dependencies and recovery |
| [RULES.md](RULES.md) | Retained production rules and explicit amendments |
| [docs/COORDINATOR.md](docs/COORDINATOR.md) | Local ledger CLI and its enforcement limits |
| [docs/BENCHMARK.md](docs/BENCHMARK.md) | Fair baseline vs multi-agent comparison |
| [CHANGELOG.md](CHANGELOG.md) | What changed and what was preserved |
| [VALIDATION.md](VALIDATION.md) | Checks performed; live production not yet measured |
| [REFERENCE.md](REFERENCE.md) | Inherited generation recipes and local tools |

## Requirements and limits
The production helpers were inherited from the macOS/DaVinci Resolve guided kit.
Use its setup check when starting production. Model names, API capabilities and
prices in REFERENCE are historical observations: inspect available tools and obtain
current cost preflights before spending. The inherited renderer has format and
frame-rate assumptions; validate an alternative specification before accepting it.

`tools/coordinator.py` uses Python's standard library and POSIX file locking.
It is a local ledger, not an autonomous scheduler or Higgsfield connector. The AI
coordinator dispatches agents and calls the existing connector. Its records support,
but cannot independently prove, media quality or genuine human approval.

The original illustrated PDF and HTML are retained under `docs/legacy/` as historical
guidance. They describe the old sequential workflow; the files above govern this edition.

## Local verification
```sh
python3 -m unittest discover -s tests -v
python3 tools/verify_baseline.py --snapshot PROMPT_SYNC_SHA256.json
```
The second command compares the original source folder with the saved SHA-256
snapshot; it only reads that folder. No generation or Resolve changes are made.

Prompt guidance was synchronized with the updated original kit on 2026-10-04. See CHANGELOG.md.
The original creation snapshot is retained; the verification command above uses the latest sync snapshot.
