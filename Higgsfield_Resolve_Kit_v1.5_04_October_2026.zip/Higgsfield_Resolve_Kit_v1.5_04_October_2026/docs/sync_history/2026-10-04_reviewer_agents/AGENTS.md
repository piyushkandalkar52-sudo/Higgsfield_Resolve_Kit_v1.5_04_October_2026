# Agent entry point

Read `CLAUDE.md`, `RULES.md`, `WORKFLOW.md`, `REFERENCE.md`, `MULTI_AGENT.md` and your assigned
`agents/` brief before production. Read `.claude/skills/pocketfm-seedance-prompt/SKILL.md` before
writing or reviewing prompts. These are production instructions when operating the kit; reading
or editing the kit itself does not authorize generation, spending or launching Resolve.

Follow approved run/packet versions. All roles share rule compliance. Only the director writes
canonical state and submits paid jobs. Workers use assigned unique draft/evidence paths and return
proposals. Only the assigned QA/editor operates Resolve, transcription and shared shot-cut scans.
Do not spawn extra workers merely to populate roles. Use real delegated agents only when supported
and authorized; otherwise execute the same roles sequentially and report the fallback honestly.

Read `docs/COORDINATOR.md` for supported coordinator commands and state transitions. Preserve
existing production gates, F3/J2 constraints, tool behavior and evidence requirements. Flag genuine
unresolved conflicts; honor explicit mode exceptions such as I4's ban on extension audio references.
