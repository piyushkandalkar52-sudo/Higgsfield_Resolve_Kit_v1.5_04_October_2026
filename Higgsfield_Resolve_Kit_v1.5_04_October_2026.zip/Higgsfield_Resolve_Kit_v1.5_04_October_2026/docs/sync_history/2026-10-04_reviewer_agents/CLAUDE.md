# Higgsfield × Resolve — Multi-agent Production Kit

This is the separate experimental multi-agent edition. The sibling
`higgsfield_resolve_kit_guided` is the unchanged baseline. This kit's purpose is to
reduce waiting and rework without weakening production quality or approval gates.

## 1. Start and resume
For production requests, read `RULES.md`, `WORKFLOW.md`, `MULTI_AGENT.md`, and
`REFERENCE.md`. Read `.claude/skills/pocketfm-seedance-prompt/SKILL.md` before
prompt work. For requests to inspect or edit this kit, do that maintenance task;
do not launch production, run setup, or spend credits merely because the folder is open.

Infer New project / Resume / Review / Quick test from the user's request. Ask a
short menu question only if intent is missing. Use the host's supported question
tool; `AskUserQuestion` is the Claude name, not a requirement in other hosts.
Respect the host's question limit. Never re-ask answers already supplied.

Welcome:
```
HIGGSFIELD × RESOLVE · MULTI-AGENT EDITION
One director · shared creative locks · independent work in parallel
Script → timed plan → approved tests → rolling production + QA + edit → delivery
No generation until the plan and spending are approved.
```

On resume, read CURRENT RUN then `logs/production_manifest.json` and the rest of
HANDOFF. Reconcile pending AND uncertain remote submissions before dispatch.
The manifest owns task/dependency/budget state; HANDOFF is the coordinator-maintained
human summary. No worker may independently resume or re-submit a job.

## 2. Run the dependency-driven workflow
Steps are milestones, not a global barrier between every activity. After the
relevant gates pass, overlap generation, QA, audio preparation, and rolling edit
as described in WORKFLOW. Do not waive plan, spending, reference, or test gates.

Use the available host's real subagent mechanism. With four active slots, the
coordinator counts as one and at most three workers run at once. Load role briefs
from `agents/`; Claude agent definitions are in `.claude/agents/`. Rotate workers
according to the bottleneck. If delegation is unavailable, use the same roles
sequentially and record actual concurrency = 1. Never claim imagined agents worked.

The coordinator owns user communication, approved creative intent, canonical
manifest/logs/HANDOFF, reference registration and all paid submissions. Workers
write only their assigned versioned task artifacts. The editor alone runs tools
that mutate Resolve, the EDL, shared shotcuts JSON or shared speech windows.
See `docs/COORDINATOR.md` for the local ledger commands. It does not spawn agents,
call Higgsfield, validate media, or replace human approval.

Show a compact tracker at milestone changes, for example:
`Plan v1 approved | A2 rendering | B1 QA | edit v1 assembling | next gate: tests`
Report useful changes during waits, including settled + committed credits vs cap.
Only the coordinator asks questions. Bundle independent decisions; existing
approval remains valid for the same run/version. New runs and material changes
need the applicable approvals. Routine delegation needs no additional approval.

## 3. Report evidence, not checklist theatre
For each reviewed take report:
```
Clip / take version — accepted / needs repair / rejected
Checks performed: words … | lip sync … | identity … | joins … | sound …
Not applicable / unverified checks: …
Evidence: media and timestamped QA report paths
Repair obligation: …; outgoing continuity usable: yes/no, evidence …
Spend: settled N + committed N / cap N
Next: ready task or user decision actually required
```
Do not mark lip sync passed from lip-motion statistics alone. Do not mark motion
or audio passed from a contact sheet. `needs_repair` is review-cut eligibility,
not final acceptance. Keep repairs tracked until verified in the delivered cut.

At delivery give paths, versions, checked criteria, timestamped accepted issues,
credits including failed takes, wall time, active time, approval waiting and agent
effort if available. Never invent unavailable usage data. Use `docs/BENCHMARK.md`.

## 4. Commands
- `status`: ready/blocked/running/uncertain tasks, actual + committed spend, next gate.
- `next`: dispatch eligible work; explain a blocking gate if no work is ready.
- `pause`: stop new submissions, record running/uncertain jobs and resumable ownership.
- `back to step N`: preserve artifacts, assess invalidation, revisit that milestone.
- `cost`: reconcile transactions and outstanding reservations.
- `compare`: prepare or report the isolated baseline/experimental benchmark.
- `help` / `rules`: summarize the workflow or relevant rules.

## 5. Hard boundaries
No paid generation without recorded user approval for scope/spec/budget/continuity
and plan; test/reference and review-round gates still apply. No double submissions.
Stop on a credit limit or 429 under retained R-B2. No credentials in project files.
Never delete attempts. Build new versioned timelines only. No concurrent edits to
shared Resolve or canonical state. Do not reuse the baseline project's writable
folder or timeline for the experimental benchmark.

`RULES.md` defines production constraints; `MULTI_AGENT.md` defines ownership;
`WORKFLOW.md` defines gates. Known amendments in this edition are documented in
`CHANGELOG.md`; the copied prompt skill's generic voice-reference language is
subject to the explicit extension exception R-I4. For genuinely unresolved
creative conflicts, propose a resolution to the user; do not repeatedly ask
about already-documented exceptions.
