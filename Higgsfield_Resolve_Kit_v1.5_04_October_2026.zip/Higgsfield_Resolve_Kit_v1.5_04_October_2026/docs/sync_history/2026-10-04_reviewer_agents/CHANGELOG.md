# Multi-agent edition — 2026-10-04

Derived from `higgsfield_resolve_kit_guided`. `BASELINE_SHA256.json` records every
source file's SHA-256 at copy time. The source folder was not edited.

## Preserved
- Original production executables and render/edit/QA scripts, except the project
  initializer enhanced for isolated multi-agent bookkeeping.
- Prompt skill and PROMPT_TEMPLATE, including realism and fire/prop guidance.
- Verbatim dialogue, character/voice locks, inspected continuity, review evidence,
  explicit paid-generation approvals and new versioned timelines.
- Existing pacing/edit heuristics and renderer constraints. This experiment does
  not silently trade away quality or loosen the edit lint to appear faster.
- Original guide PDF/HTML/images, moved into docs/legacy as historical reference.

## Changed
- Milestone gates replace a global one-step-at-a-time barrier; ready independent
  work overlaps while approvals and true dependencies remain binding.
- Four rotating roles with shared context, bounded worker output, and one editor.
- Same-run approved decisions persist; new scope/version changes are reconciled.
- Separate specification fields, early scratch timing, risk-covered approved tests.
- Single-owner canonical project state; local budget reservations and job ledger.
- Actual outgoing continuity packets, versioned evidence, descendant invalidation.
- Rolling assembly, full playback QA, and explicit repair verification at delivery.
- New templates, role briefs, Claude worker definitions, Codex entry point, and
  an isolated A/B comparison protocol.

See RULES and MULTI_AGENT for exact amended rules. Ledger automation is intentionally
limited: it does not call external services, spawn workers or verify human consent.
Do not confuse local unit tests with proof of a production speed or quality gain.

## Prompt guidance sync — 2026-10-04 (after initial kit creation)
Imported the updated upstream prompt skill byte-for-byte, including its conditional 48-lesson
PRODUCTION LEARNING LAYER and provisional evidence status. Merged only the upstream RULES
H introduction and H7 exclusion/repair refinement; retained all multi-agent amendments.
Updated prompt skeletons, scene/QA packets, production brief and pre-submit workflow to use
reference roles, causality, world/body/screen geography, hand/prop states, two-pass timing,
audio contracts, image/edit structures and evidence-based repair. Coordination code unchanged.
The original creation snapshot remains in BASELINE_SHA256.json. The newer read-only upstream
snapshot and import hashes are in PROMPT_SYNC_SHA256.json. The original has evolved since
creation; an old-snapshot difference is expected and is not evidence this sync modified it.
