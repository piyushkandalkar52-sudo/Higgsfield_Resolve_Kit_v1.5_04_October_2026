# Local production coordinator ledger

`tools/coordinator.py` is a standard-library Python 3 ledger for one production run in a project. It does not dispatch agents, call generation services, inspect media, establish pricing, or operate Resolve. The producer/coordinator is its sole intended writer. Workers submit proposals and review evidence to that coordinator.

The authoritative file is `<project>/logs/production_manifest.json`. A separate `flock` lock serializes read-modify-write operations, and an fsynced temporary file plus atomic replacement protects each update. Keep this ledger on a local filesystem supporting these operations; it is not a distributed lock service. Do not edit the JSON directly or delete its lock file during a run.

Initialize after the user has chosen scope and a credit cap. The `approve` command records an actual approval already obtained from the user: it cannot obtain or verify consent itself. Never invent approval evidence. Reference approvals, test-to-production release, creative exceptions, and review-round regeneration approval still require the workflow's manual gates. The approved plan version should identify the exact reviewed plan, preferably by immutable filename or content digest.

## Commands

Run from the kit directory. All examples below are illustrations; replace example values with real approved values. Credit values must be finite, nonnegative decimals.

```sh
python3 tools/coordinator.py --project /absolute/project init --run-id EP02_RUN01 --cap 100
python3 tools/coordinator.py --project /absolute/project approve --plan-version PLAN_v1 --approved-by 'User name' --evidence 'Actual approval message reference'
python3 tools/coordinator.py --project /absolute/project add --task-id SC01_A_v1 --plan-version PLAN_v1 --kind video
python3 tools/coordinator.py --project /absolute/project add --task-id SC02_A_v1 --plan-version PLAN_v1 --kind video
python3 tools/coordinator.py --project /absolute/project add --task-id SC01_B_v1 --plan-version PLAN_v1 --kind video --continuity-parent SC01_A_v1
python3 tools/coordinator.py --project /absolute/project ready
python3 tools/coordinator.py --project /absolute/project reserve --task-id SC01_A_v1 --cost 18
```

`add` also supports `--depends TASK_A TASK_B`. A continuity parent is automatically included among dependencies. Dependencies must already exist; self-dependencies and forward references are refused. IDs and kinds are immutable. Plan versions and dependencies change only through the explicit reviewed `revalidate` operation described below. Use a new ID for a retry or revised take. Each run has one ledger: initialization is idempotent for the same run ID and cap and refuses to overwrite another run. A new run currently requires a separate project/run directory; no automatic reset or cap increase exists.

`ready` returns planned, non-invalidated tasks under the currently approved plan whose dependencies have accepted QA. For a continuity dependency, the parent must also have a recorded observed handoff. A handoff is text or a packet path; the CLI does not inspect that packet or validate its contents. The continuity lead must inspect the generated media and packet before the coordinator records acceptance. Accepted media may feed dependent work before its invoice is settled; its reservation remains counted until settlement.

`reserve` atomically verifies readiness and that actual charges plus outstanding reservations plus the new estimate fit the cap. Obtain an accurate full-cost preflight externally first. Repeating the same reservation is idempotent; a changed cost is rejected. Reserved tasks disappear from `ready`. Before submitting externally, the coordinator must check that its task remains non-invalidated and the intended request matches the reservation. The CLI is not an external submission mutex: workers must never submit directly or treat a repeated reserve call as a new submission instruction.

Immediately record the actual job ID returned by the external submission:

```sh
python3 tools/coordinator.py --project /absolute/project submitted --task-id SC01_A_v1 --job-id ACTUAL_REMOTE_ID
```

The same ID for the same task is idempotent. Reusing a job ID on another task is rejected. Record a returned job even if inputs became stale after submission; financial obligations must not disappear.

If the external request outcome is unknown, retain its reservation:

```sh
python3 tools/coordinator.py --project /absolute/project unknown --task-id SC01_A_v1
```

Do not retry the external call until reconciled. After querying the provider, use `submitted` with the recovered job ID, or cancel only when evidence confirms no remote job and no charge:

```sh
python3 tools/coordinator.py --project /absolute/project cancel --task-id SC01_A_v1 --evidence 'Provider reconciliation reference proving no job and no charge'
```

Cancellation releases the reservation and permanently closes that task ID. It also supports a planned task or a reserved request confirmed never submitted. For an actual failed or charged remote job, record `submitted`, then its charge and QA rejection; do not use cancellation.

Record settled charges independently of output QA:

```sh
python3 tools/coordinator.py --project /absolute/project settle --task-id SC01_A_v1 --actual 18
python3 tools/coordinator.py --project /absolute/project accept --task-id SC01_A_v1 --evidence 'Review report path and reviewer' --handoff 'Observed final-frame packet path'
```

`settle` requires a known submitted job, stores the actual charge, and clears its reservation. Settlement says nothing about generation success, QA, or deliverability. A charge exceeding its estimate is recorded rather than rejected; a negative available balance blocks new reservations. Repeating the same settlement is idempotent. Invoice corrections/refunds are not implemented; do not mutate the manifest to fabricate them.

For a failed output:

```sh
python3 tools/coordinator.py --project /absolute/project reject --task-id SC01_A_v1 --evidence 'Review report with failure evidence'
```

`accept` and `reject` can run before or after settlement, require a known remote job and evidence, and set an immutable QA verdict. Include the observed handoff at acceptance if another clip will depend on its continuity. A missing handoff blocks continuity children; to correct the same accepted take, invalidate it and explicitly revalidate with fresh evidence and the observed handoff. Descendants remain invalidated until each is reviewed. This ledger tracks generation tasks, not scratch planning or editing tasks that produce no remote job.

When an approved upstream asset, blocking decision, or take is no longer valid:

```sh
python3 tools/coordinator.py --project /absolute/project invalidate --task-id SC01_A_v1 --reason 'Reference changed; actual change reference'
```

This invalidates the task and all graph descendants. It preserves historical QA and all charges/reservations: an invalidated request may already have been submitted. Settle known jobs; reconcile unknown ones; cancel confirmed unsubmitted reservations. Create new IDs for newly generated replacement tasks. Preserve an unaffected existing accepted take only after explicit re-review:

```sh
python3 tools/coordinator.py --project /absolute/project revalidate --task-id SC01_B_v1 --plan-version PLAN_v2 --depends SC01_A_v2 --continuity-parent SC01_A_v2 --evidence 'Fresh independent review and seam-check report' --handoff 'Fresh observed continuity packet path'
```

`revalidate` requires a historically accepted, currently invalidated take and the currently approved plan version. It preserves the same remote job, actual charge, reservation, and submission state; it never submits or charges again. This is an audited exception to immutable dependency bindings: `--depends` replaces the dependency list (an empty list clears ordinary dependencies), and `--continuity-parent` replaces the continuity parent. Omitted fields retain their previous values. A retained or replacement continuity parent is always included in dependencies. All dependencies must exist, be accepted and non-invalidated; continuity parents must have a recorded handoff. A full graph cycle check protects rebinding to later-created tasks. Fresh handoff evidence is required when the take already had a handoff or has a continuity parent.

Revalidation never revives rejected or pending outputs and never automatically revalidates descendants. Review each dependent take separately. To add a missing handoff or correct an accepted record, invalidate that take first, then revalidate it with fresh review evidence and the corrected handoff; this intentionally invalidates its descendants for review. New generation retries always receive new task IDs, while verified existing output uses its original ID and remote job. Historical event records preserve the original acceptance and subsequent review.

Approving a different plan blocks old-version tasks from reservation and acceptance. It does not relabel historical accepted takes or automatically invalidate their descendants. Before accepting the changed plan, the continuity lead must identify affected tasks and explicitly invalidate them. Approved, unchanged historical assets can still be dependencies of a task in the new plan. A plan change is refused while any request is in the reserved state; reconcile, submit, or cancel those first.

```sh
python3 tools/coordinator.py --project /absolute/project status
```

Status returns the full manifest and totals. On resume, reconcile submitted/unknown tasks before authorizing retries, inspect invalidated reservations, and then read `ready`. No job polling, lease recovery, or automatic dispatch occurs. A reservation with no recorded remote ID after a crash must be treated as potentially submitted until checked externally.

## Audit and verification

Each mutation records its UTC timestamp, command, and supplied arguments in the manifest's append-only event list. Failed checks and idempotent no-ops add no events. This is operational history, not a tamper-proof audit log. Never put secrets in evidence strings.

Run the fake-data tests without generation services or spending:

```sh
python3 -m unittest discover -s tests -v
```

Tests cover two-process budget contention, reservation/job deduplication, immutable task IDs, dependencies and observed handoffs, settlement versus QA, unknown outcome reconciliation, resume, cancellation evidence, transitive invalidation, cycle prevention, plan changes, actual overruns, numeric input validation, reviewed dependency rebinding, preserved financial obligations, and rejection of invalid revalidation.

For a speed comparison, manually record baseline and multi-agent run start/end timestamps, accepted output seconds, settled cost, failed-take cost, and reviewer time in a CSV. Manifest events can support generation-phase timing, but they do not measure complete agent effort or provide a fair benchmark by themselves.
