# Visual evidence gate

The visual reviewer follows docs/VISUAL_REVIEW.md and the user's preserved source.
The read-only helper combines one full review or several specialist reviews. It checks
coverage and version binding, not pixels, truthfulness, skill, human consent or final QA.
Never treat a zero exit code as permission to generate the next clip by itself.

1. Director freezes the asset and a scene packet. Packet includes exact script/scene version,
   approved direction, immutable reference paths and SHA-256 values, selected prior asset,
   required wides, audio mode, crop and authorized exceptions. Verify those source hashes
   before review/release; packet hashing alone cannot detect a referenced file changing in place.
2. Copy templates/VISUAL_REVIEW_REQUEST_TEMPLATE.json into work/<review-id>/. Fill exact
   identifiers, absolute paths and SHA-256 values computed from actual file bytes.
3. Each assigned reviewer copies VISUAL_REVIEW_RESULT_TEMPLATE.json, binds to that request,
   and replaces its placeholders with checks actually performed. Reviewers return only their
   assigned R1–R9 checks. Collectively all nine must be covered or explicitly not applicable.
   Do not prefill PASS. Image checks use whole composition; video checks require actual playback
   plus actual opening and closing portions. Required wides cannot be marked absent merely to
   pass a gate. Missing mandatory media evidence is NEEDS REVIEW.
4. Lead collects reports for the exact same asset and packet. Run:

```sh
python3 tools/review_gate.py /absolute/request.json /absolute/reviewer1.json /absolute/reviewer2.json
```

Exit 0 = visual evidence PASS; exit 2 = REPAIR or NEEDS REVIEW/invalid input. No files
are changed. Director can save stdout to the assigned report path. Missing checks, stale hashes,
duplicate IDs, conflicting judgments and missing playback/image coverage fail closed.
If reviewers disagree, inspect the disputed evidence and produce one new consolidated report
with reasons and links to the preserved originals; do not discard the unfavorable report to pass.

Check IDs correspond to the user's numbered rules:
R1 whole-scene setup; R2 film-like moment; R3 blocking/readability; R4 scene look;
R5 photographic realism; R6 opening/closing wides; R7 physical/emotional continuity;
R8 action/performance; R9 reference conflicts and narrow repair.

Status is PASS, REPAIR, NEEDS REVIEW or NOT APPLICABLE. Every check needs a reason;
all except NOT APPLICABLE need evidence strings naming actual observations, paths or timestamps.
NOT APPLICABLE needs a scene/method-specific reason (for example temporal action in a static
costume sheet). Keep source setup/context checks when they do apply to an image. The operator
must examine these reasons: the helper cannot know whether an N/A claim is justified.
Coverage flags must be actual booleans and must truthfully describe what was inspected.

## Existing workflow mapping
- PASS: a visual recommendation. Director still checks user selection, master/test gates,
  audio, relevant diagnostics, remaining repair obligations and observed continuity handoff.
  Then it may record QA approval/ledger acceptance under the existing workflow.
- REPAIR: block dependent release if material. Director records needs_repair for a usable review
  take or rejected for an unusable take; never ledger-accept an unsafe continuity parent.
- NEEDS REVIEW: hold the affected branch and record the unresolved check in work/HANDOFF.
  Do not invent a fourth qa_index.csv verdict or label it approved. Continue unrelated work.

The source permits one targeted repair then one changed approach per issue episode, subject to
existing spend approval. Track attempts across agents so rotation does not reset the limit.
After that, escalate. The helper is not a retry counter or paid-job submitter.
