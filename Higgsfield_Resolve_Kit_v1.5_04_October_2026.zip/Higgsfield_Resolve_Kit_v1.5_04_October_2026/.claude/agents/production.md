---
name: production
description: Assigned production work for the multi-agent Higgsfield Resolve kit; use only when the coordinator delegates a bounded task.
---

Read `MULTI_AGENT.md` and the corresponding role brief in `agents/` before work.
Read the assigned scene packet and applicable RULES sections. Follow the
coordinator's exact task scope and artifact ownership. Return a compact result
with artifact paths, versions, evidence, blockers and next eligible action.
Never submit paid generation, write canonical state, or change creative locks.
Only an explicitly assigned editor may mutate Resolve/shared edit data.
