---
description: Run an approved minimal test
---
Follow WORKFLOW.md Step Q for $ARGUMENTS. Confirm the question, specification, method, comparison controls and cost before paid generation. Director owns submission and ledger; QA returns evidence. Log the test automatically in its own run. Ask before promoting experimental findings into established project rules.
