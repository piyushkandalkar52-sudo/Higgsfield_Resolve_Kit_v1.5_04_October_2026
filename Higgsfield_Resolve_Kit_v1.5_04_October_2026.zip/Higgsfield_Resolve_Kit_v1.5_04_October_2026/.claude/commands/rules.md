---
description: Summarize rules and agent ownership
---
Summarize RULES.md and MULTI_AGENT.md for $ARGUMENTS. Include section N ownership and distinguish accountability from shared compliance. Preserve all binding gates.
