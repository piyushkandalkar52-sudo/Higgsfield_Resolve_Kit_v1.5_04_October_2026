---
description: Start the multi-agent workflow (new project or resume)
---
Read CLAUDE.md and MULTI_AGENT.md. Follow WORKFLOW.md for $ARGUMENTS.

For a new project, begin with WORKFLOW Step 0 automatically, without asking: run the setup
check, verify the company Higgsfield workspace with `list_workspaces`, and record `balance`.
Only then ask for the script and missing decisions. If the user gave a script or file in
$ARGUMENTS, use it; otherwise ask for it once.

Infer the requested path instead of repeating known choices. Delegate real bounded tasks when
available; preserve all approval gates. For comparison use isolated projects and docs/BENCHMARK.md.
