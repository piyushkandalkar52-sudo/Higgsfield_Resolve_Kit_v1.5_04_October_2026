---
description: Apply a versioned review round
---
Follow WORKFLOW.md Step 11 for $ARGUMENTS. Agents may inspect independent notes concurrently. Consolidate one repair table, prefer edit fixes, and ask before new paid regeneration with cost. Single editor rebuilds a new version. Invalidate affected descendants before further use and verify repairs in the exported cut.
