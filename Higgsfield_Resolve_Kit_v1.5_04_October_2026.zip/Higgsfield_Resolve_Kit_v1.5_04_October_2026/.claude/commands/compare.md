---
description: Prepare an isolated A/B workflow comparison
---
Follow docs/BENCHMARK.md for $ARGUMENTS. Select orchestration-only or full-workflow comparison. Use separate folders/Resolve projects and equal approved acceptance criteria. Do not spend until each arm has an approved plan and budget. Record elapsed time, waiting, actual costs, agent effort if available and quality outcomes; do not claim measured speed before both runs finish.
