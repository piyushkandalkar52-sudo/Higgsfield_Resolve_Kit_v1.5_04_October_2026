---
description: Resume the same versioned multi-agent run
---
For $ARGUMENTS, read CURRENT RUN, the production manifest, HANDOFF and docs/COORDINATOR.md. The coordinator alone reconciles pending/unknown jobs, outstanding reservations, task ownership and stale dependencies before dispatch. Preserve same-run approved choices. Do not initialize over an existing ledger or resubmit uncertain work. Reconcile QA rows and show ready tasks plus the next gate.
