---
description: Report multi-agent tasks and actual plus committed spending
---
Read active HANDOFF and run coordinator status per docs/COORDINATOR.md. Report ready/blocked/running/unknown jobs, owner, settled + reserved vs cap, next action and approval gate. Reconcile remote state through supported tools; never invent tool arguments or imply the local ledger polls remote jobs.
