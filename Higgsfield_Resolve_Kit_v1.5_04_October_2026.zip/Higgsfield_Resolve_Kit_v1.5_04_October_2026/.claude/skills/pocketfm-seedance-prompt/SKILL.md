---
name: pocketfm-seedance-prompt
description: How to write every Seedance 2.5 / Higgsfield video prompt in this kit — block structure, timed multishot, FOV table, the REALISM LAYER (skin lines, physical lighting with no Kelvin, required phrases, "Ultra-HD 4K, 30fps" quality cues) the fire/candle/prop safety rules, the extension-prompt recipe, and the PRODUCTION LEARNING LAYER (48 lessons from real Higgsfield + GPT production: scene first, one job per reference, world/body/screen geography, prop and hand states, performance, two-pass timing, audio contract, preflight, review and repair). Use before writing, revising or reviewing any video, keyframe or narration prompt in this kit.
---


# Seedance prompt writer (Pocket FM kit)

> Extension clips: see REFERENCE.md §3 and templates/PROMPT_TEMPLATE.md §B (start with "Continue the video straight on from its last frame", a 0.6 s continuation segment, no audio_references).

Turn scripts, scenes, and ideas into Seedance 2.0 prompts. Block, light, and pace each shot like a film.

**Output: always a single standalone prompt in a code block** — in the format the request or integration needs (prose, or JSON when required), complete and directly usable (L09, L10).

---

## CORE PRINCIPLE: WRITE THE VISIBLE

The model reacts to what can be **seen and measured**, not to mood words.

Translate every abstraction into something observable.
- ❌ "tense scene" → ✅ "man freezes, slowly clenches his fist, light only from the side, half his face in shadow"
- ❌ "cool cinematic shot of a car, epic, fast" → ✅ "low tracking shot alongside the car as it powers through a wet curve, headlights glowing, spray off the tyres, hard buffeting camera shake"

Write in plain, clear, instruction-style language. Fewer precise words beat many vague ones.

Before generating, mentally "watch" the prompt as a viewer: is everything unambiguous, is the first frame non-empty, is it clear where the subject is and where it looks, where is the light coming from.

---

## WORKFLOW

1. **Resolve the scene first** (PRODUCTION LEARNING LAYER §A): the one-sentence change, the causal chain, the start state inherited from the last accepted clip, what is protected and what may change.
2. **Read as a director.** Find the dramatic shape: where the scene turns, lands, breathes.
3. **Bind the references** (§B): one job, its exclusions and its shots per reference; resolve conflicting inputs before writing preservation words.
4. **Define continuity anchors** (§C, §D): world/body/screen positions, what is behind each subject per camera, prop states, hand budget.
5. **Write the prompt** using the block structure below, with the audio contract (§H) and light (§I).
6. **Preflight** (§G, §J): two timing passes, tags, format, length, contradictions. Then deliver the complete prompt.

If the idea is ambiguous, close the gaps in conversation first — blocking, angle, light, timing, character behavior, what is in the first frame, how it ends. The model fills any gap on its own, usually not the way intended.

---

## PRODUCTION LEARNING LAYER (Sai's Higgsfield + GPT learning, imported 2026-10-04)

**Source (bundled in this kit):** `learning/prompt_pack/` (40-lesson prompt pack) and `learning/production_handbook/`: 48 lessons, a 447-paragraph learning manual from 27 production chats (HSF, IMTS, TRA, TDMB, DP, HIH) and an archive of 98 real Seedance 2.5 prompts. Lesson IDs (L01–L48), manual paragraphs (D00nnn) and archive prompts (Annn) refer to that handbook.

**How to read it:**
- These are **conditional** lessons: apply one when its condition fits.
- One scene's preference or one successful repair is not a universal rule. Example: the 8-second hug in HSF is right for that aftermath, not for every ending.
- The lessons are derived from real corrections but have **not yet been tested on a new scene**.
- The archive's SUCCESS labels mean the job finished, not that the result was approved: 96 of the 98 say SUCCESS, and none of the renders were reviewed.
- Where this layer and an older rule in this skill disagree, the refined wording below is the current rule. The REALISM LAYER still governs skin, light and quality wording.

**The core finding (D00004):** a prompt succeeds when the scene itself has been resolved first. That means knowing:
- what changes emotionally;
- where everyone stands;
- what causes each action;
- which reference controls each feature;
- how much time the action needs.

More adjectives cannot repair an impossible camera position, a contradictory reference or a rushed exchange.

### A. Resolve the scene before writing (L01, L02, L11, L14, L15, L17, L19, L20)
- **Write one sentence: the change.** What the audience understands or feels at the end that it didn't at the start. Keep that change in every revision. If the brief has no dramatic intention, flag it; don't invent one (L01).
- **Write the causal sentence before the shots** (D00047): "Because the receptionist recognises her, her grip loosens." If the sentence reads "then an attractive insert happens", the shot is decoration: cut it.
- **Inner feelings become visible behaviour plus a trigger** (L02). Power can be someone who keeps working while another person waits; no added speech is needed.
- **Start from the last accepted state, not the top of the script paragraph** (L17, D00052).
  - Never repeat a completed action: a handshake already done, a door already open, a character already standing.
  - When the script's literal action contradicts the current frame, keep its dramatic purpose and adapt the action. "Leaps up" becomes "straightens" if she is already standing. Record the adaptation so it isn't reintroduced later.
- **Scope every correction** (L11). Record what changes, what is protected and where it applies. A new-lighting request keeps the architecture. A blocking reference doesn't dictate the lens. A local fix is never a redesign.
- **Keep source facts separate from adaptation** (L14). Track four things apart: the script's facts, the user-approved adaptation (a new city, a casting direction), your own interpretation and the approved assets. When the setting changes, update every local detail that depends on it (climate, architecture, school scale, cars, props); changing the city name alone leaves stale details.
- **Protect who knows what** (L15). A shot, face, line or symbol must not reveal a secret before its approved reveal point. Clarify the event while keeping the identity hidden; for example, an empty chairman's chair stands in for the unseen chairman.
- **Choose the grammar of time for montage and age progression** (L19). Pick one: one continuous event, separate moments, compressed years or a continuous transformation. Vary the activity and the feeling, and change costume, age and props to match the passage of time.
- **The set must support the action** (L20, L06).
  - Doors, windows and routes must work for the entrances and escapes the scene needs.
  - Social position shows through function, maintenance, scale and privacy: poor but clean, wealthy with purpose. Random grime or random gold doesn't do it.

### B. References: one clear job each (L23, L24, L35, L36, L37; A024, A080, A096)
- **For every reference, state:**
  - what it controls (identity, costume, environment, blocking, composition, lighting, continuity state, voice);
  - what it must **not** control;
  - **which shots** it applies to.

  Proven wording from the archive:
  - "Use @Image 2 STRICTLY to preserve character positions, blocking, screen direction and room geography. Do NOT copy its camera angle, framing, lens or shot composition." (A080)
  - "@Image 6 is a CAMERA/COMPOSITION REFERENCE ONLY for the FINAL INTERIOR SHOT. DO NOT use @Image 6 for Shots 1–6." (A096)
  - "@Image 4 controls ALL HALLWAY SHOTS ONLY."
- **Continuity from a previous video.** A previous approved clip can serve as a continuity reference for identity, costume, seating, props, light and axis while the new clip **opens on a new angle** (A024: "Use @Video 1 ONLY as continuity reference for …; do NOT begin on its exact final frame or camera angle").
  - This is a different method from start-frame chaining, where the clip opens **on** the start frame [R-E5].
  - Choose one method per clip and say which.
- **No invented tags** (D00098). If an outfit or prop image isn't uploaded to this generation, describe the garment in words and remove its tag. Never reference a tag that isn't attached.
- **Fix conflicting inputs at the source** (L24, D00102). If a reference visibly shows what the prompt forbids, correct or replace the reference, then retry. Example: the character sheet shows a shoulder strap while the bag must stay on the desk. More preservation words will not override the image.
- **Keep identity, outfit, pose, expression and style separate** (L35).
  - An outfit reference supplies clothes, not its fashion pose.
  - A softer expression must not make an adult look like a child.
  - If the identity reference smiles and the brief wants that smile, keep it; don't flatten it to neutral.
  - Check face, age, body, expression, pose, clothing and style one by one.
- **Offer genuinely different options** (L07). When presenting alternatives (a costume, a set, a master), vary the structure (silhouette, construction, layout, circulation, materials, dramatic function), not only the colour. Once one is chosen, refine it without reopening the concept.
- **Split a design that keeps drifting** (L36). Design the mask, accessory or costume as its own asset, choose it, then fit it to the approved base. Change one dimension per test.
- **Composites must match the room** (L37): scale, perspective, light direction, softness, focus, grain, occlusion and contact shadows.

### C. Geography: world, body and screen are three different things (L25, L26; D00111–D00124)
- **Place the action against stable architecture first** ("from the café entrance, behind her seated body, to the opposite chair"). Then give the anatomical side (her left hand) separately from the screen position (frame left).
  - A front-facing person's left is on the viewer's right.
  - After a camera reverse, "behind her" in the room may not be "behind her" on screen.
  - The refined rule: screen left/right is from the camera, **and** each instruction says which of the three it means.
- **Fixed sides stated as body sides survive camera changes**: "the window is ALWAYS on her RIGHT and his LEFT" (A080).
- **The background follows the camera.** For every angle, say what is really behind each subject from that camera position. A camera inside a building looking out cannot have that building's façade behind the people it looks at. Write the opposite side positively instead (the plaza, a low fountain, bare trees).
- **The floor-plan test** (D00117). You should be able to sketch the room from the prompt: doors, windows, furniture, actors, movement path, camera positions. If no sketch satisfies every clause, the prompt is not ready.
- **When a camera move breaks the geography, reduce the travel.** Get variety from lens, height and short same-side moves rather than a big arc (D00116).
- **Point of view (D00119–D00121):**
  - Literal POV puts the camera at the observer's eyes.
  - Over-the-shoulder includes part of the observer.
  - An object viewpoint puts the camera among objects for composition.
  - If POV keeps producing an unwanted look (e.g. binoculars), switch to a third-person view of the same discovery.

### D. Physical action, props and hands (L16, L27, L28; D00085, D00130–D00141)
- **Break every compound action into valid states:** preparation → contact → movement → release → result.
  - "Gets into the taxi" means: door open, correct side, lower the body, turn forward, settle, then close the door.
  - "Serves coffee" means: approach, place, release, withdraw.
  - These mechanics decide meaning: a child placed in a carriage by force must look different from one who climbs in.
- **Props are persistent objects.** Track owner, count, position, orientation, contact and permitted state changes.
  - A hidden prop keeps its state.
  - An allowed change is shown happening: the cup is lifted, sipped from and returned.
  - Write the inherited prop state into each clip: broken porcelain "remains visible on the floor for the rest of the sequence; the cup does not reappear" (A009).
  - Check props before they are hidden, during contact, when they reappear and at the end.
- **Budget the hands.**
  - Assign each hand before staging the camera.
  - A busy hand has to release something before it does a new task: put the bags down before a two-handed rescue; raise the phone before speaking into it.
  - Check that head turns and body facing are anatomically possible.
- **Thresholds have one clear sequence:** approach → reach → handle → open → cross → release or close → settle. The door's position is fixed; its open or closed state changes, and you state that state in every shot (A096). If time is short, start closer to the door; don't compress the steps.
- **Removing a condition also removes the actions that need it** (L34). If you take the snow out of an interior, also replace "wipes snow from his hair" (for example, a hand smoothing dry hair).

### E. Performance (L03, L04, L18; D00143–D00154, D00372)
- **Direct a change, not a permanent mood.** Write the emotional path with its trigger: "she notices she's recognised, her grip relaxes, then she answers." "Nervous throughout" flattens the scene.
- **Use one or two dominant visible cues per beat:** eye focus, breath, jaw, posture, grip, movement speed. A different micro-gesture on every word makes the acting mechanical.
- **Keep similar emotions distinct; the user corrected these repeatedly:**
  - relief is not a smile;
  - a forced reassuring smile is not ease;
  - admiration is not constant staring;
  - amusement is not gloating;
  - "innocent" never means child anatomy on an adult;
  - "powerful but not frozen", "poor but maintained", "warm in feeling while cool in light".
- **Intensity comes from the event** (L04). Forced separation, an escape or open cruelty may need active, strong performance. A negotiation needs controlled resolve. The strength of an action and the intensity of a face are two separate controls: a decisive folder slam can come with a controlled face.
  - The refined default: restraint for ordinary dialogue, and the event's stakes set the level. Subtle shock [R-G3] still applies to shock beats.
- **Choose reactions by meaning** (L18). Show the face whose understanding changes. The listener on a revelation is fine, if the scene's speaker-visibility rule allows the speaker to be off-screen. The kit's default is that dialogue is lip-synced on camera unless the script puts it off-screen.

### F. Camera and coverage earn their place (L05, L08, L13, L21, L22, L38; D00088, D00126–D00127, D00223–D00228)
- **Every move has a function:**
  - a push-in concentrates;
  - a lateral move reveals relationships and depth;
  - tracking follows a path that matters;
  - an orbit celebrates an arrival or shows a change;
  - a rack focus moves attention between things already in frame.
- The user rejected constant push-ins, arbitrary reverses and motion that blurred a simple beat.
- **Pick the fewest shots that make the event and the change readable.** Inserts must reveal a fact, mark a change or support continuity. A fast confrontation and one sustained hug can both be right; choose by what the audience needs to see.
- **"More cinematic" or "more emotional" is a diagnosis, not "more cuts"** (L13). Work out what's missing (emphasis, scale, energy, intimacy, foreground depth, a revealing reaction), name it, and fix that. Faster editing is not faster physical movement.
- **Openings carry one dramatic question** (L21). Make the consequential event readable quickly ("Will the family help the sisters?"), carry the question through the next beats, and let the response matter. Different hooks suit different scenes; there is no compulsory fast-cut template.
- **Motifs develop meaning** (L22). A repeated prop, threshold or window should change meaning over the story. Don't add a symbolic prop the script never established without approval.
- **Crop safety through the action** (L38). If one master must also serve 9:16 or square crops, keep faces, hands, contact and key props inside the shared safe area at the opening, the action peak and the end. Use diagonal depth rather than a lineup. Check the real crop: a safe first frame can fail when an arm reaches out.
- **Leave room for the feeling to land** (L08). When the action is complete but the payoff hasn't registered, give the aftermath its own time, or its own continuation clip. Don't add another plot beat. The ending must be a readable state that can be held and connects to the next clip; a half-second containing a nod, a smirk and a settle is not usable.

### G. Timing: two separate passes (L29; D00156–D00159)
- **Pass 1, arithmetic.** The shot windows are contiguous, with no gaps or overlaps, and add up to the declared duration. In the archive, 25 of 98 prompts declared one length but listed shots totalling another.
- **Pass 2, feasibility.** Can each line be spoken naturally inside its window, alongside the physical action around it? A 4-second line in a 4.1-second shot leaves no time to unlock and raise a phone. Pre-position the prop, move the action earlier, lengthen the shot or split the beat.
- A voice sample's length is not the line's length. Time the line itself. For a fixed dialogue track, use its measured length.
- Reserve a final hold that can be cut on (see F).

### H. The audio contract for THIS clip (L30; D00160–D00163; A024, A063, A096)
- **Declare the mode:**
  - silent visual (for external narration);
  - exact supplied dialogue;
  - a voice sample setting the identity only;
  - speech only;
  - speech plus named sounds.

  The kit default is the spoken lines plus room tone; one archive prompt used speech only with no ambience. Choose per clip and say it.
- **Map every voice tag to exactly one speaker and purpose**, and list each speaker's exact lines ("TOMAS SPEAKS ONLY: …"). Add "non-speaking characters stay silent and do not mouth words."
- **A voice sample controls the voice's identity and tone only.** State accent and delivery separately, e.g. "@Audio 1 controls voice identity and tonal quality only; the final line is in refined natural British English; do not reproduce any non-British accent in @Audio 1" (A096). Give each line a short delivery note (A009).
- **Narration inside a clip:** "voice-over only; neither character mouths the narration."
- **A silent insert under external narration must not generate its own narration** (A063: no dialogue, no narration, no voice-over).
- **Don't write contradictory bans** (D00163):
  - "no audio" next to required dialogue;
  - "no lip-sync" that also forbids silent breathing or eating;
  - "no text" without an exception for a required phone message on screen.

### I. Light, exposure and weather (L33, L34; D00184–D00191)
- **Describe the light source and direction separately from brightness, material colour and grade.** Cold overcast light can still leave faces well exposed; "cool" must not mean dark. Warm wood, gold or burgundy can stay warm as materials under cool light.
- **Don't keep an unwanted warm reference light while asking for new neutral daylight.** Pick one. If relighting edits keep failing, decide openly between continuing a bounded edit and a fresh image, which brings its own risk to architecture and identity.
- **Weather is scoped to the environment.** Snow outside doesn't mean snow on the indoor table or hair. Show winter through the glass, through coats, and through breath where it's cold.
- Colour temperature numbers are creative wording, not physical control. No Kelvin values [R-H2].

### J. Compile and preflight the prompt itself (L09, L10, L31, L32, L45; D00296–D00301; A011–A018)
- **Deliver exactly what was asked:** a prompt request gets a prompt, not an image. Match the count, the format (prose, or JSON if the integration needs it) and the scope.
- **For a correction, return the complete revised prompt** with the change kept as small as the request allows. Unrelated choices must not drift.
- **Keep the integration's boundaries:** fixed generation segments, exact tag spelling and punctuation, units and character limits. "Under 2,500 words" is not "under 14,000 characters".
  - Resolution and frame rate belong in the tool settings, not the prose. The kit's quality-cue line in STYLE remains as wording.
  - Historical limits in old prompts are not current settings: read them from the active tool (`models_explore`).
- **Selective repetition.** Write stable facts once, globally. Repeat only the fragile fact at the shot where it can drift: the doorway side at the crossing, the bag state where the bag is visible, the speaker at each line. Pasting the whole face and costume inventory into every shot adds noise and breaks length limits.
- **Compact video structure** (D00297), mapped onto this skill's blocks:
  - the tool and the title;
  - duration and aspect;
  - exact references with their roles (ACTIVE REFERENCES);
  - one global continuity statement;
  - the action and its emotional purpose;
  - the audio contract;
  - timed shots, each with framing, camera position or move, visible action, emotional change and its fragile continuity fact;
  - the ending state;
  - targeted negatives.
- **Image prompts** (D00300):
  - A new image covers its purpose, reference roles, identity, pose, composition, environment, light, materials and props, aspect, and relevant exclusions. Never put a video timeline in a character canvas.
  - An edit names the base image and the single change, describes the replacement precisely, lists the protected elements, and says what counts as correct.
  - Unseen geometry is designed, not "recovered exactly".
- **Small fixes to a finished clip — the video edit mode the archive used** ("Seedance 2.5 Edit", A011–A018).
  - It takes short, direct instructions on @Video 1: "in @Video 1 move the book slightly to the left, to the edge of the table; keep everything else the same"; "match the cold cloudy colour tone of @Image 1 with @Video 1; keep everything else the same as in @Video 1".
  - The pattern: one change, plus "keep everything else the same".
  - The archive's SUCCESS means only that the job finished. Confirm the current mode name and settings with `models_explore` before relying on it.
  - Consider it before regenerating a whole clip for a prop, count or colour fault.
- **Mechanical preflight before submitting** (L45):
  - valid JSON when JSON is required (e.g. `4.5 seconds` unquoted is invalid);
  - every tag attached and spelled exactly;
  - no empty or misspelled tags;
  - the character limit;
  - the output count;
  - the shot arithmetic (G);
  - no contradictory audio rules (H);
  - no completed action repeated (A);
  - no reference used outside its shots (B).

### K. Review and repair (L39–L44, L46; D00229–D00241, D00369–D00370)
- **Review story before polish** (L40). **Review in this order:** story meaning → causal action and geography → identity, costume, props → performance → timing → audio → text and crop → visual polish. Rate each as pass / needs repair / unclear. A story or continuity failure can't be averaged away by beautiful lighting.
- **Keep the technical status separate from creative approval** (L39). A finished job can still have wrong acting. An approval belongs to a specific result, element or time interval: "everything good except the book" approves the rest, and doesn't prove the later book fix worked (L46). Record the exact qualification and the rollback target.
- **Diagnose specifically** (L41). Classify the failure: story, reference, geography, action, performance, timing, appearance, audio, text or format. Record the frame or interval. Keep the observation ("an extra laptop appeared") separate from the hypothesis ("the phrase 'laptop-style bag' caused it").
- **The repair ladder** (D00234):
  1. Restate the desired state exactly.
  2. Remove contradictory clauses.
  3. Reduce simultaneous motion, or isolate the hard beat.
  4. Replace the conflicting reference, make a new master, or split the asset.
  5. Change the shot method while keeping the dramatic intention.
- **Repair the smallest failing part** (L42). List the protected elements first. Example: when reducing too many paintings, keep the room's wear, books and furniture; the earlier over-cleaned version was rejected.
- **Change method after a repeated failure** (L43). When the same defect comes back after two wording changes, adding another prohibition is not a new test. Change the cause instead: a contradiction, too many simultaneous actions, the wrong reference or the wrong shot type.
- **Be honest about tool failures** (L44). Record the actual error. Don't present a guessed keyword or filter workaround as a proven fix. Restage difficult events truthfully: a reaction shot, the action off-screen, or a cut before the impact.
- **Follow the selected version, not the newest one** (L12, L47). A rollback is a correction too. The handoff records the active scene, the last accepted state, current tags, jobs still running, pending corrections, paused work, deprecated assets and the exact next action. In this kit, that's the CURRENT RUN box [R-A7] and the review list [R-K4].
- **When adding a lesson to this skill** (L48), store its condition, the intervention, the protected elements, the evidence and its status. Test it on a different scene before calling it general.

---

## ASSET TAGGING

Reference image (`@tag`) sets **appearance and identity** by default. Text sets **what happens** and locks critical details. Both are required. When a reference is used for anything narrower or different (blocking only, composition only, one location, later shots only, voice identity only), say so explicitly: what it controls, what it must not control and which shots use it (§B).

**Tag naming:**
- If the user specifies tags as `@tag_name`, use those.
- If no tags are specified, name them by load order of the supplied assets: `@image1 @image2 ...` for images, `@video1 @video2 ...` for videos, `@audio1 @audio2 ...` for audio.
- Otherwise follow the user's explicit instruction.

**Reference + text rule:** keep the character description minimal — long appearance text conflicts with the image and degrades it.

```
@TAG: age + role/build + current state + unique visible features + action-critical details + voice (only if it has a line). 100% matches the reference.
```

State critical details (small text, logos, color) in words even if they appear on the reference — the model can drop them.

Never place an `@tag` in a shot where that object is not present; the model will try to force it into frame.

---

## CONTEXT ISOLATION

Each generation is a blank slate — **no memory of previous shots.** A prompt is a sealed single-shot document.

Do not carry in: scene numbers, script headings, summaries of prior scenes, unused tags/characters, "as above / continues" phrasing, or people and props from a previous line that are not needed in this shot.

Do carry in, written as present facts: the physical and emotional state the previous accepted clip ended on (who stands where, what is already done, prop states). "The handshake has already finished; their hands are apart" is a fact for this shot, not a reference to another prompt (§A, L17).

---

## STYLE — DISTRIBUTED, NOT A PREFIX

There is **no separate style-prefix block at the top of the prompt.** Style is not one thing in one place — it is a set of aspects, and each aspect lives in the block that already governs it, where it is most effective and unambiguous. State the target look, never what to avoid; adapt every line to this specific scene.

Cover these aspects, each in its home block:

| Aspect | Lives in | What to write |
|--------|----------|---------------|
| Lighting | **LIGHTING** | source, direction, exposure, key/fill, haze for THIS scene |
| Color / grade | **COLOR GRADE** (own block if grade is strong, e.g. teal-cyan desaturated) or folded into **LOCATION** + **LIGHTING** for a naturalistic look | palette as material + light beam + role, never a flat list |
| Lens / optical character | **OPTICS** | FOV°, rectilinear/anamorphic, prime-lens character, motion-blur |
| Camera body / tonal character | **CAMERA** | tonal latitude, highlight roll-off, color science — as a look, not a model name |
| Skin / micro-realism | **PERFORMANCE** (or inside **ACTION**) | pore-level realism, capillary flush, living eyes, catch-lights, visible breath |
| Acting | **PERFORMANCE** (or inside **ACTION**) | micro-pauses, precise eye-line, restraint, muscle-level emotion |
| Physics realism | **PHYSICS** | gravity, inertia, mass, contact shadows, fluids, particles |
| Composition / blocking | **FIRST FRAME / BLOCKING** | framing rule for THIS scene; everyone moving from frame one |
| Continuity | **POSITIVE LOCKS** | characters, props, environment identical across cuts |
| Wardrobe | **WARDROBE** (own block when costume matters) | material + condition, scene-logical |
| Format / resolution / grain / fps / bitrate | **STYLE** + **OUTPUT SETTINGS** at the **end**, just before LOCKS | STYLE opens with "Ultra-HD 4K, 30fps, cinematic realistic portrait texture" (see REALISM LAYER), then photoreal, fine grain, real-time vs slow-mo per segment |

**Placement principle:** descriptive style (light, color, optics, physics, acting) sits *inside the content block it describes*, in the body of the prompt. Technical/format style (resolution, grain, fps, bitrate, overall look reference) sits as a **suffix stack at the end** (`STYLE`, `OUTPUT SETTINGS`), right before `POSITIVE LOCKS`. Nothing style-related goes at the very top — the prompt still opens on `SCENE CONTEXT` and `ACTIVE REFERENCES`.

Use only the aspects the shot needs. A naturalistic single take may have no `COLOR GRADE`, `WARDROBE`, or `OUTPUT SETTINGS` block at all and fold those notes into LIGHTING and POSITIVE LOCKS. A graded, multi-segment piece earns the full suffix stack.

If the user supplies their own prefix or block text, use it verbatim.

---

## PROMPT STRUCTURE

Write blocks in this order. Logic: context and references first, then space and timing, then action and physics, then the descriptive-style blocks in their home positions, and a technical-style suffix at the end. Use only the blocks the shot needs; drop the rest.

```
SCENE CONTEXT
[1–2 sentences: what happens, where, when. Geo-positions of characters.]

ACTIVE REFERENCES
[@tag + minimal anchor of critical details + "100% matches the reference"]

LOCATION MAP
[Foreground / midground / background, where the camera is, where light comes from, movement paths. Naturalistic color can live here.]

FIRST FRAME / BLOCKING
[Who is where in the first frame: positions, orientation, gaze. Composition rule for this scene.]

FORMAT MODE
[Choose the level of control the shot needs:
 - Single continuous shot — "one continuous shot, the camera does not cut on its own."
 - Sequence of cuts, no timecodes — "CUT 1 … CUT 2 … CUT 3", described in order.
 - Timed multishot — explicit HARD CUTs at stated seconds.]

OPTICS
[Shot size + FOV per segment + lens/optical character. For multishot add "no drift mid-segment".]

CAMERA
[Operator behavior: height, distance, movement, focus. Camera-body tonal character as a look.]

ACTION
[Events at the precision the shot needs. Camera motion and subject motion stated separately.]

PERFORMANCE        (when acting matters)
[Acting + skin/micro-realism: muscle-level emotion, eye-line, catch-lights, breath, pore-level detail.]

PHYSICS
[Mass, inertia, contact, fluids, particles.]

LIGHTING
[Source, direction, exposure, warm/cool words (no Kelvin values) — priority block. Realism layer phrases required.]

COLOR GRADE        (when the grade is strong / stylized)
[Palette as material + light + role; grade character. Omit for naturalistic looks — fold color into LOCATION/LIGHTING.]

WARDROBE           (when costume matters)
[Material + condition, scene-logical.]

AUDIO
[The audio contract for THIS clip (§H): mode (silent / speech only / speech + named sounds), each voice tag mapped to one speaker with that speaker's exact lines, delivery notes, who stays silent.]

STYLE              (technical-style suffix)
[Opens with "Ultra-HD 4K, 30fps, cinematic realistic portrait texture." Then the overall look in words, photoreal, grain — no director or equipment names.]

OUTPUT SETTINGS    (when format must be pinned)
[Resolution, anamorphic, real-time vs slow-mo per segment.]

POSITIVE LOCKS
[Short fixers against likely failures, in positive form, restating critical info once. Continuity lives here.]
```

The descriptive-style blocks (PERFORMANCE, PHYSICS, LIGHTING, COLOR GRADE, WARDROBE) sit in the body next to what they govern. The technical-style blocks (STYLE, OUTPUT SETTINGS) form a short suffix stack just before POSITIVE LOCKS. Nothing style-related opens the prompt.

A **lock** is a short hard fixer placed next to what it protects, e.g. `"headlights stay glowing in every shot"`. Write densely where control matters, sparsely where it does not. Say each important thing once, clearly.

---

## CUTS AND TIMING

Pick the precision the shot actually needs — these are points on a scale, not a binary:

- **Single shot (oner)** → "one continuous shot, the camera does not cut on its own."
- **Sequential cuts, no timecodes** → describe shots in order as `CUT 1 … CUT 2 … CUT 3`. Use when you want specific cuts but exact timing does not matter.
- **Timed multishot** → explicit HARD CUTs at stated seconds. Use when beats must land on a clock.
- **Freestyle b-roll** → do not lock cuts; let the model find angles.

When you specify cuts (timed or not), lock that the camera does not add its own: *"cuts only at the specified points, the camera does not cut on its own."*

**Timecode format** (only when timing matters):
```
0.0s to 1.0s — [description]
1.0s HARD CUT
1.0s to 3.0s — [description]
```

**Sequential format** (cuts without timecodes):
```
CUT 1 — [description]
CUT 2 — [description]
```

**Cut types:** `HARD CUT`, `SMASH CUT`, `MATCH CUT`, `INSERT CUT`, `REVERSE CUT`, `WHIP CUT`. Fades / crossfades only if explicitly requested.

Across internal cuts hold: same character set, same geometry, screen direction, gaze, light, wardrobe, prop state.

---

## DIRECTING

**Blocking.** State where each character stands, sits, moves; what their hands do; what sits between them. "She sits across from him at the diner booth, knees touching under the table" beats "they sit and talk."

**Pace.** Read the dramatic structure. Confession scene → air, held shots, beats of silence. Action → compression, short cuts. A reveal lands on one held close-up.

**Acting.** Translate emotion into concrete on-shot direction:
- ❌ "she looks sad" → ✅ "her eyes drop to the table, jaw tightens, she swallows once before answering"
- ❌ "he is angry" → ✅ "knuckles whiten on the glass, breath shortens, eyes never leave hers"

Restraint by default for ordinary dialogue — a whisper out-acts a shout most of the time. But the event's stakes set the intensity: forced separation, escape or open cruelty may need strong, active performance; keep the strength of an action separate from facial intensity (§E, L04).

**Continuity** (hold in mind, do not write as a block): state carried forward (wet/dry/bloodied), appearance not drifting, emotional carry from the previous scene, one time-of-day and weather unless the location changes.

**Camera language.** Be concrete: FOV°, height, movement, motivation. Motivate every camera move.
- "Low-angle 18° dolly-in, slow push from waist to chest as she realizes."
- "Static 47° two-shot, eye-level, locked off — lets the silence sit."
- "Handheld 63°, follow from behind — camera lags half a beat."

---

## PROMPTING RULES

- **Positive by default.** Describe what should happen, not what to avoid. ❌ "does not fall backward" → ✅ "stays upright, feet planted." Exceptions: a **targeted** exclusion for a specific, observed or highly likely failure ("the handshake has already finished — no second handshake"; "@Image 6 does not influence Shots 1–6") and the tested exclusion lines in this skill. Never grow an ever-longer negative list: after a defect survives two wording changes, change the method instead (§K, L43).
- **Speeds in km/h.** ❌ "fast/slow" → ✅ "moves at 40 km/h", "camera pans at 5 km/h."
- **Atmosphere in percent / meters.** ❌ "light fog" → ✅ "fog density 40%", "haze visible at 15 meters depth."
- **Atmosphere builds in steps across shots.** Shot 1: fog 20% → Shot 2: 40% → Shot 3: 60%.
- **Giant scale via human-height comparison.** ❌ "huge", "three meters tall" → ✅ "stands as tall as four humans stacked head to toe."
- **Left/right is from the camera** (screen direction) — and say which of the three you mean. Place the action in the room first (world), give anatomical sides separately (body), and screen left/right last. Fixed sides written as body sides ("the window is always on her RIGHT") survive camera reverses (§C, L25).
- **Environment interaction stated physically.** Snow melts on skin, rain runs down hair, wind moves fabric.
- **Emotion through muscle movement, not labels.**

---

## REALISM LAYER (Pocket FM, learned 2026-10-01, TRA realism test)

Apply to EVERY prompt. Wording only: it needs no extra references or resolution; the regular workflow (480p, 4:3, character sheets + location plate + voice sample, start/end keyframes) stays the same. Where this layer conflicts with a rule above, this layer wins.

### Core idea

The model renders the words literally. Realism comes from naming *specific
physical flaws and physical light behaviour*, not from words like "realistic",
"cinematic" or "beautiful". Every word placed next to a face, an eye or a prop
can show up on it.

---

### 1. Skin block (biggest single gain)

In PERFORMANCE, add one `Skin:` line per on-screen character. List concrete,
small flaws matched to age, sex and the light of the scene. Write it once per
character per show (next to the acting sheet) and reuse it.

- Men: visible pores across nose and cheeks, stubble pores at the beard line,
  faint weathered lines at the eye corners, slight oily sheen on forehead and
  nose, a few loose hairs, (optional) one small old scar.
- Women: period make-up that is light and not flawless, a little powder settled
  in fine lines, visible pores on nose and cheeks, faint marks of old blemishes,
  fine lines under the eyes, natural redness at the nostrils, lip texture with
  tiny vertical lines and a little moisture, real lashes, loose strands escaping
  the hairstyle.
- Children: smooth but real skin, faint flush on cheeks, small dry patch or
  scratch, flyaway hair. Never adult lines.
- Eyes, all: "living eyes: wet surface, small soft pinpoint catch-lights, iris
  colour clearly visible". (See the fire-safety rules, 7: never "fire" or "flame" near eyes.)

Never use beauty words: flawless, perfect skin, glowing, porcelain, stunning,
gorgeous, beautiful face, high-end face. They pull towards plastic AI skin.

### 2. Lighting as physics

Write the LIGHTING block as a light plan: each source with a direction and a
warm/cool word. **Never write colour temperatures (no Kelvin values such as
2200K or 6500K)**, in any block.

- **Key:** one named source, side stated from camera ("warm fire and candle
  light from camera-right, falling on the side of each face toward the
  fireplace").
- **Fill:** "almost none; the far side of each face falls into shadow with
  detail still visible."
- **Rim / background:** a second, contrasting source ("cool moonlight from the
  window, a thin edge on hair and shoulders").
- **Required phrases (always include, word for word):** "realistic lighting
  ratio between key and fill" and "face never overexposed, skin detail still
  visible in the brightest areas".
- **Behaviour:** "flame flicker moves the key level gently on skin and walls".

Every light must have a visible, logical source in the room.

### 3. Optics

"Real lens behaviour: real lens bokeh, natural depth of field, focus held on the
eyes and the bridge of the nose in every close-up, background falling into soft
round bokeh from the practical lights, gentle natural vignetting, no drift
mid-segment."
"Real lens bokeh" and "natural depth of field" are required, word for word.

### 4. Camera as an operator

"Handheld stabiliser or light handheld, at chest-to-eye height, about 1 m from
the actors, like an operator on a light shoulder rig: a small constant breathing float, micro-corrections,
tiny focus breathing on push-ins. Pushes are short and physical (about 20 cm)."
"Handheld stabiliser or light handheld" is required, word for word. For calm
scenes add "on a gimbal with a slight breathing float".

### 5. Location text: worn materials

Even with the location plate attached, describe the set in words with wear and
use: wax-polished but scuffed panelling, soot on the mantel, velvet nap worn
shiny, fringe hanging unevenly, dull pitted metal, worn rug, dust in the air.
The plate gives the layout; the words take the glossy concept-art finish off it.

Optional stronger fix: rework each location plate once (GPT Image edit) into "a
photograph of a real period set, worn surfaces, lit only by its practical
lights", so the reference itself passes on realism instead of gloss.

### 6. STYLE line and locks

STYLE always opens with the quality-cue tokens, then the look:
"Ultra-HD 4K, 30fps, cinematic realistic portrait texture. Live-action period
drama shot on a real set: photoreal people with natural, imperfect skin, real
fabric weight (velvet nap, linen creases, lace with loose threads), fine organic
film grain, true lens softness at the frame edges, gentle highlight roll-off,
rich but natural colour."

The quality cues ("Ultra-HD 4K, 30fps, cinematic realistic portrait texture")
do not change the output resolution or frame rate; those stay as parameters
(480p/720p/1080p, fixed fps). They are kept on purpose: they push the model
toward finer detail and a higher-quality render. Always include them; never
remove them as "redundant".

POSITIVE LOCKS add: "Faces stay stable and true to the references in every
shot: same eye shape, nose, jawline. Eyes hold steady on their target; lips
move only for the spoken words."

---

### 7. Fire, candle and light-source safety (mandatory)

Two failures from the test that must never repeat:

| Failure | Wording that caused it | Rule |
|---|---|---|
| Flames visible inside Amelia's eyes | "small fire catch-lights", "her catch-lights grow" during a fire flare | Never put fire, flame, flare, blaze, burning or glow words in the same sentence as eyes, irises or pupils. |
| The contract on the table caught fire | parchment "beside a guttering tallow candle, a curl of smoke rising from the wick" | Never place a flammable prop "beside" a flame, and never use guttering / smoke / sparks / embers near a prop. |

Required wording:

- **Eyes:** "small soft warm pinpoint catch-lights, iris colour clearly visible."
  That is the only light wording allowed for eyes.
- **Flames stay in their holders:** "the fire burns steady inside the stone
  hearth", "each candle flame stays small and steady in its holder".
- **Flammable props** (paper, parchment, letters, contracts, cloth, curtains,
  hair, sleeves, veils, flowers): state the distance and state that they are
  intact. "The parchment contract lies flat and intact on the table, about 30 cm
  from the nearest candle; its red wax seal unbroken." Repeat in POSITIVE
  LOCKS: "All paper, fabric and hair stay intact; flames stay inside the hearth
  and candle holders."
- **Inserts of a prop:** frame the prop itself and keep candles out of the
  insert, or "a steady candle out of focus 30 cm behind it". Never a smoking or
  guttering wick in a prop insert.
- **Light events** (a log shifts, a door opens, lightning): put the event on the
  source and on skin/walls only: "the flames in the hearth rise for half a
  second; the warm light on the side of her face brightens, then settles".
  Never "flare" near the eyes or near a prop.
- **Banned words anywhere near faces or props:** guttering, smoke, smoking,
  sparks, embers, ignite, flare (outside the hearth sentence), blaze, burning
  (except "the fire burns steady inside the hearth"), fiery, fire in her eyes,
  eyes glowing.
- Same rule for other sources: torches, lanterns, lamps, braziers, lightning,
  the sun through glass. The source stays in its place; eyes get pinpoint
  catch-lights only; props are stated intact.

---

### QA on the result

Before accepting a clip: step through every close-up and check the eyes for reflected flames, and every prop insert for fire, smoke or scorch marks. If found, fix the wording per the fire-safety rules and regenerate; do not stitch over it.

---

## OPTICS — SHOT SIZE, LENS, FOV

Two levers define "how it is shot": **shot size** and **focal length**.

### Shot sizes
| Abbr | Meaning | In frame |
|------|---------|----------|
| ECU | Extreme Close-Up | a detail: eyes, button, headlight, hand |
| CU | Close-Up | full face / one element large |
| MCU | Medium Close-Up | head and shoulders |
| MS | Medium Shot | roughly to the waist |
| WS | Wide Shot | full figure + surroundings |
| EWS | Extreme Wide | scale, location |

### Focal length (mm — for describing size while writing, not for the prompt text)
| Lens | Effect | Use for |
|------|--------|---------|
| 24–35mm wide | space, slight perspective distortion | action, immersion, wides |
| 50mm normal | natural perspective, "as the eye sees" | realism, neutral shots |
| 85mm portrait | soft bokeh, subject separated from background | portrait, emotion |
| 135mm+ tele | strong compression, "watching from afar" | observation, distance, sport |

In the prompt text use **FOV in degrees** from the table below, not millimeters.

### FOV anchor table (degrees for the prompt)
| FOV | mm equiv | Purpose | When |
|-----|----------|---------|------|
| 180° | Fisheye | spherical distortion | POV, dream-state |
| 107° | 14–16mm | architectural ultra-wide | huge interiors, epic establish |
| 84° | 20–24mm | wide | establish, group blocking |
| 63° | 28–35mm | observational | wide observation, reportage |
| 47° | 40–50mm | neutral human perspective | universal establish, medium |
| 29° | 75–85mm | portrait compression | medium-isolate, dialogue bust |
| 18° | 100–135mm | natural portrait | close-portrait, identity-preserving |
| 12° | 180–200mm | tele-detail | hands, objects, detail-on-wide |
| 8° | 300–400mm | extreme compression | observation, broadcast |

Use only the discrete steps from the table. Not "23°" — use 18° or 29°. In a multishot, set FOV per segment and add `"no drift mid-segment"`.

### Camera placement in the prompt
Place the CAMERA block in the **3rd position** of the prompt's core layers (subject → action → camera → style → constraints). Moved to the end, FOV gets ignored; moved to the front, it conflicts with identity.

---

## OPTICAL TECHNIQUES

**Observation pattern (hidden-camera effect)** — all three ingredients at once:
1. Foreground occlusion — out-of-focus obstruction over 20–30% of frame (wall, pillar, branch, arch).
2. Atmospheric haze — fog/dust/shimmer between camera and subject.
3. Distance vantage — super-tele 8°–12°, operator anchored far away.
Change the occlusion type between beats; keep the vantage single.

**Sports broadcast:** `8° super-tele + handheld 1–2cm tremor + "anchored at distance, finding the action"`.

**Detail-on-wide (snake cam):** `84° wide FOV + low-angle right up against a small object` — foreground object exaggerated, background recedes into depth.

**Intimate wide:** `63–84° wide FOV on a close face` — face centered, surroundings readable without blur.

**Tele compressed air column** at 8°–12°: `"dust suspended in the long compressed air column between camera and subject"`, `"heat shimmer compressed into a wall of haze in front of the figure"`.

---

## SPECIAL PROTOCOLS

**4-mechanism multishot consistency stack (extreme FOV: 8°, 107°):**
1. Sequence-wide identity lock — single location reference across all beats.
2. LENS LOCK opener — explicit FOV phrase at the start of each beat.
3. LENS CHECK closer — confirm FOV at the end of the beat.
4. Color via material + light, not as a list.
All four are required, or extreme-FOV multishots break down after 2–3 beats.

**Whip-pan timing:**
```
0.3s — Subject A settled
0.8s — WHIP motion-blur transition
1.4s — Subject B settled
```
A whip under 0.8s renders as a hard cut without blur.

**Mixed time-speed (real-time + slow-mo):** hard cuts only between speed modes. Each shot is one speed start to finish.

**Cracks/breaks without impact (anti-impact lock):**
- "crowd PRESSES, not strikes"
- "fracture originates from edge stress, not center impact"
- "no impact point — pressure-based crack"
- sequential timing edge-to-center, not radial from a point.

---

## CAMERA / LIGHT / COLOR

**Colour of light** in plain warm/cool words tied to the source ("warm candle light", "cool moonlight"), fixed within a scene. **Never write Kelvin / colour-temperature values.**

**Equipment:** describe the look, not gear. No camera/film/lens model names — they get ignored or break complex moves.

**Color rule:** tie color to **material + light beam + compositional role**, never a flat list.
- ❌ "the woman wears red, the man wears blue"
- ✅ "crimson silk scarf catching the cold tungsten spill from the corridor"

**Background in layers:** state foreground / midground / background separately.

**Camera on the shadow side**, with a stated operator axis.

---

## CONTINUITY AND AUDIO LEARNINGS (Pocket FM, 2026-10-03, HSF)

- **FIRST FRAME / LOCATION MAP is written from THIS clip's actual start frame**, never copied from the master. Props change state, people move, people leave frame (say who is out of view and where they enter from). [R-E4]
- **Attach every reference to every call:** `start_image` = the start frame; one `image_references` per visible character and one for the location plate; one `audio_references` per speaker. Map each `@imageN` / `@audioN` in ACTIVE REFERENCES. [R-E14]
- **Fixed looks (e.g. cool-only):** reverse close-ups into doorways or hallways invent warm lamp bokeh. Write "every hallway light switched off; no lamps, no warm bulbs, no warm bokeh anywhere in frame" in LIGHTING. [R-H10]
- **Rain:** "No thunder." in AUDIO. [R-I5]
- **Tears:** "no tears" is ignored on child close-ups; write "dry eyes, dry cheeks". [R-H12]
- **Closing wide:** on the established master angle; a wide from a new position invents props. [R-E15]
- **Voice-over clips:** "Voice-over only: <name> in her voice @audioN … The voice is not from anyone in the room; no lips move", and "No lips move at all" in POSITIVE LOCKS. [R-I6]
- **Implied violence:** shoot past the striker's shoulder; the head turns with a single sound; the hand stays off-frame. [R-L4]
- **GPT Image masters:** natural movie-screenshot tone; no heavy film-grain or HDR / tone-mapping words. Grain wording only in the video STYLE line. [R-H11]
- These exclusion lines are the tested exception to "positive phrasing only" [R-H7].

---

## CHECKLIST (before each prompt)

- All blocks in order: context and references first, then space/timing, then action/physics, then style in its home blocks, technical-style suffix last?
- Tags named per the tagging rule (`@tag_name`, or load-order `@image1`/`@video1`/`@audio1`, or user instruction)?
- `@tag` only in shots where the object is present?
- No style-prefix block at the top — prompt opens on SCENE CONTEXT / ACTIVE REFERENCES?
- Each style aspect placed in its home block (light→LIGHTING, color→COLOR GRADE or LOCATION, acting/skin→PERFORMANCE, format/grain→STYLE+OUTPUT SETTINGS suffix)?
- Style adapted to this scene (not generic)?
- Everything positive (no "does not X")?
- Speeds in km/h, atmosphere in %/meters, giants vs human height?
- Emotion through muscle movement, not labels?
- Left/right from the camera?
- FOV in degrees from the anchor table (not mm, not arbitrary)?
- CAMERA block in 3rd position?
- Light colour in warm/cool words, NO Kelvin values anywhere?
- REALISM LAYER applied: skin line per character, required phrases ("realistic lighting ratio between key and fill", "face never overexposed, skin detail still visible in the brightest areas", "handheld stabiliser or light handheld", "real lens bokeh", "natural depth of field"), worn-material location text, STYLE opens with "Ultra-HD 4K, 30fps, cinematic realistic portrait texture"?
- Fire safety: every fire/flame/flare/glow/burn/smoke word is about the hearth or a holder only, never in a sentence with eyes or a prop; flammable props have a distance + "intact"; eyes use only "small soft warm pinpoint catch-lights, iris colour clearly visible"?
- Color via material + light + role, not a list?
- Camera on the shadow side, operator axis stated?
- Background in foreground/midground/background layers?
- Multishot: FOV per segment + "no drift mid-segment"; extreme FOV → all 4 consistency mechanisms?
- **Learning layer:** the scene's one-sentence change and the causal chain written; start state taken from the last accepted clip (nothing already done is repeated); protected elements and allowed changes listed (§A)?
- Every reference has one job, its exclusions and its shots; no tag that isn't attached; conflicting references fixed at the source (§B)?
- Each position says world / body / screen; what is behind each subject is true for that camera; a floor plan could satisfy every clause (§C)?
- Compound actions broken into states; props tracked through occlusion with their state; each hand budgeted (§D)?
- One or two visible cues per beat; intensity set by the event; reactions on whoever's understanding changes (§E)?
- Every camera move has a function; fewest shots that make the change readable; a holdable ending (§F)?
- Two timing passes: windows add up AND each line plus its action fits naturally (§G)?
- Audio contract: mode, each voice tag to one speaker with exact lines, accent/delivery separate from the voice sample, no contradictory bans (§H)?
- Light source separate from exposure and material colour; weather scoped to its environment; no action implies a removed condition (§I)?
- Mechanical preflight: requested format and count, valid JSON if JSON, tags exact, length limit, settings in tool controls (§J)?
- FIRST FRAME / LOCATION MAP rewritten from this clip's start frame (props, positions, who is out of frame)? Every visible face, the location plate and every speaker's voice attached and mapped?
- Fixed look guarded in LIGHTING (no warm bokeh, lamps off)? Rain: "No thunder"? Last shot on the established master angle?

---

## FINAL RULES

- **English prompts only.**
- **Positive phrasing by default** — state the target; use only targeted exclusions for a specific failure (see PROMPTING RULES) and the tested exclusion lines in CONTINUITY AND AUDIO LEARNINGS, never an endless negative list.
- **No director names, no signature-work references, no equipment names.**
