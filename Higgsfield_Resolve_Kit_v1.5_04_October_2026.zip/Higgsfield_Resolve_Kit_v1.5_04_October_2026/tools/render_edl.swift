// Render a preview cut from an EDL json with AVFoundation (no Resolve needed).
// usage: render_edl EDL.json SHOTS_DIR VO_DIR OUT.mp4
// EDL: {"w":1440,"h":1080,"clips":[{"clip":"x.mp4","in":0,"out":10,"vol":1.0,
//        "trans":"cut"|"dissolve"|"black","tdur":1.0,"vo":[["file.wav",offsetSec,vol?]]}], "tail_fade":1.5}
// "trans" describes the transition INTO this clip. VO offsets are relative to this clip's timeline start.
import AVFoundation
import Foundation

let a = CommandLine.arguments
let edl = try! JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: a[1]))) as! [String: Any]
let shots = a[2], voDir = a[3], outURL = URL(fileURLWithPath: a[4])
let W = CGFloat(edl["w"] as? Double ?? 1440), H = CGFloat(edl["h"] as? Double ?? 1080)
let clips = edl["clips"] as! [[String: Any]]
let tailFade = edl["tail_fade"] as? Double ?? 1.0
let ts: Int32 = 600
func T(_ s: Double) -> CMTime { CMTime(seconds: s, preferredTimescale: ts) }

let comp = AVMutableComposition()
let vT = [comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)!,
          comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)!]
let aT = [comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)!,
          comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)!]
let voT = [comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)!,
           comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)!]

struct Placed { var start: Double; var dur: Double; var track: Int; var tin: String; var tdur: Double; var natural: CGSize; var xf: CGAffineTransform; var vol: Float; var astart: Double; var adur: Double }
var placed: [Placed] = []
var cursor = 0.0
var voIdx = 0
var voPlaced: [(Int, Double, Double, Float)] = []  // track, start, dur, vol
for (i, c) in clips.enumerated() {
    let asset = AVURLAsset(url: URL(fileURLWithPath: shots + "/" + (c["clip"] as! String)))
    let vin = c["in"] as! Double, vout = c["out"] as! Double, dur = vout - vin
    let trans = c["trans"] as? String ?? "cut"
    let tdur = c["tdur"] as? Double ?? 1.0
    let start = (trans == "dissolve" && i > 0) ? cursor - tdur : cursor
    let tr = i % 2
    let src = asset.tracks(withMediaType: .video)[0]
    try! vT[tr].insertTimeRange(CMTimeRange(start: T(vin), duration: T(dur)), of: src, at: T(start))
    // split edit: "a_pre"/"a_post" = seconds of this clip's own audio that start before / run past its picture (J/L cut)
    let apre = c["a_pre"] as? Double ?? 0, apost = c["a_post"] as? Double ?? 0
    if let sa = asset.tracks(withMediaType: .audio).first {
        try! aT[tr].insertTimeRange(CMTimeRange(start: T(vin - apre), duration: T(dur + apre + apost)), of: sa, at: T(start - apre))
    }
    let nat = src.naturalSize.applying(src.preferredTransform)
    let sz = CGSize(width: abs(nat.width), height: abs(nat.height))
    let sc = max(W / sz.width, H / sz.height)
    var xf = src.preferredTransform.concatenating(CGAffineTransform(scaleX: sc, y: sc))
        .concatenating(CGAffineTransform(translationX: (W - sz.width * sc) / 2, y: (H - sz.height * sc) / 2))
    // optional punch-in: "zoom" (e.g. 1.4) centred on ("cx","cy") in normalized top-left frame coords, clamped to frame edges
    if let z = c["zoom"] as? Double, z > 1.0 {
        let cx = (c["cx"] as? Double ?? 0.5) * W, cy = (c["cy"] as? Double ?? 0.5) * H
        let tx = min(0, max(W - z * W, W / 2 - z * cx)), ty = min(0, max(H - z * H, H / 2 - z * cy))
        xf = xf.concatenating(CGAffineTransform(scaleX: z, y: z)).concatenating(CGAffineTransform(translationX: tx, y: ty))
    }
    placed.append(Placed(start: start, dur: dur, track: tr, tin: trans, tdur: tdur, natural: sz, xf: xf, vol: Float(c["vol"] as? Double ?? 1.0), astart: start - apre, adur: dur + apre + apost))
    for v in (c["vo"] as? [[Any]] ?? []) {
        let f = voDir + "/" + (v[0] as! String); let off = (v[1] as? Double) ?? Double(v[1] as! Int)
        let vvol = Float((v.count > 2 ? v[2] as? Double : nil) ?? 1.0)
        let va = AVURLAsset(url: URL(fileURLWithPath: f)); guard let vs = va.tracks(withMediaType: .audio).first else { print("missing VO", f); continue }
        let vd = CMTimeGetSeconds(va.duration); let vt = voIdx % 2; voIdx += 1
        try! voT[vt].insertTimeRange(CMTimeRange(start: .zero, duration: va.duration), of: vs, at: T(start + off))
        voPlaced.append((vt, start + off, vd, vvol))
    }
    cursor = start + dur
}
let total = cursor

// Video composition: one instruction spanning everything per segment boundary set.
var bounds = Set<Double>([0, total])
for p in placed { bounds.insert(p.start); bounds.insert(p.start + p.dur) }
// split instructions where fades begin/end, so each opacity ramp spans only its fade (not the whole clip)
if let f = placed.first { bounds.insert(min(f.start + 0.8, f.start + f.dur)) }
if let l = placed.last { bounds.insert(max(l.start, l.start + l.dur - tailFade)) }
for (i, p) in placed.enumerated() where i > 0 {
    if p.tin == "dissolve" { bounds.insert(p.start + p.tdur) }
    if p.tin == "black" { bounds.insert(p.start + p.tdur / 2); let pv = placed[i - 1]; bounds.insert(pv.start + pv.dur - p.tdur / 2) }
}
let bs = bounds.sorted()
var instrs: [AVMutableVideoCompositionInstruction] = []
for k in 0..<(bs.count - 1) {
    let s = bs[k], e = bs[k + 1]; if e - s < 1e-4 { continue }
    let ins = AVMutableVideoCompositionInstruction(); ins.timeRange = CMTimeRange(start: T(s), end: T(e))
    ins.backgroundColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
    var layers: [AVMutableVideoCompositionLayerInstruction] = []
    // active clips in [s,e), later clip on top
    let active = placed.enumerated().filter { $0.element.start < e - 1e-4 && $0.element.start + $0.element.dur > s + 1e-4 }.reversed()
    for (idx, p) in active {
        let li = AVMutableVideoCompositionLayerInstruction(assetTrack: vT[p.track]); li.setTransform(p.xf, at: T(s))
        func op(_ t: Double) -> Float {
            var o: Float = 1
            if p.tin == "black" && idx > 0 { let h = p.tdur / 2; if t < p.start + h { o = min(o, Float((t - p.start) / h)) } }
            if p.tin == "dissolve" && idx > 0 { if t < p.start + p.tdur { o = min(o, Float((t - p.start) / p.tdur)) } }
            if idx + 1 < placed.count, placed[idx + 1].tin == "black" { let h = placed[idx + 1].tdur / 2; let end = p.start + p.dur; if t > end - h { o = min(o, Float((end - t) / h)) } }
            if idx == placed.count - 1 { let end = p.start + p.dur; if t > end - tailFade { o = min(o, Float((end - t) / tailFade)) } }
            if idx == 0 && t < p.start + 0.8 { o = min(o, Float((t - p.start) / 0.8)) }
            return max(0, min(1, o))
        }
        li.setOpacityRamp(fromStartOpacity: op(s), toEndOpacity: op(e), timeRange: CMTimeRange(start: T(s), end: T(e)))
        layers.append(li)
    }
    ins.layerInstructions = layers; instrs.append(ins)
}
let vc = AVMutableVideoComposition(); vc.instructions = instrs; vc.renderSize = CGSize(width: W, height: H)
vc.frameDuration = CMTime(value: 1, timescale: 24)

// Audio mix: clip audio with short crossfades at transitions, VO at its own level.
var params: [AVMutableAudioMixInputParameters] = []
for tr in 0..<2 {
    let pm = AVMutableAudioMixInputParameters(track: aT[tr]); pm.setVolume(0, at: .zero)
    for (idx, p) in placed.enumerated() where p.track == tr {
        let fi = (p.tin == "cut" || idx == 0) ? 0.05 : min(p.tdur, 1.0)
        pm.setVolumeRamp(fromStartVolume: 0, toEndVolume: p.vol, timeRange: CMTimeRange(start: T(p.astart), duration: T(fi)))
        let fo = 0.25; pm.setVolumeRamp(fromStartVolume: p.vol, toEndVolume: 0, timeRange: CMTimeRange(start: T(p.astart + p.adur - fo), duration: T(fo)))
    }
    params.append(pm)
}
for tr in 0..<2 {
    let pm = AVMutableAudioMixInputParameters(track: voT[tr]); pm.setVolume(0, at: .zero)
    for v in voPlaced where v.0 == tr { pm.setVolume(v.3, at: T(v.1)) }
    params.append(pm)
}
let mix = AVMutableAudioMix(); mix.inputParameters = params

try? FileManager.default.removeItem(at: outURL)
let ex = AVAssetExportSession(asset: comp, presetName: AVAssetExportPresetHighestQuality)!
ex.outputURL = outURL; ex.outputFileType = .mp4; ex.videoComposition = vc; ex.audioMix = mix
let sem = DispatchSemaphore(value: 0)
ex.exportAsynchronously { sem.signal() }
sem.wait()
print(ex.status == .completed ? String(format: "OK %.2fs -> %@", total, outURL.path) : "FAILED \(String(describing: ex.error))")
