"""Every clip in an EDL must have an approved / needs_repair row in <project>/logs/qa_index.csv  [R-J10, R-K4].
usage: python3 tools/review_check.py <project> <EDL.json>      exit 1 = stop the build
Set ALLOW_UNREVIEWED=1 to build anyway (say so in the handoff)."""
import csv, json, os, sys
P, EDL = os.path.abspath(sys.argv[1]), sys.argv[2]
Q = os.path.join(P, "logs", "qa_index.csv")
clips = sorted({c["clip"] for c in json.load(open(EDL))["clips"]})
rows = {}
if os.path.exists(Q):
    for r in csv.DictReader(open(Q)):
        if r.get("clip"): rows[r["clip"].strip()] = (r.get("verdict") or "").strip().lower()   # last row per clip wins
bad = []
for c in clips:
    v = rows.get(c)
    if v not in ("approved", "needs_repair"):
        bad.append((c, v or "no row"))
for c, v in bad: print(f"  NOT REVIEWED / NOT USABLE  {c}  ({v})")
print(f"review check: {len(clips) - len(bad)}/{len(clips)} clips approved or needs_repair in logs/qa_index.csv")
if bad and os.environ.get("ALLOW_UNREVIEWED") != "1":
    print("BUILD STOPPED: add a review row per take (clip, verdict, reason, evidence, edit_use), or set ALLOW_UNREVIEWED=1")
    sys.exit(1)
