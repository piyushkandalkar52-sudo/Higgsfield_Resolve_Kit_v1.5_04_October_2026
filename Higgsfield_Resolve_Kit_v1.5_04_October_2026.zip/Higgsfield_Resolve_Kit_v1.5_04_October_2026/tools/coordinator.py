#!/usr/bin/env python3
"""Local production ledger. Never submits remote jobs or spends credits."""
import argparse
import copy
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import fcntl
import json
import os
from pathlib import Path
import sys
import tempfile


def money(value):
    try:
        result = Decimal(str(value))
    except InvalidOperation:
        raise ValueError('cost must be a finite nonnegative number')
    if not result.is_finite() or result < 0:
        raise ValueError('cost must be a finite nonnegative number')
    return result


def now():
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def locked(project):
    directory = Path(project) / 'logs'
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / '.production_manifest.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        path = directory / 'production_manifest.json'
        state = json.loads(path.read_text()) if path.exists() else None
        yield path, state


def save(path, state):
    fd, temporary = tempfile.mkstemp(prefix='.manifest-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(state, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def totals(state):
    tasks = state['tasks'].values()
    actual = sum((money(t['actual']) for t in tasks if t['actual'] is not None), Decimal(0))
    reserved = sum((money(t['reservation']) for t in state['tasks'].values()), Decimal(0))
    return {'actual': str(actual), 'reserved': str(reserved),
            'available': str(money(state['cap']) - actual - reserved)}


def eligible(state, task):
    if task['invalidated'] or task['plan_version'] != state['approved_plan_version']:
        return False
    for dependency in task['dependencies']:
        parent = state['tasks'][dependency]
        if parent['qa'] != 'accepted' or parent['invalidated']:
            return False
    parent = task['continuity_parent']
    return not parent or bool(state['tasks'][parent]['handoff'])


def execute(project, command, **args):
    for field in ('run_id', 'task_id', 'plan_version', 'job_id', 'kind'):
        if field in args and (not isinstance(args[field], str) or not args[field].strip()):
            raise ValueError(field + ' must be nonempty')
    if args.get('handoff') is not None and not args['handoff'].strip():
        raise ValueError('handoff must contain observed continuity information')
    with locked(project) as (path, original):
        state = copy.deepcopy(original)
        if command == 'init':
            if state is not None:
                if state['run_id'] == args['run_id'] and money(state['cap']) == money(args['cap']):
                    return state
                raise ValueError('ledger already initialized; cannot overwrite')
            state = {'schema_version': 1, 'run_id': args['run_id'], 'cap': str(money(args['cap'])),
                     'approved_plan_version': None, 'tasks': {}, 'events': []}
        elif state is None:
            raise ValueError('initialize the ledger first')
        elif command == 'status':
            return {'ledger': state, 'totals': totals(state)}
        elif command == 'ready':
            return [t['id'] for t in state['tasks'].values()
                    if t['submission'] == 'planned' and eligible(state, t)]
        elif command == 'approve':
            if not args['evidence'].strip() or not args['approved_by'].strip():
                raise ValueError('record actual user approval evidence and approver')
            if any(t['submission'] == 'reserved' for t in state['tasks'].values()):
                raise ValueError('cancel confirmed unsubmitted reservations before changing plan')
            state['approved_plan_version'] = args['plan_version']
        elif command == 'add':
            task_id = args['task_id']
            if task_id in state['tasks']:
                raise ValueError('task ID already exists; retries need new IDs')
            dependencies = list(dict.fromkeys(args.get('depends') or []))
            parent = args.get('continuity_parent')
            if parent and parent not in dependencies:
                dependencies.append(parent)
            if task_id in dependencies or any(d not in state['tasks'] for d in dependencies):
                raise ValueError('dependencies must exist already and cannot include this task; cycles prohibited')
            state['tasks'][task_id] = {
                'id': task_id, 'plan_version': args['plan_version'], 'kind': args['kind'],
                'dependencies': dependencies, 'continuity_parent': parent,
                'submission': 'planned', 'reservation': '0', 'actual': None,
                'job_id': None, 'qa': 'pending', 'evidence': None, 'handoff': None,
                'invalidated': False, 'created_at': now()}
        else:
            task = state['tasks'].get(args['task_id'])
            if task is None:
                raise ValueError('unknown task ID')
            if command == 'reserve':
                cost = money(args['cost'])
                if task['submission'] == 'reserved' and money(task['reservation']) == cost:
                    if not eligible(state, task):
                        raise ValueError('existing reservation is stale; reconcile before proceeding')
                    return task
                if task['submission'] != 'planned' or not eligible(state, task):
                    raise ValueError('task is not ready under the currently approved plan')
                if money(totals(state)['actual']) + money(totals(state)['reserved']) + cost > money(state['cap']):
                    raise ValueError('budget cap exceeded by actual charges plus reservations')
                task['reservation'] = str(cost)
                task['submission'] = 'reserved'
            elif command == 'submitted':
                if task['job_id'] == args['job_id']:
                    return task
                if task['submission'] not in ('reserved', 'unknown'):
                    raise ValueError('submission must have a reservation or unresolved outcome')
                if any(t['job_id'] == args['job_id'] for t in state['tasks'].values()):
                    raise ValueError('remote job ID already recorded')
                # Recording an observed job remains necessary even if its inputs became stale.
                task['job_id'] = args['job_id']
                task['submission'] = 'submitted'
            elif command == 'unknown':
                if task['submission'] not in ('reserved', 'unknown'):
                    raise ValueError('only a reserved submission can become unknown')
                task['submission'] = 'unknown'
            elif command == 'cancel':
                if task['submission'] not in ('planned', 'reserved', 'unknown') or not args['evidence'].strip():
                    raise ValueError('cancel requires evidence of no remote job / confirmed no charge')
                task['submission'] = 'cancelled'
                task['reservation'] = '0'
                task['evidence'] = args['evidence']
            elif command == 'settle':
                actual = money(args['actual'])
                if task['submission'] == 'settled' and money(task['actual']) == actual:
                    return task
                if task['submission'] != 'submitted':
                    raise ValueError('reconcile unknown submission to its remote job before settlement')
                task['actual'] = str(actual)
                task['reservation'] = '0'
                task['submission'] = 'settled'
                # Actual invoices are truth even when an estimate was too low.
            elif command in ('accept', 'reject'):
                if task['submission'] not in ('submitted', 'settled') or task['invalidated']:
                    raise ValueError('QA requires a recorded, non-invalidated remote job')
                if not args['evidence'].strip():
                    raise ValueError('QA evidence required')
                if task['qa'] != 'pending':
                    raise ValueError('QA verdict is immutable; invalidate and use a new task ID')
                if command == 'accept' and not eligible(state, task):
                    raise ValueError('dependencies or plan are no longer current')
                task['qa'] = 'accepted' if command == 'accept' else 'rejected'
                task['evidence'] = args['evidence']
                task['handoff'] = args.get('handoff')
            elif command == 'revalidate':
                if not task['invalidated'] or task['qa'] != 'accepted':
                    raise ValueError('revalidate requires a historically accepted invalidated take')
                if not args['evidence'].strip():
                    raise ValueError('revalidation requires fresh review evidence')
                if args['plan_version'] != state['approved_plan_version']:
                    raise ValueError('revalidation must use the currently approved plan')
                dependencies = args.get('depends')
                if dependencies is not None:
                    task['dependencies'] = list(dict.fromkeys(dependencies))
                if args.get('continuity_parent') is not None:
                    task['continuity_parent'] = args['continuity_parent']
                parent = task['continuity_parent']
                if parent and parent not in task['dependencies']:
                    task['dependencies'].append(parent)
                if any(d not in state['tasks'] for d in task['dependencies']):
                    raise ValueError('all rebound dependencies must exist')
                visiting, visited = set(), set()
                def visit(identifier):
                    if identifier in visiting:
                        raise ValueError('dependency cycle prohibited')
                    if identifier in visited:
                        return
                    visiting.add(identifier)
                    for dependency in state['tasks'][identifier]['dependencies']:
                        visit(dependency)
                    visiting.remove(identifier)
                    visited.add(identifier)
                for identifier in state['tasks']:
                    visit(identifier)
                task['plan_version'] = args['plan_version']
                task['invalidated'] = False
                if not eligible(state, task):
                    raise ValueError('rebound dependencies must be accepted and current with required handoff')
                if task['handoff'] or parent:
                    if not args.get('handoff'):
                        raise ValueError('fresh observed handoff required for continuity revalidation')
                task['evidence'] = args['evidence']
                if args.get('handoff') is not None:
                    task['handoff'] = args['handoff']
            elif command == 'invalidate':
                if not args['reason'].strip():
                    raise ValueError('invalidation reason required')
                affected = {task['id']}
                while True:
                    expanded = affected | {t['id'] for t in state['tasks'].values()
                                           if affected.intersection(t['dependencies'])}
                    if expanded == affected:
                        break
                    affected = expanded
                for identifier in affected:
                    state['tasks'][identifier]['invalidated'] = True
                # Reservations survive invalidation: a dispatch may already have happened.
                args['affected'] = sorted(affected)
            else:
                raise ValueError('unknown command')
        state['events'].append({'at': now(), 'command': command, 'args': args})
        save(path, state)
        return {'command': command, 'totals': totals(state)}


def parser():
    root = argparse.ArgumentParser(description=__doc__)
    root.add_argument('--project', required=True)
    sub = root.add_subparsers(dest='command', required=True)
    specifications = {
        'init': ('run-id', 'cap'), 'approve': ('plan-version', 'approved-by', 'evidence'),
        'add': ('task-id', 'plan-version', 'kind'), 'ready': (), 'status': (),
        'reserve': ('task-id', 'cost'), 'submitted': ('task-id', 'job-id'),
        'unknown': ('task-id',), 'cancel': ('task-id', 'evidence'),
        'settle': ('task-id', 'actual'), 'accept': ('task-id', 'evidence'),
        'reject': ('task-id', 'evidence'), 'invalidate': ('task-id', 'reason'),
        'revalidate': ('task-id', 'plan-version', 'evidence')}
    for name, required in specifications.items():
        command = sub.add_parser(name)
        for argument in required:
            command.add_argument('--' + argument, required=True)
        if name in ('add', 'revalidate'):
            command.add_argument('--depends', nargs='*', default=[] if name == 'add' else None)
            command.add_argument('--continuity-parent')
        if name in ('accept', 'revalidate'):
            command.add_argument('--handoff', help='Observed continuity packet text or path; not automatically inspected')
    return root


def main():
    args = vars(parser().parse_args())
    project, command = args.pop('project'), args.pop('command')
    try:
        print(json.dumps(execute(project, command, **args), indent=2))
    except (ValueError, OSError, json.JSONDecodeError) as error:
        print('coordinator: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
