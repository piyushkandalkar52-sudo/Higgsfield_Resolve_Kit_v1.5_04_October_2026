import AVFoundation; import AppKit
let a=CommandLine.arguments; let g=AVAssetImageGenerator(asset: AVURLAsset(url: URL(fileURLWithPath:a[1])))
g.appliesPreferredTrackTransform=true; g.requestedTimeToleranceBefore = .zero; g.requestedTimeToleranceAfter = .zero
let cg=try! g.copyCGImage(at: CMTime(seconds: Double(a[3])!, preferredTimescale:600), actualTime:nil)
let r=NSBitmapImageRep(cgImage:cg); try! r.representation(using:.jpeg,properties:[:])!.write(to:URL(fileURLWithPath:a[2]))
