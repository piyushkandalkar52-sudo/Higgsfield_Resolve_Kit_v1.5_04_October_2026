// Slow down one section of a clip by re-timing frames (reader/writer; original untouched).
// usage: retime IN.mp4 OUT.mp4 START END FACTOR   (FACTOR 1.6 = that section plays 1.6x longer)
import AVFoundation
let a = CommandLine.arguments
let asset = AVURLAsset(url: URL(fileURLWithPath: a[1]))
let s = Double(a[3])!, e = Double(a[4])!, f = Double(a[5])!
let track = asset.tracks(withMediaType: .video)[0]
let reader = try! AVAssetReader(asset: asset)
let ro = AVAssetReaderTrackOutput(track: track, outputSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
reader.add(ro)
let out = URL(fileURLWithPath: a[2]); try? FileManager.default.removeItem(at: out)
let writer = try! AVAssetWriter(outputURL: out, fileType: .mp4)
let sz = track.naturalSize
let wi = AVAssetWriterInput(mediaType: .video, outputSettings: [AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: Int(sz.width), AVVideoHeightKey: Int(sz.height),
    AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: 8_000_000]])
wi.transform = track.preferredTransform
let ad = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: wi, sourcePixelBufferAttributes: nil)
writer.add(wi); reader.startReading(); writer.startWriting(); writer.startSession(atSourceTime: .zero)
func map(_ t: Double) -> Double { t <= s ? t : (t <= e ? s + (t - s) * f : s + (e - s) * f + (t - e)) }
var n = 0
while let sb = ro.copyNextSampleBuffer() {
    guard let px = CMSampleBufferGetImageBuffer(sb) else { continue }
    let t = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sb))
    while !wi.isReadyForMoreMediaData { usleep(1000) }
    ad.append(px, withPresentationTime: CMTime(seconds: map(t), preferredTimescale: 6000)); n += 1
}
wi.markAsFinished()
let sem = DispatchSemaphore(value: 0); writer.finishWriting { sem.signal() }; sem.wait()
print(writer.status == .completed ? "OK frames \(n) dur \(map(CMTimeGetSeconds(asset.duration)))" : "FAILED \(String(describing: writer.error))")
