// Bake a sepia "memory" look into a clip (originals untouched).
// usage: sepia IN.mp4 OUT.mp4 [intensity 0..1, default 0.85]
import AVFoundation
import CoreImage
let a = CommandLine.arguments
let asset = AVURLAsset(url: URL(fileURLWithPath: a[1]))
let k = a.count > 3 ? Double(a[3])! : 0.85
let comp = AVVideoComposition(asset: asset) { req in
    let src = req.sourceImage.clampedToExtent()
    let sep = CIFilter(name: "CISepiaTone", parameters: [kCIInputImageKey: src, kCIInputIntensityKey: k])!.outputImage!
    let vig = CIFilter(name: "CIVignette", parameters: [kCIInputImageKey: sep, kCIInputIntensityKey: 0.6, kCIInputRadiusKey: 1.6])!.outputImage!
    req.finish(with: vig.cropped(to: req.sourceImage.extent), context: nil)
}
let out = URL(fileURLWithPath: a[2]); try? FileManager.default.removeItem(at: out)
let ex = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality)!
ex.outputURL = out; ex.outputFileType = .mp4; ex.videoComposition = comp
let sem = DispatchSemaphore(value: 0); ex.exportAsynchronously { sem.signal() }; sem.wait()
print(ex.status == .completed ? "OK \(out.lastPathComponent)" : "FAILED \(String(describing: ex.error))")
