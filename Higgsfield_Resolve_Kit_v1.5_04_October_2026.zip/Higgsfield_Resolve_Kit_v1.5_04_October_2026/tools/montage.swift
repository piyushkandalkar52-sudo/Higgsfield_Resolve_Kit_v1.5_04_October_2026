import AppKit
// usage: mont OUT.jpg COLS CELLW CELLH img...
let a=CommandLine.arguments; let cols=Int(a[2])!, cw=CGFloat(Double(a[3])!), ch=CGFloat(Double(a[4])!)
let files=Array(a[5...]); let rows=(files.count+cols-1)/cols
let W=Int(cw)*cols, H=Int(ch)*rows
let rep=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:W,pixelsHigh:H,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep)
NSColor.white.setFill(); NSRect(x:0,y:0,width:W,height:H).fill()
for (i,f) in files.enumerated(){ guard let im=NSImage(contentsOfFile:f) else{continue}
 let s=min(cw/im.size.width,ch/im.size.height); let w=im.size.width*s,h=im.size.height*s
 let c=CGFloat(i%cols), r=CGFloat(rows-1-i/cols)
 im.draw(in:NSRect(x:c*cw+(cw-w)/2,y:r*ch+(ch-h)/2,width:w,height:h))
 (URL(fileURLWithPath:f).lastPathComponent.prefix(28) as NSString).draw(at:NSPoint(x:c*cw+4,y:r*ch+4),withAttributes:[.font:NSFont.boldSystemFont(ofSize:14),.foregroundColor:NSColor.red])}
NSGraphicsContext.restoreGraphicsState()
try! rep.representation(using:.jpeg,properties:[.compressionFactor:0.8])!.write(to:URL(fileURLWithPath:a[1]))
