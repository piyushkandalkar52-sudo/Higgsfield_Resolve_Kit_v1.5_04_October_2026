"""Local, free QA for generated clips: download, Resolve transcript, lip check per line, contact sheet.
usage: python3 qa_clips.py JOBS.json --shots DIR --folder MEDIA_POOL_FOLDER [--out QA_DIR]
JOBS.json = [["S05_K1_a1.mp4","https://...mp4"], ...]  (url may be "" if the file is already in --shots)
Needs the compiled lipqa and sheet binaries next to this script (see README, Setup)."""
import argparse, json, os, subprocess, DaVinciResolveScript as d
a=argparse.ArgumentParser(); a.add_argument("jobs"); a.add_argument("--shots",required=True); a.add_argument("--folder",required=True); a.add_argument("--out",default=None); o=a.parse_args()
H=os.path.dirname(os.path.abspath(__file__)); out=o.out or os.path.join(o.shots,"_qa"); os.makedirs(out,exist_ok=True)
r=d.scriptapp("Resolve"); p=r.GetProjectManager().GetCurrentProject(); mp=p.GetMediaPool(); cur=p.GetCurrentTimeline(); root=mp.GetRootFolder()
f=[x for x in root.GetSubFolderList() if x.GetName()==o.folder]; f=f[0] if f else mp.AddSubFolder(root,o.folder); mp.SetCurrentFolder(f)
report={}
for name,url in json.load(open(o.jobs)):
    path=os.path.join(o.shots,name)
    if not os.path.exists(path): subprocess.run(["curl","-s","-o",path,url],check=True)
    clip=[c for c in f.GetClipList() if c.GetName()==name]; clip=clip[0] if clip else mp.ImportMedia([path])[0]
    tl=mp.CreateTimelineFromClips("QA_"+name,[clip]); p.SetCurrentTimeline(tl); tl.CreateSubtitlesFromAudio({})
    fps=float(tl.GetSetting("timelineFrameRate") or 24)
    subs=[((it.GetStart()-tl.GetStartFrame())/fps,(it.GetEnd()-tl.GetStartFrame())/fps,it.GetName()) for it in (tl.GetItemListInTrack("subtitle",1) or [])]
    mp.DeleteTimelines([tl]); print("==",name); rows=[]
    for s,e,t in subs:
        lip=""
        if not t.startswith("["):
            res=subprocess.run([os.path.join(H,"lipqa"),path,str(s),str(e)],capture_output=True,text=True).stdout
            lip="LIPS OK" if "LIPS MOVING" in res else "!! NO LIPSYNC"
        print(f"  {s:6.2f}-{e:6.2f}  {t}   {lip}"); rows.append([s,e,t,lip])
    subprocess.run([os.path.join(H,"sheet"),path,os.path.join(out,name+".jpg"),"8"],capture_output=True)
    report[name]=rows
if cur: p.SetCurrentTimeline(cur)
json.dump(report,open(os.path.join(out,"qa_report.json"),"w"),indent=1)
print("contact sheets + qa_report.json in",out)
