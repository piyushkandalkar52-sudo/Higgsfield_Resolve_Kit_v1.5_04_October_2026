"""Shot-length lint + auto-fix for render_edl JSON (TRA edit rule: no leftover under 2 s at a clip's head or tail).

Why: generated clips contain their own internal shots (wide / close / wide). Trimming a clip at an arbitrary time leaves
slivers (0.1-1.9 s) of the neighbouring shot at the cut. This tool looks at real shot boundaries inside every clip
(4_renders/edit/shotcuts.json, from tools/shotscan with isolated-spike detection) and:
  A leftover = a partial shot at the edge (the cut falls mid-shot) or the clip's own opening/closing wide. Complete
  designed shots (inserts, close-ups) are never removed for being short.
  fix   : moves each clip's in/out inward to a shot boundary until no leftover < MIN s remains, unless a dialogue
          line overlaps that fragment (then it is kept and reported). VO anchored to removed material moves with it,
          then all VO is re-spaced (dissolve-aware) so narration never overlaps.
  check : lists every edge fragment < MIN s; exits 1 if any is not a dialogue exception. Run before every build.

usage: python3 edit_lint.py fix IN.json OUT.json      python3 edit_lint.py check EDL.json
Project = $PROJECT or derived from the EDL path (<project>/4_renders/edit/EDL.json).
Extension chains: an EDL entry with "cont": true continues the previous clip's last shot (Seedance video_extension),
so its head is not a leftover and is never trimmed or reported.
EDL-level "edge_shots": "wides" (default, keyframe method: every clip opens/closes on a continuity wide, so a short
first/last shot is a leftover) or "designed" (clips open on a close shot / designed shot: only partial shots and
complete edge shots < 1.2 s are slivers).
"""
import json, os, sys, wave
MIN = 2.0          # leftovers (partial shots, clip opening/closing wides) shorter than this are removed
MIN_WHOLE = 1.2    # complete designed shots at a clip edge shorter than this read as slivers too
H = os.path.dirname(os.path.abspath(__file__))
ROOT = os.environ.get("PROJECT") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[2]))))
CUTS = json.load(open(os.path.join(ROOT, "4_renders/edit/shotcuts.json")))       # made by tools/shotcuts.py
_dj = os.path.join(ROOT, "4_renders/edit/dialogue.json")                          # made by tools/transcribe.py --dialogue
DIALOGUE = {k: [tuple(x) for x in v] for k, v in json.load(open(_dj)).items()} if os.path.exists(_dj) else {}
VO_DIR = os.path.join(ROOT, "4_renders/audio/vo")

def groups(clips):
    """Consecutive pieces of the same clip that are contiguous in source time play as one continuous stretch."""
    g = []
    for k, c in enumerate(clips):
        if g and clips[g[-1][-1]]["clip"] == c["clip"] and abs(clips[g[-1][-1]]["out"] - c["in"]) < 0.01 and c.get("trans", "cut") == "cut":
            g[-1].append(k)
        else:
            g.append([k])
    return g

def talks(clip, a, b):
    return any(s < b - 0.05 and e > a + 0.05 for s, e, t in DIALOGUE.get(clip, []))

def removable(name, a, b, side):
    """True if [a,b] at this edge is a leftover: a partial shot, or the clip's own first/last (wide) shot."""
    cuts = CUTS[name]["cuts"]; dur = CUTS[name]["dur"]; bounds = [0.0] + cuts + [dur]
    on = lambda t: any(abs(t - x) < 0.12 for x in bounds)
    if b - a < MIN_WHOLE: return True
    if EDGE == "designed": return not (on(a) and on(b))   # clips open/close on designed shots: keep complete shots >= MIN_WHOLE
    if side == "head": return (not on(a)) or (not cuts or b <= cuts[0] + 0.01)
    return (not on(b)) or (not cuts or a >= cuts[-1] - 0.01)

def edge_fragments(clips):
    rep = []
    for g in groups(clips):
        name = clips[g[0]]["clip"]; a, b = clips[g[0]]["in"], clips[g[-1]]["out"]
        cuts = [t for t in CUTS[name]["cuts"] if a + 0.05 < t < b - 0.05]
        if not cuts:
            if b - a < MIN: rep.append((name, "whole", a, b, talks(name, a, b)))
            continue
        if cuts[0] - a < MIN and not clips[g[0]].get("cont") and removable(name, a, cuts[0], "head"): rep.append((name, "head", a, cuts[0], talks(name, a, cuts[0])))
        if b - cuts[-1] < MIN and removable(name, cuts[-1], b, "tail"): rep.append((name, "tail", cuts[-1], b, talks(name, cuts[-1], b)))
    return rep

def vo_len(f):
    w = wave.open(os.path.join(VO_DIR, f)); d = w.getnframes() / w.getframerate(); w.close(); return d

def fix(E):
    _need_cuts(E)
    clips = [dict(c, vo=[list(v) for v in c.get("vo", [])]) for c in E["clips"]]
    for _ in range(6):  # repeat: removing a fragment can expose the next short one
        changed = False
        for g in groups(clips):
            name = clips[g[0]]["clip"]
            while True:  # head
                a, b = clips[g[0]]["in"], clips[g[-1]]["out"]
                cuts = [t for t in CUTS[name]["cuts"] if a + 0.05 < t < b - 0.05]
                if not cuts or cuts[0] - a >= MIN or not removable(name, a, cuts[0], "head") or b - cuts[0] < MIN: break
                t = cuts[0]
                if talks(name, a, t):  # speech in the leftover: J-cut (audio starts over the previous shot) if that shot is silent there
                    ss = min(s0 for s0, e0, _ in DIALOGUE[name] if s0 < t - 0.05 and e0 > a + 0.05); pre = round(t - max(a, ss - 0.08), 2)
                    prv = clips[g[0] - 1] if g[0] > 0 else None
                    ok = (prv is not None and clips[g[0]].get("trans", "cut") == "cut" and prv["out"] - prv["in"] > pre + 0.3
                          and not talks(prv["clip"], prv["out"] - pre - 0.05, prv["out"]))
                    if not ok:  # keep the shot, but start it where the speech starts
                        na = round(max(a, ss - 0.08), 2)
                        if na > a + 0.05:
                            clips[g[0]]["vo"] = [[f, o - (na - a)] for f, o in clips[g[0]]["vo"]]; clips[g[0]]["in"] = na; changed = True
                        break
                    clips[g[0]]["a_pre"] = pre
                while clips[g[0]]["out"] <= t + 0.01 and len(g) > 1:  # drop whole pieces, carry their VO forward
                    dead = clips[g[0]]; L = dead["out"] - dead["in"]
                    clips[g[1]]["vo"] = [[f, o - L] for f, o in dead["vo"]] + clips[g[1]]["vo"]
                    for key in ("trans", "tdur", "scene"):
                        if key in dead: clips[g[1]][key] = dead[key]
                    dead["drop"] = True; g = g[1:]
                d = t - clips[g[0]]["in"]; clips[g[0]]["in"] = t
                clips[g[0]]["vo"] = [[f, o - d] for f, o in clips[g[0]]["vo"]]; changed = True
            while True:  # tail
                a, b = clips[g[0]]["in"], clips[g[-1]]["out"]
                cuts = [t for t in CUTS[name]["cuts"] if a + 0.05 < t < b - 0.05]
                if not cuts or b - cuts[-1] >= MIN or not removable(name, cuts[-1], b, "tail") or cuts[-1] - a < MIN: break
                t = cuts[-1]
                if talks(name, t, b):  # speech in the leftover: L-cut (audio runs on over the next shot) if that shot is silent there
                    se = max(e0 for s0, e0, _ in DIALOGUE[name] if s0 < b - 0.05 and e0 > t + 0.05); post = round(min(b, se + 0.05) - t, 2)
                    k = g[-1] + 1; nxt = clips[k] if k < len(clips) else None
                    ok = nxt is not None and nxt.get("trans", "cut") == "cut" and nxt["out"] - nxt["in"] > post + 0.3
                    if ok:
                        first = [s0 for s0, e0, _ in DIALOGUE.get(nxt["clip"], []) if e0 > nxt["in"] + 0.05]
                        if first and min(first) - nxt["in"] < post + 0.1:  # next shot speaks too soon: start it earlier inside the same shot
                            need = post + 0.1 - (min(first) - nxt["in"]); ni = round(nxt["in"] - need, 2)
                            if ni >= 0 and not [x for x in CUTS[nxt["clip"]]["cuts"] if ni - 0.05 < x < nxt["in"]]:
                                nxt["in"] = ni; nxt["vo"] = [[f, o + need] for f, o in nxt["vo"]]
                            else: ok = False
                    if not ok: break
                    clips[g[-1]]["a_post"] = post
                while clips[g[-1]]["in"] >= t - 0.01 and len(g) > 1:
                    dead = clips[g[-1]]; start_in_prev = clips[g[-2]]["out"] - clips[g[-2]]["in"]
                    clips[g[-2]]["vo"] += [[f, o + start_in_prev] for f, o in dead["vo"]]
                    dead["drop"] = True; g = g[:-1]
                if clips[g[-1]].get("a_post") and clips[g[-1]]["out"] - clips[g[-1]]["in"] > 0: pass
                clips[g[-1]]["out"] = t; changed = True
        clips = [c for c in clips if not c.get("drop")]
        if not changed: break
    for c in clips:  # a head cut can push VO offsets negative: shift the piece's VO so the first starts at 0, keep spacing
        if c["vo"]:
            m = min(o for f, o in c["vo"])
            if m < 0: c["vo"] = [[f, round(o - m, 2)] for f, o in c["vo"]]
        if not c["vo"]: c.pop("vo")
    cur, last = 0.0, -1.0  # re-space narration (dissolve-aware)
    for k, c in enumerate(clips):
        if c.get("trans") == "dissolve" and k > 0: cur -= c.get("tdur", 1.0)
        if k > 0 and clips[k - 1].get("a_post"): last = max(last, cur + clips[k - 1]["a_post"])  # L-cut dialogue occupies this
        for v in sorted(c.get("vo", []), key=lambda x: x[1]):
            if cur + v[1] < last + 0.15: v[1] = round(last + 0.15 - cur, 2)
            last = cur + v[1] + vo_len(v[0])
        cur += c["out"] - c["in"]
    E = dict(E, clips=clips); return E

def vo_report(E):
    cur, rows, scenes = 0.0, [], []
    for k, c in enumerate(E["clips"]):
        if c.get("trans") == "dissolve" and k > 0: cur -= c.get("tdur", 1.0)
        if c.get("scene"): scenes.append((c["scene"], cur + c.get("tdur", 0)))
        for f, o in c.get("vo", []): rows.append((cur + o, cur + o + vo_len(f), f))
        cur += c["out"] - c["in"]
    for sc, t in scenes:
        for a, b, f in rows:
            if a < t < b - 0.3 and not f.startswith(f"Q2_S{sc}"): print(f"  !! VO {f} runs {b - t:.1f}s past the dissolve into Sc {sc}")
    if rows and rows[-1][1] > cur: print(f"  !! last VO ends {rows[-1][1] - cur:.1f}s after picture")

EDGE = "wides"
def _need_cuts(E):
    global EDGE; EDGE = E.get("edge_shots", "wides")
    miss = sorted({c["clip"] for c in E["clips"] if c["clip"] not in CUTS})
    if miss: sys.exit("NOT SCANNED (run: python3 tools/shotcuts.py <project>): " + ", ".join(miss))

def check(E):
    _need_cuts(E)
    bad = 0
    for name, where, a, b, dl in edge_fragments(E["clips"]):
        tag = "kept (dialogue in it)" if dl else "FAIL"
        bad += not dl
        print(f"  {tag:22s} {name} {where} {a:.2f}-{b:.2f} ({b - a:.2f}s)")
    vo_report(E)
    print(f"edge fragments < {MIN}s that must go: {bad}")
    return bad

if __name__ == "__main__":
    if sys.argv[1] == "fix":
        E = fix(json.load(open(sys.argv[2]))); json.dump(E, open(sys.argv[3], "w"), indent=1)
        print(len(E["clips"]), "pieces", round(sum(c["out"] - c["in"] for c in E["clips"]), 1), "s"); sys.exit(1 if check(E) else 0)
    sys.exit(1 if check(json.load(open(sys.argv[2]))) else 0)
