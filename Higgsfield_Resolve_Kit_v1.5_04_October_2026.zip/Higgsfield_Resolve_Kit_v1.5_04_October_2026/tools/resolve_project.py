"""Open (or create) a DaVinci Resolve project by name and make it current. Never touches other projects' timelines.
usage: python3 tools/resolve_project.py "<project name>"     (source tools/resolve_env.sh first)"""
import sys, DaVinciResolveScript as d
pm = d.scriptapp("Resolve").GetProjectManager(); name = sys.argv[1]
p = pm.LoadProject(name) or pm.CreateProject(name)
print("current project:", p.GetName() if p else "FAILED", "| timelines:", p.GetTimelineCount() if p else "-")
