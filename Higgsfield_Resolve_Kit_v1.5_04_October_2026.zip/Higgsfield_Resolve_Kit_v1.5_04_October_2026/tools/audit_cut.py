"""Contact sheet of a whole cut, one frame every STEP seconds, stamped with timeline time. Use it to audit blocking/continuity.
usage: python3 audit_cut.py EDL.json --shots DIR --out audit.jpg [--step 0.75]   (needs opencv-python)"""
import argparse, json, os, cv2, numpy as np
a=argparse.ArgumentParser(); a.add_argument("edl"); a.add_argument("--shots",required=True); a.add_argument("--out",required=True); a.add_argument("--step",type=float,default=0.75); o=a.parse_args()
t=0; tiles=[]
for x in json.load(open(o.edl)):
    cap=cv2.VideoCapture(x.get("path") or os.path.join(o.shots,x["clip"])); s=x["in"]
    while s < x["out"]-0.05:
        cap.set(0,s*1000); ok,fr=cap.read()
        if ok: fr=cv2.resize(fr,(256,192)); cv2.putText(fr,f"{t+s-x['in']:.1f}",(5,18),0,0.55,(0,255,255),2); tiles.append(fr)
        s+=o.step
    t+=x["out"]-x["in"]
while len(tiles)%8: tiles.append(np.zeros_like(tiles[0]))
cv2.imwrite(o.out,np.vstack([np.hstack(tiles[i:i+8]) for i in range(0,len(tiles),8)])); print(len(tiles),"frames ->",o.out)
