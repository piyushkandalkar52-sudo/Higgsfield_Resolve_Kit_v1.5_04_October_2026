#!/usr/bin/env python3
"""Create an isolated project without changing any existing project."""
import argparse
from datetime import datetime
from pathlib import Path
import re
import shutil

# Project layout: the single source of truth for every folder the kit uses.
FOLDERS = [
    '1_source/script',      # script + notes
    '1_source/voices',      # voice samples
    '1_source/reference',   # reference video / data
    '2_library/characters', '2_library/locations', '2_library/costumes', '2_library/props',
    '3_prompts',            # approved scene packets
    '4_renders/frames',     # keyframes, sheets
    '4_renders/clips',      # generated shots
    '4_renders/scenes',     # assembled scenes
    '4_renders/audio/vo',   # voice-over / dialogue audio
    '4_renders/edit',       # EDL, shot cuts, dialogue timing
    '5_review/handoffs',    # QA sheets + continuity handoffs
    '6_final',              # delivered cuts
    'logs',
    'work',                 # worker scratch
]
LIBRARY_HEADER = ('asset_id,name,category,variant,view,file,scenes,approved,notes')
LOG_HEADERS = {
    'attempts.csv': 'job,attempt,job_id,model,mode,parent_job,duration,resolution,aspect,audio,credits,status,file,verdict,notes',
    'credits.csv': 'date,balance,spent,on_what',
    'qa_index.csv': 'clip,attempt,job_id,verdict,reason,evidence,edit_use,reviewed_utc,reviewer',
    'approvals.csv': 'date,gate,subject,decision,approver,notes',
    'benchmark_events.csv': 'run_id,arm,task_id,owner,category,start_utc,end_utc,notes',
}


def create(slug, parent=None):
    kit = Path(__file__).resolve().parent.parent
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', slug):
        raise ValueError('slug must be 1–80 letters/digits/underscores/hyphens, starting with a letter or digit')
    project = (Path(parent).expanduser() if parent else kit / 'projects') / slug
    if project.exists():
        raise ValueError(f'EXISTS {project}: resume explicitly; initializer never overwrites or migrates projects')
    project.mkdir(parents=True, exist_ok=False)
    for folder in FOLDERS:
        (project / folder).mkdir(parents=True, exist_ok=True)
    date = datetime.now().strftime('%Y-%m-%d')
    handoff = (kit / 'templates/HANDOFF_TEMPLATE.md').read_text().replace('<SLUG>', slug).replace('<DATE>', date)
    (project / 'HANDOFF.md').write_text(handoff)
    shutil.copyfile(kit / 'templates/BENCHMARK_REPORT_TEMPLATE.md', project / 'BENCHMARK_REPORT.md')
    shutil.copyfile(kit / 'templates/ASSET_LIBRARY.md', project / '2_library/README.md')
    (project / '2_library/library.csv').write_text(LIBRARY_HEADER + '\n')
    for name, header in LOG_HEADERS.items():
        (project / 'logs' / name).write_text(header + '\n')
    (project / 'logs/handoff_history.md').write_text(f'# Handoff history — {slug}\n\nPreserve dated completed-run reports; newest first.\n')
    return project.resolve()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('slug')
    parser.add_argument('parent', nargs='?')
    args = parser.parse_args()
    try:
        print('CREATED', create(args.slug, args.parent))
    except (ValueError, OSError) as error:
        parser.exit(1, str(error) + '\n')


if __name__ == '__main__':
    main()
