"""Transcribe clips or voice-over files with DaVinci Resolve's own speech-to-text (no Whisper/ffmpeg needed).
usage: python3 tools/transcribe.py --project "<Resolve project>" FILE [FILE ...] [--dialogue <project>/4_renders/edit/dialogue.json --shots <project>/4_renders/clips]
Prints "start-end text" per subtitle. With --dialogue, also stores {clip-path-relative-to-shots: [[s,e,text],...]} so
edit_lint.py knows where speech is. Needs Resolve running (source tools/resolve_env.sh first). Uses a "QA" bin and
temporary timelines it deletes again; never touches any other timeline."""
import sys, os, json, argparse, DaVinciResolveScript as d
a = argparse.ArgumentParser(); a.add_argument("files", nargs="+"); a.add_argument("--project", required=True)
a.add_argument("--dialogue"); a.add_argument("--shots"); o = a.parse_args()
r = d.scriptapp("Resolve"); pm = r.GetProjectManager()
p = pm.LoadProject(o.project) or pm.CreateProject(o.project)
mp = p.GetMediaPool(); root = mp.GetRootFolder()
qa = [f for f in root.GetSubFolderList() if f.GetName() == "QA"]; qa = qa[0] if qa else mp.AddSubFolder(root, "QA"); mp.SetCurrentFolder(qa)
D = json.load(open(o.dialogue)) if o.dialogue and os.path.exists(o.dialogue) else {}
for f in o.files:
    n = os.path.basename(f)
    c = [x for x in qa.GetClipList() if x.GetName() == n]; c = c[0] if c else mp.ImportMedia([os.path.abspath(f)])[0]
    tl = mp.CreateTimelineFromClips("QA_" + n, [c]); p.SetCurrentTimeline(tl); tl.CreateSubtitlesFromAudio({})
    fps = float(tl.GetSetting("timelineFrameRate") or 24)
    subs = [((i.GetStart() - tl.GetStartFrame()) / fps, (i.GetEnd() - tl.GetStartFrame()) / fps, i.GetName()) for i in (tl.GetItemListInTrack("subtitle", 1) or [])]
    mp.DeleteTimelines([tl])
    print("==", n); [print(f"  {s:5.2f}-{e:5.2f} {t}") for s, e, t in subs]
    if o.dialogue and o.shots: D[os.path.relpath(os.path.abspath(f), os.path.abspath(o.shots))] = [[round(s, 2), round(e, 2), t] for s, e, t in subs if not t.startswith("[")]
if o.dialogue: json.dump(D, open(o.dialogue, "w"), indent=1); print("dialogue windows ->", o.dialogue)
pm.SaveProject()
