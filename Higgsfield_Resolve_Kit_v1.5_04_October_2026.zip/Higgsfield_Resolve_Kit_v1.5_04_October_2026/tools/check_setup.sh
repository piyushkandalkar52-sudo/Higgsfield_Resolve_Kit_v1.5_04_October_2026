#!/bin/zsh
# Step 0 of the guided workflow: verify the machine.  Prints one line per check: OK / MISSING + fix.
K=${0:A:h}
ok(){ echo "OK       $1"; }; bad(){ echo "MISSING  $1  ->  $2"; }
command -v swiftc >/dev/null && ok "Xcode command line tools (swiftc)" || bad "swiftc" "run: xcode-select --install"
for n in lastframe sheet lipqa shotscan render_edl; do [ -x $K/$n ] || NEED=1; done
[ -z "$NEED" ] && ok "kit tools compiled" || bad "kit tools not compiled" "run: tools/build_tools.sh"
command -v python3 >/dev/null && ok "python3" || bad "python3" "install Python 3"
pgrep -f "DaVinci Resolve" >/dev/null && ok "DaVinci Resolve is running" || bad "DaVinci Resolve not running" "open DaVinci Resolve (Studio 19+)"
source $K/resolve_env.sh
python3 -c "import DaVinciResolveScript as d; import sys; sys.exit(0 if d.scriptapp('Resolve') else 1)" 2>/dev/null \
  && ok "Resolve scripting responds" || bad "Resolve scripting" "Resolve > Preferences > System > General > External scripting using: Local"
