#!/bin/zsh
# Download finished Higgsfield clips into a project and make their QA material.
# usage: tools/fetch_clip.sh <project> <SUBFOLDER> NAME URL [NAME URL ...]
#   -> 4_renders/clips/<SUB>/NAME.mp4, 5_review/<SUB>/NAME_sheet.jpg (12 frames), NAME_last.jpg (last frame)
K=${0:A:h}; P=${1:A}; SUB=$2; shift 2
V=$P/4_renders/clips/$SUB; Q=$P/5_review/$SUB; mkdir -p $V $Q
while [ $# -gt 1 ]; do
  curl -sf -o $V/$1.mp4 "$2" || { echo "FAIL download $1"; shift 2; continue; }
  $K/sheet $V/$1.mp4 $Q/$1_sheet.jpg 12 >/dev/null; $K/lastframe $V/$1.mp4 $Q/$1_last.jpg >/dev/null
  echo "$1 ok  -> $Q/$1_sheet.jpg"; shift 2
done
