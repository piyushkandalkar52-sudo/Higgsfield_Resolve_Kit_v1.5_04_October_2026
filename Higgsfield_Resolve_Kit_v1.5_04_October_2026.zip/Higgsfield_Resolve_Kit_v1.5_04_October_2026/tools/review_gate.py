#!/usr/bin/env python3
"""Read-only merge of version-bound review evidence; never inspects or approves media itself."""
import argparse
import hashlib
import json
from pathlib import Path

CHECKS = tuple('R' + str(i) for i in range(1, 10))
STATUSES = {'PASS', 'REPAIR', 'NEEDS REVIEW', 'NOT APPLICABLE'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def merge(request, reports):
    if not isinstance(request, dict):
        raise ValueError("request must be an object")
    problems, repairs = [], []
    if request.get('kind') not in ('image', 'video'):
        raise ValueError('kind must be image or video')
    for field in ('asset_id', 'asset_version', 'asset_sha256', 'scene_packet_sha256'):
        if not isinstance(request.get(field), str) or not request[field].strip():
            raise ValueError('missing ' + field)
    for path_key, hash_key in [('asset_path', 'asset_sha256'), ('scene_packet_path', 'scene_packet_sha256')]:
        path = Path(request[path_key])
        if not path.is_absolute():
            raise ValueError(path_key + ' must be absolute')
        if digest(path) != request[hash_key]:
            problems.append(path_key + ' changed since review request')
    grouped = {check: [] for check in CHECKS}
    reviewers = set()
    coverage = {'whole_image': False, 'playback': False, 'opening': False, 'closing': False}
    for report in reports:
        if not isinstance(report, dict):
            problems.append('report must be an object')
            continue
        reviewer = report.get('reviewer')
        if not isinstance(reviewer, str) or not reviewer.strip() or reviewer in reviewers:
            problems.append('missing or duplicate reviewer identifier')
            continue
        reviewers.add(reviewer)
        if any(report.get(f) != request[f] for f in ('asset_id', 'asset_version', 'asset_sha256', 'scene_packet_sha256')):
            problems.append(reviewer + ': stale or mismatched asset/scene packet')
            continue
        local = set()
        checks = report.get('checks')
        if not isinstance(checks, list):
            problems.append(reviewer + ': checks must be a list')
            continue
        for check in checks:
            if not isinstance(check, dict):
                problems.append(reviewer + ': malformed check')
                continue
            identifier = check.get('id')
            status = check.get('status')
            reason = check.get('reason')
            evidence = check.get('evidence')
            if identifier not in grouped or identifier in local:
                problems.append(reviewer + ': unknown or duplicate check ID')
                continue
            local.add(identifier)
            if status not in STATUSES or not isinstance(reason, str) or not reason.strip():
                problems.append(reviewer + ': invalid status or missing reason for ' + identifier)
                continue
            if status != 'NOT APPLICABLE' and (not isinstance(evidence, list) or not evidence or
                    any(not isinstance(e, str) or not e.strip() for e in evidence)):
                problems.append(reviewer + ': missing evidence for ' + identifier)
                continue
            grouped[identifier].append(check)
        observed = report.get('coverage', {})
        if not isinstance(observed, dict):
            problems.append(reviewer + ': invalid coverage')
        else:
            for field in coverage:
                if field in observed and not isinstance(observed[field], bool):
                    problems.append(reviewer + ': non-boolean coverage flag ' + field)
                coverage[field] |= observed.get(field) is True
    for identifier, items in grouped.items():
        if not items:
            problems.append(identifier + ': no review coverage')
            continue
        statuses = {item['status'] for item in items}
        if len(statuses) > 1:
            problems.append(identifier + ': reviewers disagree; lead must reconcile')
        if 'NEEDS REVIEW' in statuses:
            problems.append(identifier + ': unresolved mandatory check')
        for item in items:
            if item['status'] == 'REPAIR':
                repairs.append({'id': identifier, 'reason': item['reason'], 'evidence': item['evidence']})
    required = ('whole_image',) if request['kind'] == 'image' else ('playback', 'opening', 'closing')
    for field in required:
        if not coverage[field]:
            problems.append('required actual-media coverage missing: ' + field)
    decision = 'NEEDS REVIEW' if problems else ('REPAIR' if repairs else 'PASS')
    return {'asset_id': request['asset_id'], 'asset_version': request['asset_version'],
            'decision': decision, 'problems': problems, 'repairs': repairs,
            'coverage': coverage, 'reviewers': sorted(reviewers),
            'scope': 'Visual evidence completeness only; not human approval, full QA or release authority'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('request')
    parser.add_argument('reports', nargs='+')
    args = parser.parse_args()
    try:
        result = merge(json.loads(Path(args.request).read_text()),
                       [json.loads(Path(p).read_text()) for p in args.reports])
        print(json.dumps(result, indent=2))
        return 0 if result['decision'] == 'PASS' else 2
    except (ValueError, KeyError, TypeError, OSError) as error:
        print(json.dumps({'decision': 'NEEDS REVIEW', 'error': str(error)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
