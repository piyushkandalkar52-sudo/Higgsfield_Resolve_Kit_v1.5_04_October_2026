import AVFoundation
import Vision
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let t0 = Double(CommandLine.arguments[2])!, t1 = Double(CommandLine.arguments[3])!
let a = AVURLAsset(url: url); let g = AVAssetImageGenerator(asset: a); g.appliesPreferredTrackTransform = true
g.requestedTimeToleranceBefore = .zero; g.requestedTimeToleranceAfter = .zero
var opens: [Double] = []; var n = 0; var found = 0; var widths: [Double] = []
var t = t0
while t < t1 {
  n += 1
  if let cg = try? g.copyCGImage(at: CMTime(seconds: t, preferredTimescale: 600), actualTime: nil) {
    let req = VNDetectFaceLandmarksRequest()
    try? VNImageRequestHandler(cgImage: cg).perform([req])
    if let faces = req.results, let f = faces.max(by: { $0.boundingBox.width < $1.boundingBox.width }), let lips = f.landmarks?.innerLips {
      let ys = lips.normalizedPoints.map { Double($0.y) }
      opens.append((ys.max()! - ys.min()!)); found += 1; widths.append(Double(f.boundingBox.width) * Double(cg.width))
    }
  }
  t += 1.0/12.0
}
let mean = opens.isEmpty ? 0 : opens.reduce(0,+)/Double(opens.count)
let sd = opens.isEmpty ? 0 : sqrt(opens.map{($0-mean)*($0-mean)}.reduce(0,+)/Double(opens.count))
let w = widths.sorted(); let mw = w.isEmpty ? 0 : w[w.count/2]
print(String(format: "samples %d face %d%% faceW %.0fpx mouthOpen mean %.3f sd %.3f max %.3f  => %@", n, 100*found/max(n,1), mw, mean, sd, opens.max() ?? 0, (found*2 >= n && sd > 0.015) ? "LIPS MOVING" : "NO VISIBLE LIP-SYNC"))
