"""usage: resolve_verify_single_track.py "Timeline name"  -> exit 1 if video exists on any track other than the edit's spine."""
import sys, DaVinciResolveScript as d
p = d.scriptapp("Resolve").GetProjectManager().GetCurrentProject()
t = [p.GetTimelineByIndex(i) for i in range(1, p.GetTimelineCount() + 1) if p.GetTimelineByIndex(i).GetName() == sys.argv[1]][0]
n = {k: len(t.GetItemListInTrack("video", k) or []) for k in range(1, t.GetTrackCount("video") + 1)}
extra = sum(v for k, v in n.items() if k != max(n, key=n.get)); print("video items per track:", n)
sys.exit(1 if extra else 0)
