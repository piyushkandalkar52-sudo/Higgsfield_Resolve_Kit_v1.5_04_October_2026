"""Convert a render_edl JSON into an FCPXML 1.9 timeline that DaVinci Resolve imports with
cross-dissolves, clip audio levels and the VO on a connected lane.
usage: python3 edl_to_fcpxml.py EDL.json SHOTS_DIR VO_DIR OUT.fcpxml "Timeline Name"
"dissolve" = cross dissolve (overlap); "black" = cross dissolve too (Resolve has no dip in FCPXML import;
it is added as a 'Fade to Black'-style dissolve of tdur between the two clips)."""
import json, os, sys
from xml.sax.saxutils import quoteattr

edl_path, shots, vo_dir, out, name = sys.argv[1:6]
E = json.load(open(edl_path)); FPS = 24
def fr(s): return f"{int(round(s * FPS))}/{FPS}s"

assets, ids = [], {}
def asset(path, has_video=True):
    if path in ids: return ids[path]
    i = f"r{len(ids) + 2}"; ids[path] = i
    assets.append(f'<asset id="{i}" name={quoteattr(os.path.basename(path))} start="0s" duration="3600s" '
                  f'hasVideo="{1 if has_video else 0}" hasAudio="1" format="r1" audioSources="1" audioChannels="2">'
                  f'<media-rep kind="original-media" src={quoteattr("file://" + path)}/></asset>')
    return i

def split_wav(src, t0, dur):
    """Cut [t0, t0+dur] of a clip's audio to 4_renders/audio/split/ (48 kHz stereo wav) and return its path."""
    import subprocess, wave
    d = os.path.join(os.path.dirname(os.path.abspath(shots)), "audio", "split")  # <project>/4_renders/clips -> 4_renders/audio/split; os.makedirs(d, exist_ok=True)
    full = os.path.join(d, os.path.basename(src) + ".full.wav")
    if not os.path.exists(full): subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@48000", "-c", "2", src, full], check=True)
    out = os.path.join(d, f"{os.path.basename(src)[:-4]}_{t0:.2f}_{dur:.2f}.wav")
    w = wave.open(full); r = w.getframerate(); w.setpos(int(t0 * r)); fr_ = w.readframes(int(dur * r)); prm = w.getparams(); w.close()
    o = wave.open(out, "wb"); o.setparams(prm); o.writeframes(fr_); o.close(); return out

spine, cursor = [], 0.0
for k, c in enumerate(E["clips"]):
    p = os.path.join(shots, c["clip"]); aid = asset(p)
    dur = c["out"] - c["in"]; trans = c.get("trans", "cut"); tdur = c.get("tdur", 1.0)
    if k > 0 and trans in ("dissolve", "black"):
        spine.append(f'<transition name="Cross Dissolve" offset="{fr(cursor - tdur / 2)}" duration="{fr(tdur)}"/>')
    vol_db = -96 if c.get("vol", 1) <= 0 else 20 * __import__("math").log10(c.get("vol", 1))
    conn = []
    for v in c.get("vo", []):
        vp = os.path.join(vo_dir, v[0]); vid = asset(vp, has_video=False)
        import wave
        try:
            w = wave.open(vp); vd = w.getnframes() / w.getframerate(); w.close()
        except Exception: vd = 10.0
        conn.append(f'<asset-clip ref="{vid}" lane="-1" name={quoteattr(v[0])} offset="{fr(c["in"] + v[1])}" start="0s" duration="{fr(vd)}" audioRole="dialogue.VO"/>')
    xform = ""
    if c.get("zoom", 1) > 1:  # punch-in centred on (cx, cy), normalized top-left coords; FCPXML units: frame height = 100
        z = c["zoom"]; W, H = E.get("w", 1440), E.get("h", 1080); uw = 100.0 * W / H
        px = max(-(z - 1) * uw / 2, min((z - 1) * uw / 2, (0.5 - c.get("cx", 0.5)) * z * uw))
        py = max(-(z - 1) * 50, min((z - 1) * 50, (c.get("cy", 0.5) - 0.5) * z * 100))
        xform = f'<adjust-transform position="{px:.2f} {py:.2f}" scale="{z:.3f} {z:.3f}"/>'
    # split edit (J/L cut): this clip's own audio before / after its picture, exported as audio-only wavs (Resolve ignores
    # srcEnable="audio" and would put a video sliver on a lower track), connected like the VO
    for kind, t0, dur_s in (("J", c["in"] - c.get("a_pre", 0), c.get("a_pre", 0)), ("L", c["out"], c.get("a_post", 0))):
        if dur_s <= 0: continue
        wav = split_wav(p, t0, dur_s); wid = asset(wav, has_video=False)
        conn.append(f'<asset-clip ref="{wid}" lane="-2" name={quoteattr(os.path.basename(wav))} offset="{fr(c["in"] - c.get("a_pre", 0) if kind == "J" else c["out"])}" start="0s" duration="{fr(dur_s)}" audioRole="dialogue"><adjust-volume amount="{vol_db:.1f}dB"/></asset-clip>')
    spine.append(f'<asset-clip ref="{aid}" name={quoteattr(c["clip"])} offset="{fr(cursor)}" start="{fr(c["in"])}" duration="{fr(dur)}">'
                 + xform + f'<adjust-volume amount="{vol_db:.1f}dB"/>' + "".join(conn) + '</asset-clip>')
    cursor += dur
xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.9"><resources>
<format id="r1" name="FFVideoFormat1440x1080p24" frameDuration="1/24s" width="1440" height="1080"/>
{"".join(assets)}
</resources><library><event name={quoteattr(name)}><project name={quoteattr(name)}>
<sequence format="r1" duration="{fr(cursor)}" tcStart="0s" tcFormat="NDF"><spine>
{"".join(spine)}
</spine></sequence></project></event></library></fcpxml>'''
open(out, "w").write(xml); print("wrote", out, f"{cursor:.2f}s", len(E["clips"]), "clips")

# --- optional: embed an SRT as FCPXML captions (argv[6]) ---
if len(sys.argv) > 6:
    import re, math
    srt = open(sys.argv[6]).read().strip().split("\n\n")
    cues = []
    for b in srt:
        ln = b.strip().split("\n")
        m = re.match(r"(\d+):(\d+):(\d+),(\d+) --> (\d+):(\d+):(\d+),(\d+)", ln[1])
        g = list(map(int, m.groups()))
        cues.append((g[0]*3600+g[1]*60+g[2]+g[3]/1000, g[4]*3600+g[5]*60+g[6]+g[7]/1000, " ".join(ln[2:])))
    # timeline start of each spine clip
    starts, t = [], 0.0
    for c in E["clips"]:
        starts.append((t, c)); t += c["out"] - c["in"]
    from xml.sax.saxutils import escape
    caps = {}
    for n, (a, b, txt) in enumerate(cues):
        k = max(i for i, (st, c) in enumerate(starts) if st <= a + 1e-6)
        st, c = starts[k]
        caps.setdefault(k, []).append(
            f'<caption lane="1" offset="{fr(c["in"] + a - st)}" duration="{fr(b - a)}" role="SRT?captionFormat=SRT.en">'
            f'<text><text-style ref="cs{n}">{escape(txt)}</text-style></text>'
            f'<text-style-def id="cs{n}"><text-style font=".SF NS" fontSize="13" fontFace="Regular" fontColor="1 1 1 1" backgroundColor="0 0 0 1"/></text-style-def></caption>')
    x = open(out).read(); parts = x.split("</asset-clip>")
    # parts[i] ends clip i (spine clips only; connected VO asset-clips are self-closing)
    x2 = "".join(p + ("".join(caps.get(i, [])) + "</asset-clip>" if i < len(parts) - 1 else "") for i, p in enumerate(parts))
    open(out, "w").write(x2); print("embedded", len(cues), "captions")
