"""usage: q2_resolve_build.py FCPXML SRT "Timeline name"  -> imports edit, builds '<name> CAPTIONED' (SRT on empty tl, edit nested at 0)"""
import sys, os, DaVinciResolveScript as d
fx, srt, name = sys.argv[1:4]
r = d.scriptapp("Resolve"); p = r.GetProjectManager().GetCurrentProject(); mp = p.GetMediaPool()
root = mp.GetRootFolder(); mp.SetCurrentFolder(root)
tl = mp.ImportTimelineFromFile(os.path.abspath(fx), {"timelineName": name, "importSourceClips": True})
print("imported", tl.GetName() if tl else None)
end = tl.GetEndFrame(); start = tl.GetStartFrame(); print("frames", start, end)
cap = mp.CreateEmptyTimeline(name + " CAPTIONED"); p.SetCurrentTimeline(cap)
cap.AddTrack("subtitle")
item = mp.ImportMedia([os.path.abspath(srt)])[0]
print("srt append", mp.AppendToTimeline([item]))
src = [c for c in root.GetClipList() if c.GetName() == name]
print("nest src", src)
if src:
    print(mp.AppendToTimeline([{"mediaPoolItem": src[0], "startFrame": 0, "endFrame": end - start - 1, "trackIndex": 1, "recordFrame": cap.GetStartFrame()}]))
print("subs", len(cap.GetItemListInTrack("subtitle", 1) or []), "video", len(cap.GetItemListInTrack("video", 1) or []))
