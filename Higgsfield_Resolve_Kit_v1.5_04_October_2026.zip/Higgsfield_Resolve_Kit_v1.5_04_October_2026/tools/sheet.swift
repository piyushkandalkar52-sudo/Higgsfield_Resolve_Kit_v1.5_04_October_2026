import AVFoundation
import AppKit
let url = URL(fileURLWithPath: CommandLine.arguments[1]); let out = CommandLine.arguments[2]; let n = Int(CommandLine.arguments[3])!
let a = AVURLAsset(url: url); let g = AVAssetImageGenerator(asset: a); g.appliesPreferredTrackTransform = true
g.requestedTimeToleranceBefore = .zero; g.requestedTimeToleranceAfter = .zero; g.maximumSize = CGSize(width: 400, height: 400)
let d = CMTimeGetSeconds(a.duration); print("dur", d)
let cols = 4; let rows = (n + cols - 1) / cols
var imgs: [CGImage] = []
for i in 0..<n { let t = min(d - 0.05, d * Double(i) / Double(n - 1)); imgs.append(try! g.copyCGImage(at: CMTime(seconds: t, preferredTimescale: 600), actualTime: nil)) }
let w = imgs[0].width, h = imgs[0].height
let ctx = CGContext(data: nil, width: w*cols, height: h*rows, bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
for (i, im) in imgs.enumerated() { ctx.draw(im, in: CGRect(x: (i%cols)*w, y: (rows-1-i/cols)*h, width: w, height: h)) }
try! NSBitmapImageRep(cgImage: ctx.makeImage()!).representation(using: .jpeg, properties: [:])!.write(to: URL(fileURLWithPath: out))
