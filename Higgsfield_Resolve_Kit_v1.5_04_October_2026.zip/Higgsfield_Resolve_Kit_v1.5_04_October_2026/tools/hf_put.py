"""PUT local files to Higgsfield presigned URLs from a saved media_upload JSON.
usage: python3 tools/hf_put.py UPLOAD_JSON local1 [local2 ...]   (order = order of files[] in the media_upload call)"""
import json,sys,subprocess
d=json.load(open(sys.argv[1]))
if isinstance(d,list): d=json.loads(d[0]['text'])
for u,s in zip(d['uploads'],sys.argv[2:]):
    for _ in range(3):
        c=subprocess.run(["curl","-s","-o","/dev/null","-w","%{http_code}","-X","PUT","-H","Content-Type: "+u['content_type'],"--data-binary","@"+s,u['upload_url']],capture_output=True,text=True).stdout
        if c=="200": break
    print(u['media_id'],c,s.split('/')[-1])
