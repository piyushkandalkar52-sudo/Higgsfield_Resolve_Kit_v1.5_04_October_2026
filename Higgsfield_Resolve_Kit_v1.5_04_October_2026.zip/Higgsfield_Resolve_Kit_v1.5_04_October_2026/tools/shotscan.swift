// shotscan clip.mp4 [step]  -> JSON lines: t, cut(bool), faces [[cx,cy,h]] (normalized, top-left origin)
import AVFoundation
import Vision
import CoreGraphics
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let step = CommandLine.arguments.count > 2 ? Double(CommandLine.arguments[2])! : 0.2
let asset = AVURLAsset(url: url); let dur = CMTimeGetSeconds(asset.duration)
let g = AVAssetImageGenerator(asset: asset); g.appliesPreferredTrackTransform = true
g.requestedTimeToleranceBefore = .zero; g.requestedTimeToleranceAfter = .zero; g.maximumSize = CGSize(width: 480, height: 360)
func thumb(_ cg: CGImage) -> [UInt8] {
  let w = 32, h = 24; var px = [UInt8](repeating: 0, count: w * h)
  let ctx = CGContext(data: &px, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(), bitmapInfo: 0)!
  ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h)); return px }
var prev: [UInt8]? = nil; var t = 0.0; var rows: [String] = []
while t < dur - 0.05 {
  if let cg = try? g.copyCGImage(at: CMTime(seconds: t, preferredTimescale: 600), actualTime: nil) {
    let th = thumb(cg); var diff = 0.0
    if let p = prev { diff = zip(th, p).map { abs(Double($0) - Double($1)) }.reduce(0, +) / Double(th.count) }
    prev = th
    let req = VNDetectFaceRectanglesRequest(); try? VNImageRequestHandler(cgImage: cg).perform([req])
    let f = (req.results ?? []).map { String(format: "[%.3f,%.3f,%.3f]", $0.boundingBox.midX, 1 - $0.boundingBox.midY, $0.boundingBox.height) }
    rows.append(String(format: "{\"t\":%.2f,\"d\":%.1f,\"f\":[%@]}", t, diff, f.joined(separator: ",")))
  }
  t += step }
print("[" + rows.joined(separator: ",\n") + "]")
