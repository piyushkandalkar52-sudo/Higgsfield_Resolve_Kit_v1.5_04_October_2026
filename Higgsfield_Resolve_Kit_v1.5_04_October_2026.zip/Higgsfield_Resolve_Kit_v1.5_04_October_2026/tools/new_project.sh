#!/bin/zsh
# Create a separate multi-agent project; never modify an existing project.
K=${0:A:h}
exec python3 "$K/init_project.py" "$@"
