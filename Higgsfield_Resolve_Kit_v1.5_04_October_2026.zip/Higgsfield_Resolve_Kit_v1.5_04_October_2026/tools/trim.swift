import AVFoundation
let a = AVURLAsset(url: URL(fileURLWithPath: CommandLine.arguments[1]))
let e = AVAssetExportSession(asset: a, presetName: AVAssetExportPresetAppleM4A)!
e.outputURL = URL(fileURLWithPath: CommandLine.arguments[2]); e.outputFileType = .m4a
e.timeRange = CMTimeRange(start: CMTime(seconds: Double(CommandLine.arguments[3])!, preferredTimescale: 600), duration: CMTime(seconds: 12, preferredTimescale: 600))
let s = DispatchSemaphore(value: 0); e.exportAsynchronously { s.signal() }; s.wait(); print(e.status.rawValue, e.error as Any)
