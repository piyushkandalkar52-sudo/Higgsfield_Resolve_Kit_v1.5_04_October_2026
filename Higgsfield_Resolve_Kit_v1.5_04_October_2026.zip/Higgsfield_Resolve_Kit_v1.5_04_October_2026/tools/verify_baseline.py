#!/usr/bin/env python3
"""Maintainer tool: verify that an original source kit still matches a saved SHA-256 snapshot.

This kit never reads outside its own folder on its own. You must pass the location of the
original source kit explicitly with --source; there is no default and no stored path.
New users do not need this tool.
"""
import argparse
import hashlib
import json
from pathlib import Path

IGNORED = {'.DS_Store'}


def main():
    kit = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--source', required=True,
                        help='path to the original source kit folder (required)')
    parser.add_argument('--snapshot', default=str(kit / 'PROMPT_SYNC_SHA256.json'),
                        help='snapshot inside this kit (default: PROMPT_SYNC_SHA256.json)')
    args = parser.parse_args()
    with open(args.snapshot) as f:
        recorded = json.load(f)
    source = Path(args.source).expanduser()
    if not source.is_dir():
        parser.exit(1, f'Source folder not found: {source}\n')
    expected = {k: v for k, v in recorded['files'].items() if Path(k).name not in IGNORED}
    current = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
               for p in source.rglob('*') if p.is_file() and p.name not in IGNORED}
    changes = sorted(n for n in set(current) | set(expected) if current.get(n) != expected.get(n))
    if changes:
        for name in changes:
            print('DIFFERENT', name)
        return 1
    print(f'PASS: source kit unchanged; {len(current)} files match {Path(args.snapshot).name}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
