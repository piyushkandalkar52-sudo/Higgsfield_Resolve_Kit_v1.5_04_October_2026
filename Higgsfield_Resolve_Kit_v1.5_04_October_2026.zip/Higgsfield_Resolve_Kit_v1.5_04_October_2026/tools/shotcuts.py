"""Find the real shot boundaries inside every generated clip (Seedance clips contain their own internal cuts).
usage: python3 tools/shotcuts.py <project>            -> <project>/4_renders/edit/shotcuts.json
       python3 tools/shotcuts.py <project> SUB/a.mp4   -> also prints the cuts of the named clips
Keys are clip paths relative to 4_renders/clips (the same strings the EDL uses). A cut = an isolated spike in
tools/shotscan's frame difference (ignores whip pans, smoke, a swinging lamp)."""
import json, os, subprocess, sys
H = os.path.dirname(os.path.abspath(__file__)); P = os.path.abspath(sys.argv[1]); SH = os.path.join(P, "4_renders/clips")
OUT = os.path.join(P, "4_renders/edit/shotcuts.json"); C = json.load(open(OUT)) if os.path.exists(OUT) else {}
def scan(rel):
    d = json.loads(subprocess.run([os.path.join(H, "shotscan"), os.path.join(SH, rel), "0.1"], capture_output=True, text=True).stdout)
    v = [x["d"] for x in d]; t = [x["t"] for x in d]; cuts = []
    for i in range(1, len(v)):
        nb = sorted(v[j] for j in (i - 2, i - 1, i + 1, i + 2) if 0 <= j < len(v))
        if v[i] > 18 and v[i] > 3 * max(1, nb[len(nb) // 2]): cuts.append(round(t[i] - 0.05, 2))
    return {"cuts": cuts, "dur": round(t[-1] + 0.1, 2)}
want = sys.argv[2:]
for dp, _, fs in os.walk(SH, followlinks=True):
    for f in sorted(fs):
        if not f.endswith(".mp4"): continue
        rel = os.path.relpath(os.path.join(dp, f), SH)
        if rel not in C or rel in want: C[rel] = scan(rel)
for w in want: print(w, C[w])
json.dump(C, open(OUT, "w"), indent=1); print(len(C), "clips ->", OUT)
