"""Render a long EDL with render_edl in parts (full-length AVFoundation compositions fail), splitting only where
no VO spills past a part's last clip, then join parts pairwise.
usage: python3 tools/render_preview.py <project>/4_renders/edit/EDL.json OUT.mp4
The project folder is taken from $PROJECT, or derived from the EDL path (<project>/4_renders/edit/EDL.json)."""
import json, os, subprocess, sys, tempfile, wave
H = os.path.dirname(os.path.abspath(__file__))
EDL_PATH, OUT = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
P = os.environ.get("PROJECT") or os.path.dirname(os.path.dirname(os.path.dirname(EDL_PATH))); os.chdir(P)
SH, VO = P + "/4_renders/clips", P + "/4_renders/audio/vo"
E = json.load(open(EDL_PATH)); C = E["clips"]; T = tempfile.mkdtemp()
D = P + "/4_renders/scenes/_render_parts/" + os.path.basename(EDL_PATH)[:-5]; os.makedirs(D, exist_ok=True)
def vo_len(f): w = wave.open(VO + "/" + f); return w.getnframes() / w.getframerate()
def spills(c): return any(v[1] + vo_len(v[0]) > c["out"] - c["in"] for v in c.get("vo", []))
def render(edl, shots, out):
    j = T + "/" + os.path.basename(out) + ".json"; json.dump(edl, open(j, "w"))
    r = subprocess.run([os.path.join(H, "render_edl"), j, shots, VO, out], capture_output=True, text=True).stdout.strip().splitlines()[-1]
    if not r.startswith("OK"): sys.exit("FAILED " + out + " " + r[:200])
    return float(r.split()[1].rstrip("s"))
parts, cur = [], []
for k, c in enumerate(C):
    cur.append(c)
    if len(cur) >= 10 and not spills(c) and k < len(C) - 3: parts.append(cur); cur = []
if cur: parts.append(cur)
segs = []
for i, p in enumerate(parts):
    o = f"{D}/p{i}.mp4"; segs.append((os.path.basename(o), render(dict(E, clips=p, tail_fade=0.04 if i < len(parts) - 1 else 1.0), SH, o))); print("part", i, len(p), "clips", segs[-1][1])
while len(segs) > 1:
    nxt = []
    for i in range(0, len(segs), 2):
        grp = segs[i:i + 2]; last = i + 2 >= len(segs)
        if len(grp) == 1: nxt.append(grp[0]); continue
        o = f"{D}/j{len(segs)}_{i}.mp4"
        cl = [{"clip": n, "in": 0, "out": round(d - 0.02, 2), "vol": 1.0, "trans": "cut"} for n, d in grp]
        nxt.append((os.path.basename(o), render({"w": E["w"], "h": E["h"], "tail_fade": 1.0 if last else 0.04, "clips": cl}, D, o)))
    segs = nxt
os.replace(f"{D}/{segs[0][0]}", OUT); print("OK", round(segs[0][1], 2), OUT)
