"""Scan a rendered preview for flash frames / slivers  [R-J9].
usage: python3 tools/flash_check.py preview.mp4 [min_seconds=0.5]     exit 1 = a shot shorter than min_seconds
Frame-accurate (1/24 s): a cut = an isolated difference spike (d > 8 and > 4x both neighbours). Also lists shots < 2 s."""
import json, os, subprocess, sys
H = os.path.dirname(os.path.abspath(__file__)); V = sys.argv[1]; MIN = float(sys.argv[2]) if len(sys.argv) > 2 else 0.5
o = subprocess.run([os.path.join(H, "shotscan"), V, str(1 / 24)], capture_output=True, text=True).stdout
s = o[o.index("["):].strip()
try: r = json.loads(s)
except ValueError: r = json.loads(s[:s.rindex("}") + 1] + "]")
d = [x["d"] for x in r]; t = [x["t"] for x in r]
c = [0.0] + [t[i] for i in range(1, len(d) - 1) if d[i] > 8 and d[i] > 4 * max(d[i - 1], d[i + 1], 0.5)] + [t[-1]]
shots = [(round(c[i], 2), round(c[i + 1] - c[i], 2)) for i in range(len(c) - 1)]
flash = [x for x in shots if x[1] < MIN]; short = [x for x in shots if MIN <= x[1] < 2]
print(f"{len(shots)} shots; under 2 s (designed shots are OK, check them): {short}")
if flash:
    print(f"FLASH / SLIVER under {MIN} s at (start, length): {flash} -> move the EDL in/out ~2 frames off the cut")
    sys.exit(1)
print("flash check OK")
