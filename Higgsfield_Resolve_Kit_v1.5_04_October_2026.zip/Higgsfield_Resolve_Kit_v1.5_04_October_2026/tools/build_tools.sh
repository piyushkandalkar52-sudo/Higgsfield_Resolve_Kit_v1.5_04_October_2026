#!/bin/zsh
# Compile the Swift helpers once per machine (needs Xcode Command Line Tools: xcode-select --install).
cd "${0:A:h}"
for n in lastframe sheet lipqa trim shotscan render_edl retime sepia montage frameat; do
  swiftc -O $n.swift -o $n 2>/dev/null && echo "built $n" || echo "FAILED $n"
done
