#!/bin/zsh
# The ONE build command for a cut.  usage: tools/build_edit.sh <project> <EDL.json> <captions.srt> "<Timeline name>" "<Resolve project>"
# 1 lint (no leftover slivers < 2 s; extension heads marked "cont" are exempt)  2 FCPXML  3 Resolve timeline + CAPTIONED copy
# 4 verify one video track  5 preview mp4 in <project>/6_final/  6 flash check on the preview  7 save the Resolve project.
# 0 (before all): every EDL clip needs an approved / needs_repair row in <project>/logs/qa_index.csv [R-J10].
K=${0:A:h}; P=${1:A}; EDL=${2:A}; SRT=${3:A}; NAME=$4; RP=$5; export PROJECT=$P
source $K/resolve_env.sh
echo "== 0 review list"; python3 $K/review_check.py $P $EDL || exit 1
echo "== 1 shot-length lint"; python3 $K/edit_lint.py check $EDL || { echo "BUILD STOPPED: fix leftovers (python3 tools/edit_lint.py fix IN OUT) or mark extension heads \"cont\": true"; exit 1; }
X=${EDL:r}.fcpxml
echo "== 2 fcpxml"; python3 $K/edl_to_fcpxml.py $EDL $P/4_renders/clips $P/4_renders/audio/vo $X "$NAME" || exit 1
echo "== 3 resolve"; python3 $K/resolve_project.py "$RP" && python3 $K/resolve_build.py $X $SRT "$NAME" | tail -1
echo "== 4 verify"; python3 $K/resolve_verify.py "$NAME" || { echo "BUILD STOPPED: stray video on a second track"; exit 1; }
mkdir -p $P/6_final; OUT=$P/6_final/${NAME// /_}.mp4
echo "== 5 preview"; python3 $K/render_preview.py $EDL $OUT | tail -1
echo "== 6 flash check"; python3 $K/flash_check.py $OUT || { echo "BUILD STOPPED: flash frame in the preview (timeline is built; fix the EDL and rebuild as the next version)"; exit 1; }
echo "== 7 save"; python3 -c "import DaVinciResolveScript as d; print('saved', d.scriptapp('Resolve').GetProjectManager().SaveProject())"
echo "DONE  timeline: \"$NAME CAPTIONED\" in Resolve project \"$RP\"  |  preview: $OUT"
