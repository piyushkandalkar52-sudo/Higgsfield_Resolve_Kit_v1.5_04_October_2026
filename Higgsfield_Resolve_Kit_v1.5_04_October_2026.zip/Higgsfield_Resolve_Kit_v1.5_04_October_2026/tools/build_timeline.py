"""Rebuild a Resolve timeline from an EDL json.
usage: python3 build_timeline.py EDL.json --shots DIR --timeline "S03 Name" --folder S03_Name [--fps 24] [--w 1440 --h 1080] [--no-subs]
EDL entry: {"clip":"file.mp4","in":1.5,"out":6.0,"zoom":1.35?,"mute":true?,"path":"/abs/path.mp4"?}
Never touches any timeline except the one named. Deletes and recreates that one."""
import argparse, json, os, DaVinciResolveScript as d
a=argparse.ArgumentParser(); a.add_argument("edl"); a.add_argument("--shots",required=True); a.add_argument("--timeline",required=True)
a.add_argument("--folder",required=True); a.add_argument("--fps",type=float,default=24); a.add_argument("--w",default="1440"); a.add_argument("--h",default="1080")
a.add_argument("--no-subs",action="store_true"); o=a.parse_args()
r=d.scriptapp("Resolve"); p=r.GetProjectManager().GetCurrentProject(); mp=p.GetMediaPool(); root=mp.GetRootFolder()
f=[x for x in root.GetSubFolderList() if x.GetName()==o.folder]; f=f[0] if f else mp.AddSubFolder(root,o.folder)
allc={}
def walk(fo):
    for c in fo.GetClipList(): allc.setdefault(c.GetName(),c)
    for s in fo.GetSubFolderList(): walk(s)
walk(root); mp.SetCurrentFolder(f)
EDL=json.load(open(o.edl))
for e in EDL:
    if e["clip"] not in allc: allc[e["clip"]]=mp.ImportMedia([e.get("path") or os.path.join(o.shots,e["clip"])])[0]
old=[t for t in [p.GetTimelineByIndex(i) for i in range(1,p.GetTimelineCount()+1)] if t.GetName()==o.timeline]
if old: mp.DeleteTimelines(old)
tl=mp.CreateEmptyTimeline(o.timeline)
tl.SetSetting("useCustomSettings","1"); tl.SetSetting("timelineResolutionWidth",o.w); tl.SetSetting("timelineResolutionHeight",o.h)
p.SetCurrentTimeline(tl)
items=mp.AppendToTimeline([{"mediaPoolItem":allc[e["clip"]],"startFrame":int(e["in"]*o.fps),"endFrame":int(e["out"]*o.fps)-1} for e in EDL])
aud=tl.GetItemListInTrack("audio",1) or []
for it,e in zip(items,EDL):
    if e.get("zoom"): it.SetProperty("ZoomX",e["zoom"]); it.SetProperty("ZoomY",e["zoom"])
    if e.get("mute"):
        for x in aud:
            if x.GetStart()==it.GetStart(): x.SetClipEnabled(False)
if not o.no_subs: tl.CreateSubtitlesFromAudio({})
print("timeline %s: %.2fs, %d cuts"%(o.timeline,(tl.GetEndFrame()-tl.GetStartFrame())/o.fps,len(items)))
for it in (tl.GetItemListInTrack("subtitle",1) or []):
    print(f"  {(it.GetStart()-tl.GetStartFrame())/o.fps:7.2f} {it.GetName()}")
r.OpenPage("edit")
