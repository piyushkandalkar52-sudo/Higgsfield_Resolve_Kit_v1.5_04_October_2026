import AVFoundation
import AppKit
let url = URL(fileURLWithPath: CommandLine.arguments[1]); let out = CommandLine.arguments[2]
let a = AVURLAsset(url: url)
let g = AVAssetImageGenerator(asset: a); g.appliesPreferredTrackTransform = true
g.requestedTimeToleranceBefore = .zero; g.requestedTimeToleranceAfter = .zero
let d = CMTimeGetSeconds(a.duration)
let t = CommandLine.arguments.count > 3 ? Double(CommandLine.arguments[3])! : d - 0.06
let cg = try! g.copyCGImage(at: CMTime(seconds: t, preferredTimescale: 600), actualTime: nil)
try! NSBitmapImageRep(cgImage: cg).representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: out))
print(cg.width, cg.height, d)
