#!/usr/bin/env python3
"""Pocket FM company-account guard for the Higgsfield MCP tools.

Host-agnostic: wired into Claude Code (.claude/settings.json) and Codex
(.codex/hooks.json). Both hosts send the same hook JSON on stdin.

Enforced by Claude Code's hook runner, NOT by secrecy. The logic here is
readable on purpose. The only sensitive value is the log token in
guard_config.json.

Flow:
  SessionStart -> clear any stale verification, inject the rule for Claude.
  PreToolUse on a Higgsfield tool:
     - read-only tools (incl. list_workspaces) are always allowed
     - select_workspace invalidates the verification (forces re-check)
     - every credit-spending tool is BLOCKED until a fresh verification
       file proves the selected workspace is the company one
  PostToolUse on list_workspaces/balance/plans:
     - parse the REAL result; write the verification file only if the
       selected workspace is Pocket's enterprise workspace; otherwise log
       the attempt.
"""
import sys, os, json, time, re, datetime, urllib.request, urllib.error, getpass, socket, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(HERE, "state", "ws_verified.json")
CONFIG = os.path.join(HERE, "guard_config.json")

# Read-only tools that never spend credits and are needed to verify.
# Bare Higgsfield tool names (host prefixes are stripped by hf_tool()).
READONLY = {
    "list_workspaces", "balance", "show_plans_and_credits", "transactions",
    "get_preferences", "show_credit_reset", "show_generations",
    "show_generation_by_ids", "list_projects", "list_folders",
    "list_project_assets", "job_display",
}
VERIFY_SOURCES = {"list_workspaces", "balance", "show_plans_and_credits"}


def hf_tool(tool_name):
    """Return the bare tool name if this is a Higgsfield MCP tool, else None.
    Handles mcp__Higgsfield__x, mcp__higgsfield__x and plugin-scoped
    mcp__plugin_<p>_higgsfield__x names."""
    if not tool_name or not tool_name.startswith("mcp__"):
        return None
    parts = tool_name.split("__")
    if len(parts) < 3:
        return None
    server, bare = "__".join(parts[1:-1]), parts[-1]
    return bare if "higgsfield" in server.lower() else None


def load_config():
    try:
        with open(CONFIG) as f:
            return json.load(f)
    except Exception:
        return {}

def cfg(c, k, d):
    v = c.get(k)
    return v if v is not None else d

def read_input():
    try:
        return json.load(sys.stdin)
    except Exception:
        return {}

def emit(obj):
    sys.stdout.write(json.dumps(obj))
    sys.stdout.flush()

def deny(reason):
    emit({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": reason,
    }})
    sys.exit(0)

def allow():
    sys.exit(0)

def git_identity():
    out = {}
    for key in ("user.name", "user.email"):
        try:
            v = subprocess.run(["git", "config", "--get", key],
                               capture_output=True, text=True, timeout=5)
            out[key] = v.stdout.strip()
        except Exception:
            out[key] = ""
    return out

def log_attempt(config, event, tool, detail):
    url = cfg(config, "log_endpoint", "")
    if not url:
        return
    gid = git_identity()
    payload = {
        "secret": cfg(config, "log_secret", ""),
        "time": datetime.datetime.utcnow().isoformat() + "Z",
        "event": event,
        "tool": tool,
        "detail": detail,
        "os_user": _safe(getpass.getuser),
        "host": _safe(socket.gethostname),
        "git_name": gid.get("user.name", ""),
        "git_email": gid.get("user.email", ""),
        "cwd": os.getcwd(),
    }
    try:
        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=8).read()
    except Exception:
        pass  # logging is best-effort; never block on it

def _safe(fn):
    try:
        return fn()
    except Exception:
        return ""

def selected_workspace(tool_response):
    """Return (name, plan) of the selected workspace, or (None, None).
    Accepts structured JSON (dicts/lists, MCP content blocks, JSON text)
    and the tabular text format (header row names the columns)."""
    found = _from_structured(tool_response)
    if found:
        return found
    for text in _texts(tool_response):
        try:
            found = _from_structured(json.loads(text))
            if found:
                return found
        except Exception:
            pass
        found = _from_table(text)
        if found:
            return found
    return None, None

_SEL_KEYS = ("is_selected", "selected", "isSelected", "is_current", "current", "active")
_PLAN_KEYS = ("plan_type", "plan", "planType", "tier")

def _truthy(v):
    return v is True or str(v).strip().lower() in ("true", "yes", "1")

def _from_structured(x):
    if isinstance(x, dict):
        if any(k in x for k in _SEL_KEYS) and "name" in x:
            if any(_truthy(x.get(k)) for k in _SEL_KEYS):
                plan = next((x.get(k) for k in _PLAN_KEYS if x.get(k) is not None), None)
                return (str(x.get("name") or ""), str(plan) if plan is not None else None)
        for v in x.values():
            r = _from_structured(v)
            if r:
                return r
    elif isinstance(x, list):
        for v in x:
            r = _from_structured(v)
            if r:
                return r
    return None

def _texts(x):
    if isinstance(x, str):
        yield x
    elif isinstance(x, dict):
        for v in x.values():
            yield from _texts(v)
    elif isinstance(x, list):
        for v in x:
            yield from _texts(v)

def _from_table(text):
    cols = None
    for line in text.splitlines():
        m = re.search(r"\{([^}]*)\}", line)
        if m and "name" in m.group(1):
            cols = [c.strip().lower() for c in m.group(1).split(",")]
            continue
        parts = [p.strip() for p in line.split(",")]
        if cols and len(parts) >= len(cols):
            row = dict(zip(cols, parts))
            sel = next((row[k] for k in ("is_selected", "selected") if k in row), None)
            if sel is not None and _truthy(sel):
                return row.get("name") or "", row.get("plan_type") or row.get("plan")
        elif not cols and len(parts) >= 6 and parts[4].lower() == "true":
            return parts[1], parts[5]
    return None

def is_company(name, plan, config):
    if not name:
        return False
    matches = [m.lower() for m in cfg(config, "company_workspace_match",
                                      ["pocket entertainment", "pocket fm", "pocket_fm"])]
    name_ok = any(m in name.lower() for m in matches)
    if cfg(config, "require_enterprise_plan", True):
        plan_ok = (plan or "").lower() == "enterprise"
        return name_ok and plan_ok
    return name_ok

def write_state(name, plan):
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    with open(STATE, "w") as f:
        json.dump({"workspace": name, "plan": plan, "ts": time.time()}, f)

def clear_state():
    # Invalidate by overwriting; deletion can be blocked on synced folders,
    # and an invalid marker fails closed (fresh_state rejects it).
    try:
        os.makedirs(os.path.dirname(STATE), exist_ok=True)
        with open(STATE, "w") as f:
            json.dump({"workspace": None, "plan": None, "ts": 0}, f)
    except Exception:
        pass
    try:
        os.remove(STATE)
    except Exception:
        pass

def fresh_state(config):
    try:
        with open(STATE) as f:
            st = json.load(f)
    except Exception:
        return None
    ttl = cfg(config, "verify_ttl_seconds", 3600)
    if time.time() - st.get("ts", 0) > ttl:
        return None
    # Defense in depth: the stored workspace itself must still be the company one.
    if not is_company(st.get("workspace"), st.get("plan"), config):
        return None
    return st

def main():
    config = load_config()
    data = read_input()
    event = data.get("hook_event_name", "")
    tool = data.get("tool_name", "")
    bare = hf_tool(tool)

    if event == "SessionStart":
        clear_state()
        emit({"hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": (
                "This kit is licensed for Pocket FM company use only. Before any "
                "Higgsfield generation, the active workspace must be verified: call "
                "the Higgsfield list_workspaces tool and confirm the selected workspace "
                "is Pocket's enterprise workspace. Generation tools are blocked by a "
                "hook until that verification succeeds in this session."
            ),
        }})
        sys.exit(0)

    if event == "PreToolUse":
        if bare is None:
            allow()  # not a Higgsfield tool
        if bare == "select_workspace":
            clear_state()  # workspace may change; force re-verification
            allow()
        if bare in READONLY:
            allow()
        st = fresh_state(config)
        if st:
            allow()
        # not verified -> block and log
        log_attempt(config, "BLOCKED_UNVERIFIED", tool,
                    "generation attempted before company-workspace verification")
        deny(cfg(config, "block_message",
                 "Blocked: this kit is licensed for Pocket FM company use only. "
                 "The active Higgsfield workspace has not been verified as the "
                 "company enterprise workspace. Sign in with your company account "
                 "and select the Pocket workspace. This attempt has been logged."))

    if event == "PostToolUse":
        if bare in VERIFY_SOURCES:
            name, plan = selected_workspace(data.get("tool_response"))
            if is_company(name, plan, config):
                write_state(name, plan)
            else:
                clear_state()
                log_attempt(config, "NON_COMPANY_WORKSPACE", tool,
                            "selected workspace=%r plan=%r" % (name, plan))
        sys.exit(0)

    sys.exit(0)

if __name__ == "__main__":
    main()
