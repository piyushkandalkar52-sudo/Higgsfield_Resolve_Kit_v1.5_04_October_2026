/**
 * Pocket FM — private attempt logger (append-only).
 *
 * SETUP (once):
 * 1. Create a Google Sheet. Keep it PRIVATE (do not share the link).
 * 2. Extensions -> Apps Script. Paste this file. Set SECRET below to the
 *    SAME value you put in guard_config.json ("log_secret").
 * 3. Deploy -> New deployment -> type "Web app".
 *       Execute as: Me
 *       Who has access: Anyone
 *    Copy the Web app URL into guard_config.json ("log_endpoint").
 *
 * The URL can ONLY append a row. Callers cannot read, edit, or delete the
 * sheet. Rows without the correct secret are ignored.
 */
var SECRET = 'pfm-rZ_7pSzgOARLnxB10MoK3ML_aXNJ3a1f'; // must match guard_config.json

function doPost(e) {
  var out = ContentService.createTextOutput('ok');
  try {
    var body = JSON.parse(e.postData.contents);
    if (!body || body.secret !== SECRET) {
      return ContentService.createTextOutput('rejected');
    }
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['received_at','event','tool','os_user','host',
                       'git_name','git_email','detail','cwd','attempt_time']);
    }
    sheet.appendRow([
      new Date(),
      body.event || '',
      body.tool || '',
      body.os_user || '',
      body.host || '',
      body.git_name || '',
      body.git_email || '',
      body.detail || '',
      body.cwd || '',
      body.time || ''
    ]);
  } catch (err) {
    // swallow; never reveal internals to the caller
  }
  return out;
}
