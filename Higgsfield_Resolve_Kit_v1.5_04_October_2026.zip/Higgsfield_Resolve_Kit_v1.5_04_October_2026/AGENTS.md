# Agent entry point

## Company-account guard — read first
This kit's Higgsfield tools are protected by `guard/hf_guard.py`, wired into Codex through
`.codex/hooks.json` (and into Claude Code through `.claude/settings.json`). Generation tools
stay blocked until `list_workspaces` shows the Pocket company workspace on the enterprise plan.
At setup, call `list_workspaces` first. If a Higgsfield call is denied by the guard, report the
message to the user; never try to work around it. If the guard hooks are not active in this
session (the user has not trusted them in `/hooks`), do not run Higgsfield generation: ask the
user to open `/hooks` and trust the company-account guard first.

Read `CLAUDE.md`, `RULES.md`, `WORKFLOW.md`, `REFERENCE.md`, `MULTI_AGENT.md` and your assigned
`agents/` brief before production. Read `.claude/skills/pocketfm-seedance-prompt/SKILL.md` before
writing or reviewing prompts. These are production instructions when operating the kit; reading
or editing the kit itself does not authorize generation, spending or launching Resolve.

Follow approved run/packet versions. All roles share rule compliance. Only the director writes
canonical state and submits paid jobs. Workers use assigned unique draft/evidence paths and return
proposals. Only the assigned QA/editor operates Resolve, transcription and shared shot-cut scans.
Do not spawn extra workers merely to populate roles. Use real delegated agents only when supported
and authorized; otherwise execute the same roles sequentially and report the fallback honestly.

Read `docs/COORDINATOR.md` for supported coordinator commands and state transitions. Preserve
existing production gates, F3/J2 constraints, tool behavior and evidence requirements. Flag genuine
unresolved conflicts; honor explicit mode exceptions such as I4's ban on extension audio references.

## Additional review and oversight roles
Visual review uses agents/visual-reviewer.md and docs/VISUAL_REVIEW.md, derived from the user's
reviewer document. agents/workflow-supervisor.md and agents/agent-watcher.md define bounded
read-only audits. Use docs/AGENT_DISPATCH.md to choose roles and capacity; the larger role roster
does not increase host slots. Seven available roles do not mean seven permanently running agents.
