# Validation — 2026-10-04

## Passed
- 15 standard-library unit tests: reservation races across processes, budget caps,
  duplicate IDs/jobs, pending and unknown submissions, dependency and handoff gates,
  plan versions, invalidation, reviewed reuse without duplicate charges, audit records,
  numeric validation, isolated project creation and refusal to overwrite existing work.
- Actual zsh initializer and command-line smoke test in a temporary path with spaces;
  synthetic local records only, no remote request.
- Python syntax parsing for all copied and new Python tools/tests; zsh syntax for initializer.
- All 13 workflow steps retain Goal / You do / Ask / Gate / Outputs.
- Main document links and entry points checked; role names and approval gates reconciled.
- Every inherited production tool except the deliberately enhanced project initializer
  matches its source SHA-256. Prompt skill and prompt template are byte-for-byte preserved.
- Original source kit: all 74 files match BASELINE_SHA256.json.
- Independent agent review found and resolved rule/role inconsistencies and an invalidated
  take reuse issue. The explicit revalidation path now retains job IDs and financial records.

## Not claimed
No Higgsfield generation, account spending, Resolve project modification, live media QA,
PDF regeneration, or measured A/B production benchmark was performed. The retained PDF/HTML
are historical guides. Live API compatibility and alternate render specifications need
production preflight. Automated tests verify local coordination logic, not film quality.

The coordinator records evidence supplied by its operator; it cannot authenticate a user
approval or inspect a continuity packet itself. Worker dispatch and human-facing summary/CSV
reconciliation remain the AI coordinator's job. See docs/COORDINATOR.md for exact limits.

Run `python3 -m unittest discover -s tests -v` from this kit to repeat the local checks (reads only this
folder). Maintainers who have the original source kit can additionally run
`python3 tools/verify_baseline.py --source <path-to-original-kit>`.

## Prompt sync follow-up — 2026-10-04
The source kit was updated by its owner after the original validation above. The new skill is
byte-identical to that updated source. Only H introduction/H7 upstream rule changes were merged;
all multi-agent rule amendments remain. Prompt-facing templates and instructions were aligned.
The 15 existing coordination/project tests were rerun; no paid generation or live media tests.
Maintainers: use `python3 tools/verify_baseline.py --source <path-to-original-kit> --snapshot PROMPT_SYNC_SHA256.json` to compare the
source against the sync-time snapshot. BASELINE_SHA256.json is retained as creation history.

## Three added roles — 2026-10-04
- 22 unit tests passed (15 retained + 7 visual-report aggregation tests). New checks cover
  complete/split coverage, missing evidence, disagreements, stale asset/packet checksums,
  duplicate reviewers, video playback coverage, explicit N/A reasons and malformed inputs.
- Three native Claude definitions and matching role briefs checked; all nine user-source rules
  mapped. Independent review confirmed preserved gates and found one boolean-schema issue, fixed
  with a regression check. Existing coordinator code and prompt skill/template remain unchanged.
- Source DOCX preserved byte-for-byte and extracted for traceability. No media generation,
  paid spend, live visual QA, Resolve edits or monitoring automation occurred. The report merger
  validates declarations; it cannot prove visual correctness or that a review actually happened.
- Actual speed/rework improvement remains unmeasured until the A/B run at equal quality.
