# REFERENCE — settings, recipes, templates, tools, failure modes

> Inherited technical reference. Historical costs, service limits and model IDs below
> must be checked against available tools/current preflights before production.
> Multi-agent ownership and gates are in MULTI_AGENT.md and WORKFLOW.md; they supersede
> old sequential coordination assumptions. Only the editor runs shared shotcuts,
> Resolve transcription and builds. Only the coordinator submits paid jobs and logs.
> Extensions still require visual seam QA; “exact” below describes intended continuation,
> not a guarantee. The ledger CLI is documented in docs/COORDINATOR.md.
> Existing helper tools/renderer constraints are retained, not generalized to every format.
> ALLOW_UNREVIEWED is a legacy script escape hatch, not an authorized workflow shortcut;
> this edition requires review evidence. Build success does not prove final repairs.

## 1. Higgsfield settings and costs

| Purpose | Model | Key params |
|---|---|---|
| Base video clip | `seedance_2_5` | `mode: "omni_reference"`, `resolution: "480p"`, `aspect_ratio: "4:3"`, `duration` 4–15, `generate_audio`, `medias`: optional `start_image` / `end_image`, `image_references` (character sheets, plate), `audio_references` (voice, 15 s or shorter) |
| Extension clip | `seedance_2_5` | `mode: "video_extension"`, `extension_mode: "forward"`, `duration` 4–30, `medias`: `video_references` = the parent **job id**, plus `image_references`; **no `audio_references`** |
| Keyframe / sheet / frame edit | `gpt_image_2_5` | `aspect_ratio: "4:3"`; `medias` role `image` (the first image is the one being edited) |
| Narration | `seed_audio` | `prompt` = the exact line; `medias` = `audio_references` with the narrator's sample; `format: "wav"`, `sample_rate: 48000`; `speech_rate` ±% to fit a window |
| Preflight | any | `get_cost: true` (free; it doesn't validate the whole request) |

**Observed costs (480p):** video about 3 credits per second (a 10 s clip is about 30, a 6 s
extension 18); a narration line about 0.6; a GPT Image still about 0.25. The real figures are in
the `transactions` list; report from there.

**A first 5-minute run** (TRA, 2026-10-01): about 1,000 credits and about 2 hours, including
roughly 100 credits of rejected takes. **A 2-minute extension run:** about 460 credits.
**A keyframe run with scene chains in parallel** (HSF, 2026-10-03): 11 clips + 3 GPT Image masters
= 330.75 credits and about 47 active minutes for 1:20 of finished cut plus a 7.7 s insert, every
take accepted first time: about 250 credits and 35 active minutes per finished minute.
Those historical examples reported active time. New comparisons must record wall time
and adjusted elapsed separately, including generation waiting; see docs/BENCHMARK.md.

- A `medias[].value` is a confirmed `media_id` or a finished **job id**: a keyframe job or a parent
  video can be used directly.
- **Preset suggestion instead of a job:** resend with `declined_preset_id: "<id>"`. The common one
  is `24bae836-2c4a-48e0-89b6-49fcc0b21612` ("IN THE DARK").
- **Batches:** `generate_video_batch` takes up to 12 items per call. The `index` is yours; keep an
  index → clip map.
- **Polling:** `jobs_wait` waits at most 15 s per call. A 6–10 s clip takes about 4–9 minutes; a
  14 s extension up to about 10.

## 2. Uploading local files
1. Call `media_upload(files=[{filename:"Name.png"}, …])` with up to 20 files. The response is
   large and gets saved to a file; keep its path.
2. Run `python3 tools/hf_put.py <saved-response> <local files, same order>`. Every line must
   print `200`.
3. Call `media_confirm(type:"image"|"audio", media_ids:[…])`.
4. Record every id in `HANDOFF.md` §4 and reuse them; never re-upload.

## 3. Extension vs keyframe chaining (what the 2026-10-01/02 tests showed)

| | **Extension chains** | **Keyframe chaining** |
|---|---|---|
| The join | **Exact:** the extension starts on the parent's last frame | Approximate; needs the seam check [R-E3] |
| Prep per clip | None (the parent job id) | Extract the last frame, upload, sometimes a GPT Image edit |
| Voice references for dialogue | **Not allowed** (422); the model invents the voice | Allowed (cloned voice) |
| Speed | Strictly sequential per location (about 6–9 min per step) | Can run in parallel with anchor frames [R-E9] |
| Typical quirks | Holds the continuation longer than asked (up to about 2.5 s); sometimes replays an earlier shot of the parent; can pull the full location plate back in when the camera goes high | The model can ignore the start frame if the clip opens with a hard cut |

**Extension recipe:**
- Start the prompt with "Continue the video straight on from its last frame."
- Make the FIRST FRAME / BLOCKING section describe the parent's real last frame (look at it).
- Make the first segment "0.0s to 0.6s — the same shot as the video's last frame, continuing
  seamlessly", then HARD CUT to the coverage.
- In the edit, mark the clip `"cont": true` and cut at the first real boundary when the
  continuation runs long.

**Recommended mix:**
- Use extensions for silent action and montage chains.
- Put on-camera dialogue that needs a cloned voice in keyframe clips, or accept the model's voice
  for that line.

## 4. Prompt templates
Use the block order and realism layer from the prompt skill. Copy-ready skeletons are in
`templates/PROMPT_TEMPLATE.md`: a base dialogue clip, a base silent clip, an extension clip and a
GPT Image keyframe edit.

## 5. Tools (`tools/`; build once with `tools/build_tools.sh`)

| Tool | Use |
|---|---|
| `check_setup.sh` | Step 0 checks |
| `new_project.sh <slug> [parent]` | Create a project folder, its HANDOFF and its logs |
| `hf_put.py <response> <files…>` | PUT the files to Higgsfield's presigned upload URLs |
| `fetch_clip.sh <project> <SUB> NAME URL …` | Download clips, then make their 12-frame contact sheet and last frame |
| `sheet clip.mp4 out.jpg N` | N-frame contact sheet |
| `lastframe clip.mp4 out.jpg [t]` | Last frame (or the frame at t) |
| `frameat clip.mp4 out.jpg t` | Exact frame at t seconds |
| `montage out.jpg cols cellW cellH img…` | Labelled contact montage of reference images |
| `lipqa clip.mp4 t0 t1` | Lip motion in a window (sd > 0.015 = moving) |
| `transcribe.py --project "<Resolve project>" files…` | Resolve speech-to-text for clips or voice-over; `--dialogue … --shots …` stores the speech windows for the lint |
| `shotcuts.py <project> [clips…]` | Real shot boundaries for every clip → `4_renders/edit/shotcuts.json` |
| `trim in out.m4a start` | Cut a 12 s piece from a voice sample |
| `retime in out t0 t1 factor` | Slow down one section of a clip (e.g. a push at 1.6×) |
| `sepia in out [0..1]` | Sepia-and-vignette copy for flashbacks |
| `edit_lint.py check/fix EDL` | No slivers under 2 s at clip edges (extension heads with `"cont"` exempt) |
| `review_check.py <project> <EDL>` | Every EDL clip has an approved / needs_repair row in `logs/qa_index.csv` [R-J10]; `ALLOW_UNREVIEWED=1` overrides (log it) |
| `flash_check.py preview.mp4 [0.5]` | Frame-accurate scan of a render: stops on any shot under 0.5 s (flash frames), lists shots under 2 s [R-J9] |
| `edl_to_fcpxml.py`, `resolve_build.py`, `resolve_verify.py` | EDL → FCPXML → Resolve timeline + CAPTIONED → single-track check |
| `render_edl`, `render_preview.py <edl> <out.mp4>` | Preview MP4 rendered in parts (full-length compositions fail in AVFoundation) |
| `resolve_project.py "<name>"` | Open or create the Resolve project |
| `build_edit.sh <project> <edl> <srt> "<Timeline>" "<Resolve project>"` | **The one build command**: review-list check, lint, FCPXML, timeline, CAPTIONED copy, verify, preview, flash check, save |
| `qa_clips.py`, `build_timeline.py`, `audit_cut.py` | Older direct-Resolve helpers (still work) |

Before any Resolve tool: `source tools/resolve_env.sh`.

## 6. EDL format (the input to `build_edit.sh`)
```json
{"w":1440,"h":1080,"tail_fade":1.0,"clips":[
 {"clip":"SUB/A1_a2.mp4","in":0.0,"out":10.0,"vol":1.0,"trans":"cut","vo":[["SUB/V01.wav",9.6]]},
 {"clip":"SUB/A2_a3.mp4","in":0.0,"out":3.8,"vol":0.0,"cont":true},
 {"clip":"SUB/A2_a3.mp4","in":3.8,"out":12.0,"vol":1.0}
]}
```
- **`"edge_shots"`** (top level): `"wides"` (the default; for keyframe clips that open and close
  on a continuity wide) or `"designed"` (for clips whose first and last shots are designed shots,
  e.g. extension chains). The lint uses it to tell a leftover wide from a real shot.
- **Paths:** `clip` is relative to `4_renders/clips`; voice-over files are relative to
  `4_renders/audio/vo`.
- **Voice-over:** `vo` entries are `[file, offsetFromClipStart, vol?]`, and the offset must be 0
  or more.
- **Muting part of a clip:** split it into consecutive pieces of the same file (they play as
  one) and set `vol 0` on the piece to mute.
- **Optional keys:**
  - `zoom` + `cx` / `cy` (punch-in)
  - `a_pre` / `a_post` (J- or L-cut)
  - `trans: "dissolve"` / `"black"` + `tdur`
  - `cont: true` (extension head)
- **Rendering:** the voice-over of the **last** clip must end before that clip ends, or the
  renderer fails. Add the next shot, or move the line.

## 7. Failure modes seen, and fixes

| Symptom | Cause | Fix |
|---|---|---|
| Line plays as voice-over, mouth frozen | Speaker in a wide or low-angle MS, not facing camera | Speaker in MCU/CU facing camera, with "lips clearly shape every word" [R-F4] |
| Characters re-seated in reaction shots | Hard-cut singles | Push-in from the wide [R-E8] |
| Signature detail redrawn (mask) | A cut to a close-up | Close-up keyframe, one continuous shot [R-E7] |
| Standing character seated again in the end wide | Snap-back to the start composition | Image-edit the wide, then a short living wide [R-E12] |
| Character teleports mid-clip | Many hard cuts plus crossing moves in one prompt | MOVEMENT / STILL split, positions per beat [R-F2, F5] |
| Gasp, open mouth, hand to chest | Reaction words | Subtle-shock tells and banned words [R-G3] |
| Fire in the eyes, a prop catches fire | "Fire catch-lights", a parchment "beside a guttering candle" | Fire and prop safety wording [R-H5] |
| Freckles, sweat beads, raw red hands | Over-literal skin flaws | "Faint" / "subtle"; freckles only if on the sheet [R-H1] |
| Hand at the throat in a restraint | Arm-grab wording | Hold on the sleeve or wrist; "her neck stays clear in every shot" [R-L1] |
| NSFW flag on a mother-and-child shot | Adult leaning over a child in bed | Restage: at the table, a shawl over the shoulders [R-L3] |
| Flags, armoured soldiers, legible crest | Location plate content in a high wide | Head-height framing, drop the plate in extensions, frame rooftops out [R-H9] |
| `[thud]`, `(dramatic music)`, `[sigh]` | Native audio | Mute that piece in the EDL [R-I1] |
| Narration gibberish or silent take | Seed Audio glitch, numbers | Transcribe every line; regenerate; spell numbers out [R-I2] |
| 422 on generate | Voice reference over 15 s, **or** `audio_references` in extension mode | Trim to 12 s / drop the voice reference in extensions [R-I3, I4] |
| Extension replays an earlier shot | Model behaviour | Trim at the first real boundary after the replay |
| Preview renders dark | Old `render_edl` fade bug (fixed in this kit) | Rebuild `render_edl` from this kit's source |
| Preview render fails ("could not be composed") | The last clip's voice-over runs past its end | Move the line, or add the next shot [§6] |
| 429 "daily workspace group credit limit" | Workspace cap | Stop and report; list the rejected jobs [R-B2] |
| A prop is back, or a character is in the wrong place, at the start of a clip | FIRST FRAME / LOCATION MAP text copied from the master | Rewrite it from this clip's real start frame [R-E4] |
| Face or location drifts although the prompt names it | Only the composite start frame attached | Attach each visible face sheet and the location plate as separate references [R-E14] |
| Warm lamp bokeh behind a close-up in a cool-only look | Reverse angle into a doorway or hallway | Write the lamps out in LIGHTING; check backgrounds; fix in the image if it repeats [R-H10] |
| Thunder under the lines in a rain scene | Native audio | "No thunder" in AUDIO; mute it in the edit if it still appears [R-I5] |
| Extra props (four suitcases instead of two) | A closing wide from a new camera angle | End on the established master angle [R-E15] |
| Faces and fabric smear in later wides | Several last-frame handoffs in a row | Re-anchor from a sharp edited frame after two handoffs [R-E16] |
| Oversaturated, grainy, HDR-looking masters | Film-grain / HDR wording in the image prompt | Natural movie-screenshot wording; grain only in video STYLE [R-H11] |
| Child sheds tears although the prompt said no tears | Negative wording ignored | "Dry eyes, dry cheeks", or accept and log it [R-H12] |
| Two-frame flash at a cut in the preview | EDL in/out exactly on a cut time | Move the point ~2 frames off the cut; `flash_check.py` catches it [R-J9] |
| A shot change on the contact sheet is missing from shotcuts.json | Cut followed by fast motion (a slap, a whip pan) | Add the cut by hand from shotscan's difference values [R-J9] |
| Quiet line endings | Source clip audio, not an edit fade | Measure levels per line; level them in the mix [R-I7] |
| Build stops at "review list" | A clip in the EDL has no approved / needs_repair row | Review the take and write its row [R-K4] |
