"""The guard is wired identically into Claude Code and Codex, and fails closed."""
import json, os, re, shutil, subprocess, sys, tempfile, unittest
KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(KIT, "guard"))
import hf_guard  # noqa: E402

def load(p):
    with open(os.path.join(KIT, p)) as f:
        return json.load(f)

class HostsTest(unittest.TestCase):
    def test_tool_name_variants(self):
        self.assertEqual(hf_guard.hf_tool("mcp__Higgsfield__generate_video"), "generate_video")
        self.assertEqual(hf_guard.hf_tool("mcp__higgsfield__generate_video"), "generate_video")
        self.assertEqual(hf_guard.hf_tool("mcp__plugin_x_higgsfield__balance"), "balance")
        self.assertIsNone(hf_guard.hf_tool("mcp__filesystem__read_file"))
        self.assertIsNone(hf_guard.hf_tool("Bash"))

    def test_both_hosts_guard_all_three_events(self):
        for path, cfg in ((".claude/settings.json", load(".claude/settings.json")),
                          (".codex/hooks.json", load(".codex/hooks.json"))):
            for ev in ("SessionStart", "PreToolUse", "PostToolUse"):
                with self.subTest(host=path, event=ev):
                    cmds = [h["command"] for g in cfg["hooks"][ev] for h in g["hooks"]]
                    self.assertTrue(any("guard/hf_guard.py" in c for c in cmds))
            for ev in ("PreToolUse", "PostToolUse"):
                m = cfg["hooks"][ev][0]["matcher"]
                for name in ("mcp__Higgsfield__generate_video", "mcp__higgsfield__generate_video"):
                    self.assertTrue(re.search(m, name), (path, m, name))

    def test_codex_command_fails_closed_without_guard(self):
        tmp = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(tmp, ".codex"))
            shutil.copy(os.path.join(KIT, ".codex/hooks.json"), os.path.join(tmp, ".codex"))
            cmd = load(".codex/hooks.json")["hooks"]["PreToolUse"][0]["hooks"][0]["command"]
            r = subprocess.run(["sh", "-c", cmd], cwd=tmp, input='{"hook_event_name":"PreToolUse"}',
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 2)  # exit 2 = block in both hosts
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

if __name__ == "__main__":
    unittest.main()
