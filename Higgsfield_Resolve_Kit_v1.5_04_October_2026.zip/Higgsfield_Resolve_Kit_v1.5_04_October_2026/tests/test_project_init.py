import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('project_init', Path(__file__).resolve().parents[1] / 'tools/init_project.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class ProjectInitTests(unittest.TestCase):
    def test_isolated_layout_and_no_implicit_approval(self):
        with tempfile.TemporaryDirectory(prefix='kit space ') as parent:
            project = module.create('BENCH_B', parent)
            for path in ['HANDOFF.md', 'BENCHMARK_REPORT.md', 'work', '5_review/handoffs', 'logs/qa_index.csv', 'logs/benchmark_events.csv']:
                self.assertTrue((project / path).exists(), path)
            self.assertFalse((project / 'logs/production_manifest.json').exists())
            original = (project / 'HANDOFF.md').read_bytes()
            with self.assertRaises(ValueError):
                module.create('BENCH_B', parent)
            self.assertEqual(original, (project / 'HANDOFF.md').read_bytes())

    def test_path_traversal_and_existing_nonproject_rejected(self):
        with tempfile.TemporaryDirectory() as parent:
            for slug in ['../other', '', '/absolute', 'a/b', 'bad name']:
                with self.assertRaises(ValueError):
                    module.create(slug, parent)
            existing = Path(parent) / 'existing'
            existing.mkdir()
            (existing / 'keep.txt').write_text('keep')
            with self.assertRaises(ValueError):
                module.create('existing', parent)
            self.assertEqual('keep', (existing / 'keep.txt').read_text())


class LayoutTests(unittest.TestCase):
    def test_new_project_layout(self):
        with tempfile.TemporaryDirectory() as parent:
            project = module.create('LAYOUT', parent)
            for folder in module.FOLDERS:
                self.assertTrue((project / folder).is_dir(), folder)
            self.assertTrue((project / '2_library/README.md').exists())
            self.assertTrue((project / '2_library/library.csv').read_text().startswith('asset_id,name,category'))
            top = sorted(p.name for p in project.iterdir())
            self.assertEqual(top, ['1_source', '2_library', '3_prompts', '4_renders', '5_review',
                                   '6_final', 'BENCHMARK_REPORT.md', 'HANDOFF.md', 'logs', 'work'])
