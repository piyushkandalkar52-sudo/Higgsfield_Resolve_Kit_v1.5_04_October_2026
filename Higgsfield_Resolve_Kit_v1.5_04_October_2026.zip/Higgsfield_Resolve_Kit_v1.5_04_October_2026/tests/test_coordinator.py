import importlib.util
import json
import multiprocessing
from pathlib import Path
import tempfile
import unittest

MODULE = Path(__file__).resolve().parents[1] / 'tools' / 'coordinator.py'
spec = importlib.util.spec_from_file_location('coordinator', MODULE)
coordinator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(coordinator)


def reserve_worker(project, task, queue):
    try:
        coordinator.execute(project, 'reserve', task_id=task, cost='6')
        queue.put('ok')
    except ValueError:
        queue.put('blocked')


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.project = self.directory.name
        self.call('init', run_id='fake-run', cap='10')
        self.call('approve', plan_version='v1', approved_by='test fixture', evidence='Simulated approval; no actual production')

    def call(self, command, **args):
        return coordinator.execute(self.project, command, **args)

    def add(self, identifier, **kwargs):
        return self.call('add', task_id=identifier, plan_version='v1', kind='video', **kwargs)

    def submit(self, identifier, cost='3'):
        self.call('reserve', task_id=identifier, cost=cost)
        self.call('submitted', task_id=identifier, job_id='fake-' + identifier)

    def test_budget_race(self):
        self.add('a')
        self.add('b')
        context = multiprocessing.get_context('spawn')
        queue = context.Queue()
        workers = [context.Process(target=reserve_worker, args=(self.project, task, queue)) for task in ('a', 'b')]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(10)
            self.assertEqual(worker.exitcode, 0)
        self.assertEqual(sorted(queue.get(timeout=2) for _ in workers), ['blocked', 'ok'])
        self.assertEqual(self.call('status')['totals']['reserved'], '6')
        queue.close()

    def test_dedupe_and_immutable_task(self):
        self.add('a')
        self.call('reserve', task_id='a', cost='3')
        self.call('reserve', task_id='a', cost='3')
        self.assertEqual(self.call('status')['totals']['reserved'], '3')
        with self.assertRaises(ValueError):
            self.call('reserve', task_id='a', cost='4')
        self.call('submitted', task_id='a', job_id='fake-a')
        self.call('submitted', task_id='a', job_id='fake-a')
        self.add('b')
        self.call('reserve', task_id='b', cost='1')
        with self.assertRaises(ValueError):
            self.call('submitted', task_id='b', job_id='fake-a')
        with self.assertRaises(ValueError):
            self.add('a')

    def test_continuity_and_settlement_are_separate(self):
        self.add('a')
        self.add('b', continuity_parent='a')
        self.submit('a')
        self.call('settle', task_id='a', actual='2')
        self.assertNotIn('b', self.call('ready'))
        self.call('accept', task_id='a', evidence='fake review', handoff='Observed fake final frame; prop in left hand')
        self.assertIn('b', self.call('ready'))
        self.assertEqual(self.call('status')['totals']['actual'], '2')

    def test_accepted_parent_without_handoff_blocks_chain(self):
        self.add('a')
        self.add('b', continuity_parent='a')
        self.submit('a')
        self.call('accept', task_id='a', evidence='fake review')
        self.assertNotIn('b', self.call('ready'))

    def test_unknown_retains_reservation_across_resume(self):
        self.add('a')
        self.call('reserve', task_id='a', cost='8')
        self.call('unknown', task_id='a')
        self.assertEqual(self.call('status')['totals']['reserved'], '8')
        self.call('init', run_id='fake-run', cap='10')
        self.assertEqual(self.call('status')['ledger']['tasks']['a']['submission'], 'unknown')
        with self.assertRaises(ValueError):
            self.call('settle', task_id='a', actual='0')
        with self.assertRaises(ValueError):
            self.call('reserve', task_id='a', cost='8')
        self.call('submitted', task_id='a', job_id='reconciled-fake-job')
        self.call('settle', task_id='a', actual='8')
        self.assertEqual(self.call('status')['totals']['reserved'], '0')

    def test_cancel_unknown_requires_evidence(self):
        self.add('a')
        self.call('reserve', task_id='a', cost='8')
        self.call('unknown', task_id='a')
        with self.assertRaises(ValueError):
            self.call('cancel', task_id='a', evidence='')
        self.call('cancel', task_id='a', evidence='Fake service reconciliation confirms no job and no charge')
        self.assertEqual(self.call('status')['totals']['reserved'], '0')
        self.assertNotIn('a', self.call('ready'))

    def test_invalidation_propagates_and_preserves_money(self):
        self.add('a')
        self.submit('a')
        self.call('accept', task_id='a', evidence='fake QA', handoff='fake packet')
        self.add('b', continuity_parent='a')
        self.submit('b')
        self.add('c', depends=['b'])
        self.call('invalidate', task_id='a', reason='fake changed reference')
        state = self.call('status')
        self.assertTrue(all(t['invalidated'] for t in state['ledger']['tasks'].values()))
        self.assertEqual(state['totals']['reserved'], '6')
        self.assertEqual(self.call('ready'), [])
        self.call('settle', task_id='b', actual='3')
        with self.assertRaises(ValueError):
            self.call('accept', task_id='b', evidence='fake')

    def test_plan_version_and_cycles(self):
        self.add('old')
        with self.assertRaises(ValueError):
            self.add('self', depends=['self'])
        with self.assertRaises(ValueError):
            self.add('forward', depends=['not-yet-created'])
        self.call('approve', plan_version='v2', approved_by='fixture', evidence='simulated revised approval')
        self.assertEqual(self.call('ready'), [])
        with self.assertRaises(ValueError):
            self.call('reserve', task_id='old', cost='1')

    def test_actual_overrun_is_recorded_and_blocks_further_spend(self):
        self.add('a')
        self.submit('a', '1')
        self.call('settle', task_id='a', actual='12')
        self.assertEqual(self.call('status')['totals']['available'], '-2')
        self.add('b')
        with self.assertRaises(ValueError):
            self.call('reserve', task_id='b', cost='0')
        self.call('reject', task_id='a', evidence='fake output failed')
        self.assertEqual(self.call('status')['totals']['actual'], '12')

    def test_stale_reservation_and_blank_identifiers(self):
        self.add('a')
        self.call('reserve', task_id='a', cost='3')
        self.call('invalidate', task_id='a', reason='fake change')
        with self.assertRaises(ValueError):
            self.call('reserve', task_id='a', cost='3')
        self.call('submitted', task_id='a', job_id='observed-fake-job')
        for command, args in [('add', dict(task_id=' ', plan_version='v1', kind='video')),
                              ('submitted', dict(task_id='a', job_id=' ')),
                              ('init', dict(run_id=' ', cap='10')),
                              ('approve', dict(plan_version=' ', approved_by='fixture', evidence='fake'))]:
            with self.assertRaises(ValueError):
                self.call(command, **args)
        self.add('b')
        self.submit('b')
        with self.assertRaises(ValueError):
            self.call('accept', task_id='b', evidence='fake', handoff=' ')

    def test_revalidate_rebinds_without_spending_or_releasing_reservations(self):
        self.add('parent')
        self.submit('parent', '1')
        self.call('accept', task_id='parent', evidence='fake review', handoff='original packet')
        self.add('child', continuity_parent='parent')
        self.submit('child', '2')
        self.call('accept', task_id='child', evidence='fake review', handoff='child packet')
        self.call('invalidate', task_id='parent', reason='fake reference correction')
        self.add('replacement')
        self.submit('replacement', '1')
        self.call('accept', task_id='replacement', evidence='fake review', handoff='replacement packet')
        before = self.call('status')['totals']
        self.call('revalidate', task_id='child', plan_version='v1', evidence='fake independent seam re-review',
                  depends=['replacement'], continuity_parent='replacement', handoff='new reviewed child packet')
        state = self.call('status')
        self.assertEqual(state['totals'], before)
        child = state['ledger']['tasks']['child']
        self.assertEqual(child['job_id'], 'fake-child')
        self.assertEqual(child['dependencies'], ['replacement'])
        self.assertFalse(child['invalidated'])
        self.assertTrue(state['ledger']['tasks']['parent']['invalidated'])

    def test_revalidate_checks_verdict_dependencies_cycles_and_evidence(self):
        self.add('a')
        self.submit('a', '1')
        self.call('accept', task_id='a', evidence='fake review')
        self.add('b', depends=['a'])
        self.submit('b', '1')
        self.call('accept', task_id='b', evidence='fake review')
        self.call('invalidate', task_id='a', reason='fake change')
        for task_id, extra in [('a', {'depends': ['b']}), ('a', {'depends': ['missing']}),
                               ('b', {}), ('a', {'plan_version': 'v0'}), ('a', {'evidence': ' '})]:
            arguments = dict(task_id=task_id, plan_version='v1', evidence='fake re-review')
            arguments.update(extra)
            with self.assertRaises(ValueError):
                self.call('revalidate', **arguments)
        self.call('revalidate', task_id='a', plan_version='v1', evidence='fake reviewed unchanged output')
        self.assertTrue(self.call('status')['ledger']['tasks']['b']['invalidated'])
        self.add('rejected')
        self.submit('rejected', '1')
        self.call('reject', task_id='rejected', evidence='fake failure')
        self.call('invalidate', task_id='rejected', reason='fake')
        self.add('pending')
        self.call('invalidate', task_id='pending', reason='fake')
        for task_id in ('rejected', 'pending', 'a'):
            with self.assertRaises(ValueError):
                self.call('revalidate', task_id=task_id, plan_version='v1', evidence='fake')

    def test_validation_and_audit(self):
        self.add('a')
        for value in ('NaN', 'Infinity', '-1'):
            with self.assertRaises(ValueError):
                self.call('reserve', task_id='a', cost=value)
        state = self.call('status')['ledger']
        self.assertEqual([event['command'] for event in state['events']], ['init', 'approve', 'add'])
        self.assertTrue(all(event['at'] for event in state['events']))
        self.assertEqual(json.loads((Path(self.project) / 'logs/production_manifest.json').read_text()), state)


if __name__ == '__main__':
    unittest.main()
