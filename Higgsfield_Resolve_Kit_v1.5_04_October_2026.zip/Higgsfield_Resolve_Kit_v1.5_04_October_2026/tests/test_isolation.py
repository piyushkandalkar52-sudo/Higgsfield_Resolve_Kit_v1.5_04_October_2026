"""The kit must not read outside its own folder by default."""
import os, re, subprocess, sys, unittest
KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class IsolationTest(unittest.TestCase):
    def test_baseline_requires_explicit_source(self):
        r = subprocess.run([sys.executable, os.path.join(KIT, 'tools', 'verify_baseline.py')],
                           capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn('--source', r.stderr)

    def test_no_absolute_user_paths_in_active_files(self):
        skip = ('docs/sync_history', 'docs/legacy', 'learning/', '.git/')
        bad = []
        for root, _, files in os.walk(KIT):
            rel = os.path.relpath(root, KIT)
            if any(rel.startswith(s.rstrip('/')) for s in skip):
                continue
            for n in files:
                if n == 'test_isolation.py' or not n.endswith(('.md', '.py', '.sh', '.json', '.swift')):
                    continue
                p = os.path.join(root, n)
                with open(p, encoding='utf-8', errors='ignore') as f:
                    if re.search(r'/Users/[^/\s]+/|~/Documents', f.read()):
                        bad.append(os.path.relpath(p, KIT))
        self.assertEqual(bad, [])

if __name__ == '__main__':
    unittest.main()
