"""Company-account guard: the selected workspace must be Pocket + enterprise."""
import json, os, subprocess, sys, tempfile, shutil, unittest
KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(KIT, "guard")

CO = {"id": "b7", "name": "Pocket Entertainment", "is_selected": True, "plan_type": "enterprise"}
PE = {"id": "b2", "name": "Personal", "is_selected": True, "plan_type": "free"}
TBL = ("workspaces[2]{id,name,type,user_role,is_selected,plan_type,credits}:\n"
       "  b2,,private,owner,%s,free,1.3\n  b7,Pocket Entertainment,shared,member,%s,enterprise,9")

class GuardTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        hooks = os.path.join(self.tmp, "hooks")
        shutil.copytree(SRC, hooks)
        self.g = os.path.join(hooks, "hf_guard.py")
        cfg = os.path.join(hooks, "guard_config.json")
        with open(cfg) as f:
            c = json.load(f)
        c["log_endpoint"] = ""
        with open(cfg, "w") as f:
            json.dump(c, f)
    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)
    def run_hook(self, d):
        return subprocess.run([sys.executable, self.g], input=json.dumps(d),
                              capture_output=True, text=True).stdout.strip()
    def gen(self):
        o = self.run_hook({"hook_event_name": "PreToolUse", "tool_name": "mcp__Higgsfield__generate_video"})
        return "allow" if not o else json.loads(o)["hookSpecificOutput"]["permissionDecision"]
    def verify(self, resp):
        self.run_hook({"hook_event_name": "SessionStart"})
        self.run_hook({"hook_event_name": "PostToolUse",
                       "tool_name": "mcp__Higgsfield__list_workspaces", "tool_response": resp})
    def test_blocked_before_verification(self):
        self.run_hook({"hook_event_name": "SessionStart"}); self.assertEqual(self.gen(), "deny")
    def test_readonly_allowed(self):
        o = self.run_hook({"hook_event_name": "PreToolUse", "tool_name": "mcp__Higgsfield__list_workspaces"})
        self.assertEqual(o, "")
    def test_formats(self):
        cases = [(TBL % ("false", "true"), "allow"), (TBL % ("true", "false"), "deny"),
                 ({"workspaces": [dict(PE, is_selected=False), CO]}, "allow"),
                 ({"workspaces": [PE, dict(CO, is_selected=False)]}, "deny"),
                 (json.dumps([CO]), "allow"),
                 ([{"type": "text", "text": json.dumps([CO])}], "allow"),
                 ({"content": [{"type": "text", "text": TBL % ("true", "false")}]}, "deny"),
                 ([dict(CO, plan_type="free")], "deny"), ("error: timeout", "deny")]
        for resp, exp in cases:
            with self.subTest(resp=str(resp)[:60]):
                self.verify(resp); self.assertEqual(self.gen(), exp)
    def test_switch_workspace_relocks(self):
        self.verify([CO]); self.assertEqual(self.gen(), "allow")
        self.run_hook({"hook_event_name": "PreToolUse", "tool_name": "mcp__Higgsfield__select_workspace"})
        self.assertEqual(self.gen(), "deny")

if __name__ == "__main__":
    unittest.main()
