import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('review_gate', Path(__file__).resolve().parents[1] / 'tools/review_gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


class ReviewGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.asset = Path(self.tmp.name) / 'synthetic_asset.bin'
        self.packet = Path(self.tmp.name) / 'scene.md'
        self.asset.write_bytes(b'fixture only, not a real image')
        self.packet.write_text('Synthetic scene context')
        self.request = dict(asset_id='A', asset_version='v1', kind='image',
                            asset_path=str(self.asset), asset_sha256=gate.digest(self.asset),
                            scene_packet_path=str(self.packet), scene_packet_sha256=gate.digest(self.packet))
        self.report = {key: self.request[key] for key in ('asset_id', 'asset_version', 'asset_sha256', 'scene_packet_sha256')}
        self.report.update(reviewer='r1', coverage={'whole_image': True}, checks=[
            {'id': cid, 'status': 'PASS', 'reason': 'Synthetic test finding', 'evidence': ['Synthetic evidence only']}
            for cid in gate.CHECKS])

    def test_full_and_split_coverage(self):
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'PASS')
        second = copy.deepcopy(self.report)
        second['reviewer'] = 'r2'
        second['checks'] = second['checks'][4:]
        self.report['checks'] = self.report['checks'][:4]
        self.assertEqual(gate.merge(self.request, [self.report, second])['decision'], 'PASS')

    def test_missing_coverage_and_evidence(self):
        self.report['checks'].pop()
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'NEEDS REVIEW')
        self.report['checks'][0]['evidence'] = []
        result = gate.merge(self.request, [self.report])
        self.assertTrue(any('missing evidence' in x for x in result['problems']))

    def test_material_defect_not_averaged(self):
        self.report['checks'][0]['status'] = 'REPAIR'
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'REPAIR')
        other = copy.deepcopy(self.report)
        other['reviewer'] = 'r2'
        other['checks'][0]['status'] = 'PASS'
        result = gate.merge(self.request, [self.report, other])
        self.assertEqual(result['decision'], 'NEEDS REVIEW')
        self.assertEqual(len(result['repairs']), 1)

    def test_stale_report_or_changed_media(self):
        self.report['asset_version'] = 'v0'
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'NEEDS REVIEW')
        self.report['asset_version'] = 'v1'
        self.asset.write_bytes(b'replaced')
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'NEEDS REVIEW')

    def test_packet_changes_and_duplicate_reviewers(self):
        self.assertEqual(gate.merge(self.request, [self.report, self.report])['decision'], 'NEEDS REVIEW')
        self.packet.write_text('Changed selected references')
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'NEEDS REVIEW')

    def test_video_cannot_pass_from_stills(self):
        self.request['kind'] = 'video'
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'NEEDS REVIEW')
        self.report['coverage'] = {'playback': True, 'opening': True, 'closing': True}
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'PASS')
        other = copy.deepcopy(self.report)
        other['reviewer'] = 'r2'
        self.report['coverage']['playback'] = 'true'
        self.assertEqual(gate.merge(self.request, [self.report, other])['decision'], 'NEEDS REVIEW')

    def test_na_needs_reason_and_malformed_fails_closed(self):
        self.report['checks'][7] = {'id': 'R8', 'status': 'NOT APPLICABLE', 'reason': 'Static sheet; no temporal action', 'evidence': []}
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'PASS')
        self.report['checks'][7]['reason'] = ''
        self.assertEqual(gate.merge(self.request, [self.report])['decision'], 'NEEDS REVIEW')
        self.assertEqual(gate.merge(self.request, [[]])['decision'], 'NEEDS REVIEW')
        with self.assertRaises(ValueError):
            gate.merge([], [])


if __name__ == '__main__':
    unittest.main()
