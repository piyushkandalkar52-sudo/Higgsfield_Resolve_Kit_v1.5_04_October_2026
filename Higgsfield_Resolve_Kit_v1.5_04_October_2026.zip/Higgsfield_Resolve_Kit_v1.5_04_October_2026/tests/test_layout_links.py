"""Every project folder named by a tool, agent, template or doc must exist in a new project."""
import importlib.util, os, re, tempfile, unittest
from pathlib import Path
KIT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('project_init', KIT / 'tools/init_project.py')
init = importlib.util.module_from_spec(spec); spec.loader.exec_module(init)
SKIP = {'sync_history', 'legacy', 'learning', '.git', 'state', '__pycache__'}
PATH = re.compile(r'(?<![\w/])([1-6]_(?:source|library|prompts|renders|review|final)(?:/[A-Za-z][\w-]*)*)')
OLD = re.compile(r'0[0-5]_(?:input|prompts|output|qa|stitch|delivery)')

def kit_files():
    for root, dirs, files in os.walk(KIT):
        dirs[:] = [d for d in dirs if d not in SKIP]
        for n in files:
            if n.endswith(('.md', '.py', '.sh', '.swift', '.json')) and n not in ('CHANGELOG.md', 'test_layout_links.py'):
                yield Path(root) / n

class LayoutLinkTests(unittest.TestCase):
    def test_referenced_folders_exist_in_new_project(self):
        with tempfile.TemporaryDirectory() as parent:
            project = init.create('LINKS', parent)
            missing = set()
            for f in kit_files():
                for m in PATH.findall(f.read_text(encoding='utf-8', errors='ignore')):
                    # the deepest existing folder must be the full path minus at most a file/run-specific leaf
                    parts = m.split('/')
                    if not (project / m).exists() and not (project / '/'.join(parts[:-1])).is_dir():
                        missing.add(f'{f.relative_to(KIT)}: {m}')
            self.assertEqual(sorted(missing), [])

    def test_no_old_layout_paths(self):
        bad = [str(f.relative_to(KIT)) for f in kit_files() if OLD.search(f.read_text(encoding='utf-8', errors='ignore'))]
        self.assertEqual(bad, [])

if __name__ == '__main__':
    unittest.main()


class DepthDerivedPathTests(unittest.TestCase):
    """Tools that derive folders by walking up from a path must land inside the new layout."""
    def test_tools_resolve_into_layout(self):
        import ast
        with tempfile.TemporaryDirectory() as parent:
            project = init.create('DEPTH', parent)
            clips = str(project / '4_renders/clips')
            edl = str(project / '4_renders/edit/EDL.json')
            # edl_to_fcpxml: split audio sits beside clips under 4_renders
            src = (KIT / 'tools/edl_to_fcpxml.py').read_text()
            self.assertIn('os.path.dirname(os.path.abspath(shots)), "audio", "split"', src)
            self.assertTrue(os.path.isdir(os.path.join(os.path.dirname(clips), 'audio')))
            # edit_lint / render_preview: project = three levels above the EDL
            for tool in ('edit_lint.py', 'render_preview.py'):
                self.assertIn('os.path.dirname(os.path.dirname(os.path.dirname(', (KIT / 'tools' / tool).read_text(), tool)
            self.assertEqual(Path(os.path.dirname(os.path.dirname(os.path.dirname(edl)))), project)
